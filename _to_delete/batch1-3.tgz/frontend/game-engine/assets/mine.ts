import type { MineRockKind } from '@farming/shared';
import { P } from './palette';
import { PixelCanvas } from './PixelCanvas';
import type { Rng } from '../utils/random';

/** Art for the mine: entrance, cave floor and walls, rocks, ladders and slimes. */

const CAVE = {
  floor: '#4a3f38',
  floorLight: '#5a4d44',
  floorDark: '#3a312b',
  wall: '#2a2320',
  wallTop: '#5e5048',
  wallFace: '#433832',
  wallFaceDark: '#352c27',
};

const ORE: Record<MineRockKind, { base: string; light: string } | null> = {
  stone: null,
  copper: { base: '#d9823b', light: '#f4b07a' },
  iron: { base: '#8f9eb0', light: '#d8e2ee' },
  gold: { base: '#e8b83a', light: '#fff0a8' },
  gem: { base: '#9b5ccf', light: '#e2bcff' },
};

/** The mine entrance in the overworld: a rocky mound with a timbered opening. 32x30, base row 28. */
export function drawMineEntrance(): PixelCanvas {
  const p = new PixelCanvas(32, 30);
  for (let y = 2; y <= 28; y++) {
    for (let x = 0; x < 32; x++) {
      const nx = (x - 15.5) / 15.5;
      const ny = (y - 22) / 20;
      if (nx * nx + ny * ny > 1) continue;
      const l = -(nx * 0.5 + ny * 0.9);
      p.set(x, y, l > 0.5 ? P.stoneLight : l < -0.3 ? P.stoneDark : P.stone);
    }
  }
  // Dark opening.
  for (let y = 12; y <= 28; y++) {
    for (let x = 9; x <= 22; x++) {
      const nx = (x - 15.5) / 6.5;
      const ny = (y - 28) / 16;
      if (nx * nx + ny * ny <= 1) p.set(x, y, y < 16 ? '#1a1412' : '#100c0b');
    }
  }
  // Timber frame.
  p.rect(8, 13, 2, 16, P.woodDark);
  p.rect(22, 13, 2, 16, P.woodDark);
  p.rect(7, 12, 18, 2, P.wood);
  p.rect(7, 12, 18, 1, P.woodLight);
  // Rails.
  p.rect(12, 26, 1, 3, '#7d858d');
  p.rect(19, 26, 1, 3, '#7d858d');
  for (let y = 26; y <= 28; y += 2) p.rect(11, y, 10, 1, P.woodDark);
  // A lantern on the frame.
  p.rect(5, 15, 2, 3, '#ffd76a');
  p.set(5, 14, P.woodDark);
  p.outline(P.outline);
  return p;
}

/** A breakable mine rock, 16x14 (same footprint as the overworld rock). */
export function drawMineRock(rng: Rng, kind: MineRockKind): PixelCanvas {
  const p = new PixelCanvas(16, 14);
  const dark = '#4f4742';
  const mid = '#6e655e';
  const light = '#8e847b';
  for (let y = 1; y <= 12; y++) {
    for (let x = 0; x < 16; x++) {
      const nx = (x - 7.5) / (6.2 + rng.range(-0.3, 0.3));
      const ny = (y - 8) / 5;
      if (nx * nx + ny * ny > 1) continue;
      const l = -(nx * 0.55 + ny * 0.85);
      p.set(x, y, y === 12 ? dark : l > 0.45 ? light : l < -0.35 ? dark : mid);
    }
  }
  p.set(5, 5, '#aea397');
  const ore = ORE[kind];
  if (ore) {
    const spots = kind === 'gem' ? 3 : 5;
    for (let i = 0; i < spots; i++) {
      const x = rng.int(3, 11);
      const y = rng.int(5, 10);
      p.rect(x, y, kind === 'gem' ? 2 : 1, kind === 'gem' ? 2 : 1, ore.base);
      p.set(x, y, ore.light);
    }
  }
  p.outline(P.outline);
  return p;
}

/** A hole with a ladder leading down, 16x16 (flat on the floor). */
export function drawLadderDown(): PixelCanvas {
  const p = new PixelCanvas(16, 16);
  for (let y = 2; y <= 14; y++) {
    for (let x = 1; x <= 14; x++) {
      const nx = (x - 7.5) / 6.5;
      const ny = (y - 8) / 6;
      if (nx * nx + ny * ny <= 1) p.set(x, y, y < 5 ? '#1e1816' : '#0c0908');
    }
  }
  p.rect(5, 3, 1, 11, P.wood);
  p.rect(10, 3, 1, 11, P.wood);
  for (let y = 4; y <= 12; y += 3) p.rect(5, y, 6, 1, P.woodLight);
  p.outline(P.outline);
  return p;
}

/** The ladder back up to daylight, 16x26, base row 24. */
export function drawLadderUp(): PixelCanvas {
  const p = new PixelCanvas(16, 26);
  p.rect(3, 0, 2, 25, P.woodDark);
  p.rect(11, 0, 2, 25, P.woodDark);
  for (let y = 2; y <= 22; y += 4) {
    p.rect(3, y, 10, 2, P.wood);
    p.rect(3, y, 10, 1, P.woodLight);
  }
  // A shaft of daylight.
  p.rect(5, 0, 6, 2, '#fff3c4', 150);
  p.outline(P.outline);
  return p;
}

/** Slime sheet: 2 frames of 14x11 (squash, stretch), drawn white so it can be tinted. */
export function drawSlimeSheet(): PixelCanvas {
  const p = new PixelCanvas(28, 11);
  for (let f = 0; f < 2; f++) {
    const ox = f * 14;
    const h = f === 0 ? 6 : 8;
    const w = f === 0 ? 6.5 : 5.5;
    for (let y = 0; y < 11; y++) {
      for (let x = 0; x < 14; x++) {
        const nx = (x - 6.5) / w;
        const ny = (y - 10) / h;
        if (y > 10 || nx * nx + ny * ny > 1) continue;
        const shade = y < 10 - h * 0.6 ? 255 : y > 8 ? 170 : 215;
        const v = shade.toString(16).padStart(2, '0');
        p.set(ox + x, y, `#${v}${v}${v}`);
      }
    }
    // Eyes.
    const ey = f === 0 ? 7 : 5;
    p.set(ox + 4, ey, '#1a1412');
    p.set(ox + 8, ey, '#1a1412');
    p.set(ox + 4, ey - 1, '#ffffff');
  }
  p.outline(P.outline);
  return p;
}

/**
 * One floor of the mine as a single image: floor tiles with pebbles and
 * cracks, walls with a lit top edge. `wall(x, y)` says which tiles are rock.
 */
export function drawCaveFloor(rng: Rng, width: number, height: number, wall: (x: number, y: number) => boolean, size = 16): HTMLCanvasElement {
  const p = new PixelCanvas(width * size, height * size);
  for (let ty = 0; ty < height; ty++) {
    for (let tx = 0; tx < width; tx++) {
      const x0 = tx * size;
      const y0 = ty * size;
      if (wall(tx, ty)) {
        const openBelow = ty + 1 < height && !wall(tx, ty + 1);
        p.rect(x0, y0, size, size, CAVE.wall);
        if (openBelow) {
          // The visible rock face, lit from above.
          p.rect(x0, y0 + 4, size, size - 4, CAVE.wallFace);
          p.rect(x0, y0 + 4, size, 2, CAVE.wallTop);
          for (let i = 0; i < 3; i++) p.rect(x0 + rng.int(1, 13), y0 + rng.int(7, 13), 2, 1, CAVE.wallFaceDark);
        } else if (rng.chance(0.2)) {
          p.set(x0 + rng.int(2, 13), y0 + rng.int(2, 13), CAVE.wallFace);
        }
        continue;
      }
      p.rect(x0, y0, size, size, CAVE.floor);
      for (let i = 0; i < 7; i++) p.set(x0 + rng.int(0, 15), y0 + rng.int(0, 15), rng.chance(0.5) ? CAVE.floorDark : CAVE.floorLight);
      if (rng.chance(0.12)) p.rect(x0 + rng.int(2, 11), y0 + rng.int(2, 11), 3, 2, '#62564c');
      // Shadow under a wall above.
      if (ty > 0 && wall(tx, ty - 1)) p.rect(x0, y0, size, 3, CAVE.floorDark);
    }
  }
  return p.toCanvas();
}
