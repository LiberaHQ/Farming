import * as Phaser from 'phaser';
import {
  DEFAULT_WORLD_SEED,
  GAME_CONFIG,
  gameTime,
  isMachineKind,
  ITEMS,
  ITEM_IDS,
  MACHINES,
  MINE,
  NPCS,
  TERRAIN_NAMES,
  TIME_CONFIG,
  Terrain,
  formatClock,
  resolveAppearance,
  joinSave,
  type CoopPlayerState,
  type Direction,
  type ItemAmount,
  type ItemId,
  type MemberView,
  type SharedWorldState,
  type TradeOffer,
  type WorldOp,
  type NpcId,
  type TerrainType,
} from '@farming/shared';
import { repaintPlayer, TEXTURES } from '../assets/registerTextures';
import { GRASS_VARIANTS, TILE, TILE_MARGIN, TILE_SPACING, WATER_TILE_INDICES } from '../assets/tileIndex';
import { DEPTH, SCENES } from '../constants';
import { Player } from '../entities/Player';
import { gameCommands, gameEvents, type GameCommandMap, type PanelId } from '../events/GameEventBus';
import { drawWorldMap, MAP_SCALE } from '../maps/mapImage';
import { buildGroundIndices } from '../maps/tileResolver';
import { generateWorld } from '../maps/WorldGenerator';
import { terrainAt, type WorldData } from '../maps/WorldData';
import { barterWith, buyFrom, craft, offerFor, sellTo, stockFor, type TxResult } from '../state/economy';
import { Quests } from '../state/Quests';
import { Social } from '../state/Social';
import { PlayerState } from '../state/PlayerState';
import { LocalSaveStore, SAVE_VERSION, type SaveData, type SaveStore } from '../state/save';
import type { AppearanceChoice } from '@farming/shared';
import { AmbientLifeSystem } from '../systems/AmbientLifeSystem';
import { AnimalSystem } from '../systems/AnimalSystem';
import { FishingSystem } from '../systems/FishingSystem';
import { BuildSystem, type Placed } from '../systems/BuildSystem';
import { CameraSystem } from '../systems/CameraSystem';
import { DropSystem } from '../systems/DropSystem';
import { FarmingSystem } from '../systems/FarmingSystem';
import { FxSystem } from '../systems/FxSystem';
import { GrassRustleSystem } from '../systems/GrassRustleSystem';
import { InputSystem } from '../systems/InputSystem';
import { InteractionSystem } from '../systems/InteractionSystem';
import { LivestockSystem } from '../systems/LivestockSystem';
import { LightingSystem } from '../systems/LightingSystem';
import { NpcSystem, type Npc } from '../systems/NpcSystem';
import { OcclusionSystem } from '../systems/OcclusionSystem';
import { ResourceSystem } from '../systems/ResourceSystem';
import { TimeSystem } from '../systems/TimeSystem';
import { WaterGlintSystem } from '../systems/WaterGlintSystem';
import { WeatherSystem } from '../systems/WeatherSystem';
import { AudioSystem } from '../audio/AudioSystem';
import { bindAudio, sfx, unbindAudio, withSfxVolume } from '../audio/sfx';
import { LocalAuthority, ServerAuthority, type Authority } from '../net/Authority';
import type { CoopSession } from '../net/CoopSession';
import { RemotePlayerSystem } from '../systems/RemotePlayerSystem';
import type { MineHost, MineSceneData } from './MineScene';

interface WorldSceneData {
  seed?: string;
  /** Save to resume from (loaded by the app before the game starts). Null = new game. */
  save?: SaveData | null;
  /** Co-op: the shared world from the server, and this player's own progress. */
  coop?: CoopSceneData | null;
}

export interface CoopSceneData {
  session: CoopSession;
  shared: SharedWorldState;
  /** This player's progress in the world, or null on a first visit. */
  me: CoopPlayerState | null;
  members: MemberView[];
  /** Set when the scene restarts for a new co-op day. */
  morning?: { passedOut: boolean };
}

/** How often this player's own progress is reported to the co-op server. */
const COOP_STATE_MS = 3000;

const GROUND_TINT = { spring: 0xffffff, summer: 0xf4ffe6, fall: 0xf2cf8e, winter: 0xffffff } as const;

/** The playable overworld. Owns the map and wires the gameplay systems together. */
export class WorldScene extends Phaser.Scene {
  private seed = DEFAULT_WORLD_SEED;
  private world!: WorldData;
  private ground!: Phaser.Tilemaps.TilemapLayer;
  private player!: Player;
  private state!: PlayerState;
  private controls!: InputSystem;
  private occlusion!: OcclusionSystem;
  private rustle!: GrassRustleSystem;
  private drops!: DropSystem;
  private interaction!: InteractionSystem;
  private resources!: ResourceSystem;
  private farming!: FarmingSystem;
  private build!: BuildSystem;
  private animals!: AnimalSystem;
  private livestock!: LivestockSystem;
  private npcs!: NpcSystem;
  private time_!: TimeSystem;
  private weather!: WeatherSystem;
  private lighting!: LightingSystem;
  private audio!: AudioSystem;
  private fx!: FxSystem;
  private fishing!: FishingSystem;
  private ambient!: AmbientLifeSystem;
  private social!: Social;
  private quests!: Quests;
  /** Merchant whose trade panel is open. */
  private shopNpc: NpcId | null = null;
  private stepTimer = 0;
  private store: SaveStore = new LocalSaveStore();
  private initialSave: SaveData | null = null;
  private panel: PanelId | null = null;
  private sleeping = false;
  private lastTileKey = -1;
  private fpsElapsed = 0;
  private lastSavedAt: number | null = null;
  private coop: CoopSceneData | null = null;
  private authority: Authority = new LocalAuthority();
  private remotes: RemotePlayerSystem | null = null;
  private netOffs: Array<() => void> = [];
  private lastSentMove = '';
  private moveTimer = 0;
  private stateTimer = 0;
  private lastStateSig = '';
  private inBed = false;
  /** Down in the mine (the mine scene runs on top; this scene keeps the clock and menus). */
  private away = false;

  constructor() {
    super(SCENES.World);
  }

  init(data: WorldSceneData): void {
    this.seed = data.seed ?? DEFAULT_WORLD_SEED;
    this.initialSave = data.save ?? null;
    this.store = (this.registry.get('saveStore') as SaveStore | undefined) ?? new LocalSaveStore();
    this.lastTileKey = -1;
    this.panel = null;
    this.sleeping = false;
    this.coop = data.coop ?? null;
    this.authority = this.coop ? new ServerAuthority(this.coop.session) : new LocalAuthority();
    this.remotes = null;
    this.netOffs = [];
    this.inBed = false;
    this.lastStateSig = '';
    this.away = false;
  }

  create(): void {
    const { tileSize } = GAME_CONFIG;
    const { widthTiles, heightTiles } = GAME_CONFIG.world;
    this.world = generateWorld(this.seed, widthTiles, heightTiles);
    const save = this.coop ? this.coopSave(this.coop) : this.initialSave;
    const freshGuest = !!this.coop && !this.coop.me;
    this.lastSavedAt = save?.savedAt ?? null;

    // Tile layers: ground (collidable water), floor paths, tilled soil.
    const map = this.make.tilemap({ data: buildGroundIndices(this.world), tileWidth: tileSize, tileHeight: tileSize });
    const tileset = map.addTilesetImage(TEXTURES.tiles, TEXTURES.tiles, tileSize, tileSize, TILE_MARGIN, TILE_SPACING);
    if (!tileset) throw new Error('Tileset could not be created');
    const ground = map.createLayer(0, tileset, 0, 0);
    const floor = map.createBlankLayer('floor', tileset, 0, 0);
    const soil = map.createBlankLayer('soil', tileset, 0, 0);
    if (!ground || !floor || !soil) throw new Error('Tile layers could not be created');
    this.ground = ground.setDepth(DEPTH.ground);
    ground.setCollision(WATER_TILE_INDICES);

    const worldWidth = map.widthInPixels;
    const worldHeight = map.heightInPixels;
    this.physics.world.setBounds(0, 0, worldWidth, worldHeight);

    // Clock and weather come first: other systems spawn in the right season.
    // In co-op the server ends the day (and tells everyone), so passing out locally does nothing.
    this.time_ = new TimeSystem({ onTick: () => this.onClockTick(), onPassOut: () => (this.coop ? undefined : this.goToSleep(true)) });
    this.weather = new WeatherSystem(this, this.seed);
    if (save) this.time_.set(save.time.day, save.time.minute);
    this.weather.set(save?.weather ?? this.weather.forecast(this.time_.day));

    // Player state and entity.
    this.state = new PlayerState();
    if (save && !freshGuest) this.state.restore(save.player);
    else {
      // New worlds start with the look chosen on the player's profile.
      const look = this.registry.get('defaultAppearance') as AppearanceChoice | undefined;
      if (look) for (const part of Object.keys(look) as (keyof AppearanceChoice)[]) this.state.setAppearancePart(part, look[part]);
    }
    repaintPlayer(this, resolveAppearance(this.state.appearance));
    const door = this.doorPosition();
    this.player = new Player(this, save?.player.x ?? door.x, save?.player.y ?? door.y);

    // Systems.
    const fx = new FxSystem(this);
    this.fx = fx;
    this.drops = new DropSystem(this);
    this.occlusion = new OcclusionSystem();
    this.rustle = new GrassRustleSystem(this);
    this.farming = new FarmingSystem(this, this.world, soil, fx, this.drops);
    const obstacles = this.physics.add.staticGroup();
    this.build = new BuildSystem(this, this.world, floor, obstacles, this.occlusion, fx);
    this.resources = new ResourceSystem(this, this.world.width, {
      obstacles,
      occlusion: this.occlusion,
      rustle: this.rustle,
      fx,
      drops: this.drops,
      isTileReserved: (tx, ty) => this.farming.isTilled(tx, ty) || this.build.isBlocked(tx, ty),
      playerPosition: () => ({ x: this.player.x, y: this.player.y }),
      claim: (node, proceed) =>
        this.authority.request({ t: 'node', tx: node.spec.tx, ty: node.spec.ty }, proceed, () => {
          node.claiming = false;
        }),
    });
    this.resources.setCalendar(this.time_.day, this.time_.season);
    if (save) {
      this.resources.restore(save.resources);
      // Saves from before the village market: clear the market area and add its stalls and board.
      this.resources.clearArea(this.world.market);
      const { mine } = this.world;
      this.resources.clearArea({ x0: mine.tx - 1, y0: mine.ty - 1, x1: mine.tx + 2, y1: mine.ty + 1 });
      for (const spec of this.world.objects) if (spec.kind === 'stall' || spec.kind === 'board' || spec.kind === 'mine') this.resources.ensure(spec);
    } else this.resources.spawnAll(this.world.objects);

    if (save) {
      for (const p of save.placed) this.build.place(p.kind, p.tx, p.ty, p.items, p.machine, p.hay);
      this.farming.restore(save.farm);
    } else {
      this.build.place('cottage', this.world.home.tx, this.world.home.ty);
      this.prepareStarterPlot();
    }
    if (!this.build.at(this.world.home.tx, this.world.home.ty)) this.build.place('cottage', this.world.home.tx, this.world.home.ty);
    this.farming.setShelter((tx, ty) => this.build.isSheltered(tx, ty));
    this.build.refreshMachines(gameTime(this.time_.day, this.time_.minute));
    if (this.weather.isWet) this.farming.waterAll();

    this.animals = new AnimalSystem(
      this,
      this.world,
      (tx, ty) => this.resources.isBlocked(tx, ty) || this.build.isBlocked(tx, ty) || this.farming.isTilled(tx, ty),
      this.drops,
      fx,
    );
    this.animals.spawnRabbits(14);
    this.livestock = new LivestockSystem(this, fx, (tx, ty) => {
      const t = terrainAt(this.world, tx, ty);
      return (t === Terrain.Grass || t === Terrain.Path) && !this.resources.isBlocked(tx, ty) && !this.build.isBlocked(tx, ty) && !this.farming.isTilled(tx, ty);
    });
    this.livestock.restore(save?.livestock);
    for (const c of save?.chickens ?? []) this.animals.addChicken(c.x, c.y, { x: c.homeX, y: c.homeY });

    this.npcs = new NpcSystem(this, this.world);
    this.social = new Social();
    this.social.restore(save?.social);
    this.quests = new Quests(this.seed);
    this.quests.restore(save?.quests, this.time_.day, this.time_.season);
    this.fishing = new FishingSystem(this, this.player, this.state, this.drops, fx);
    this.ambient = new AmbientLifeSystem(this, this.world);

    new WaterGlintSystem(this, this.world);
    this.lighting = new LightingSystem(this);
    this.audio = new AudioSystem(this);
    bindAudio(this.audio);
    this.applySeasonTint();

    this.interaction = new InteractionSystem(this, {
      world: this.world,
      player: this.player,
      state: this.state,
      resources: this.resources,
      farming: this.farming,
      build: this.build,
      animals: this.animals,
      npcs: this.npcs,
      drops: this.drops,
      fx,
      fishing: this.fishing,
      social: this.social,
      authority: this.authority,
      livestock: this.livestock,
      calendar: () => ({ day: this.time_.day, minute: this.time_.minute, season: this.time_.season, weather: this.weather.current }),
      openShop: (npcId) => this.openShop(npcId),
      openBoard: () => this.openBoard(),
      boardRequests: () => this.quests.openCount(),
      talkTo: (npc) => this.talkTo(npc),
      giveGift: (npcId, slot) => this.giveGift(npcId, slot),
      rest: () => this.rest(),
      enterMine: () => this.openMineEntrance(),
      openChest: (placed: Placed) => {
        this.build.openChestUi(placed);
        this.setPanel('chest');
      },
      sleep: () => this.goToSleep(false),
      say: (speaker, text) => {
        gameEvents.emit('dialogue', { speaker, text });
        this.setPanel('dialogue');
      },
    });

    this.physics.add.collider(this.player.sprite, ground);
    this.physics.add.collider(this.player.sprite, obstacles);

    this.controls = new InputSystem(this);
    new CameraSystem(this, this.player.sprite, worldWidth, worldHeight);

    // Developer aid: toggle collision-box rendering with the backtick key.
    this.input.keyboard?.on('keydown-BACKTICK', this.toggleCollisionDebug, this);
    this.input.keyboard?.on('keydown-M', (e: KeyboardEvent) => {
      if (e.shiftKey) this.audio.toggleMute();
    });

    // Sync dependent visuals after Arcade Physics has moved bodies this frame.
    this.events.on(Phaser.Scenes.Events.POST_UPDATE, this.lateUpdate, this);

    // Save when the tab is hidden or closed.
    const saveOnHide = () => {
      if (document.visibilityState === 'hidden') this.saveGame(false, true);
    };
    const saveOnExit = () => this.saveGame(false, true);
    document.addEventListener('visibilitychange', saveOnHide);
    window.addEventListener('pagehide', saveOnExit);

    const unsubscribe = this.bindCommands();
    if (this.coop) this.startCoop(this.coop);
    // Restarting the scene fires SHUTDOWN; destroying the whole game fires DESTROY. Clean up once on either.
    let cleaned = false;
    const cleanup = () => {
      if (cleaned) return;
      cleaned = true;
      this.netOffs.forEach((off) => off());
      this.netOffs = [];
      this.events.off(Phaser.Scenes.Events.POST_UPDATE, this.lateUpdate, this);
      document.removeEventListener('visibilitychange', saveOnHide);
      window.removeEventListener('pagehide', saveOnExit);
      unsubscribe();
      unbindAudio(this.audio);
      this.audio.destroy();
    };
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, cleanup);
    this.events.once(Phaser.Scenes.Events.DESTROY, cleanup);

    gameEvents.emit('world:ready', {
      seed: this.seed,
      widthTiles,
      heightTiles,
      objectCount: this.world.objects.length,
    });
    this.state.emitAll();
    this.emitTime();
    this.emitSaveInfo();
    this.audio.emit();
    gameEvents.emit('ui:panel', { panel: null });
    if (this.coop?.morning) this.wakeUpTogether(this.coop.morning.passedOut);
    else if (this.coop) gameEvents.emit('toast', { text: `Joined ${this.coop.session.join.room.hostName}'s world. Day ${this.time_.dayOfSeason} of ${this.time_.season}.` });
    else if (save) gameEvents.emit('toast', { text: `Welcome back! Day ${this.time_.dayOfSeason} of ${this.time_.season}.` });
  }

  update(_time: number, delta: number): void {
    const actions = this.controls.getActions();
    const inventory = this.state.inventory;

    if (actions.hotbar !== null) inventory.select(actions.hotbar);
    if (actions.close) this.setPanel(this.panel ? null : 'menu');
    if (actions.toggleInventory) this.togglePanel('inventory');
    if (actions.toggleCrafting) this.togglePanel('crafting');
    if (actions.toggleMap && this.away) gameEvents.emit('toast', { text: "There's no map of the mine." });
    else if (actions.toggleMap) {
      if (this.panel === 'map') this.setPanel(null);
      else if (!this.panel || this.panel === 'inventory' || this.panel === 'crafting') this.openMap();
    }
    if (this.panel === 'dialogue' && (actions.use || actions.interact)) this.setPanel(null);

    const frozen = this.panel !== null || this.sleeping;
    // Alone, menus pause the world; in co-op the server's clock keeps running.
    this.time_.running = this.coop ? true : !frozen;
    if (this.coop && this.inBed) {
      const intent = this.controls.getMoveIntent();
      if (intent.x !== 0 || intent.y !== 0) this.leaveBed();
    }
    if (frozen) {
      this.player.stop();
    } else if (this.away) {
      // In the mine: that scene moves the player and handles Use/Interact.
      if (actions.cycle !== 0) inventory.cycle(actions.cycle);
      if (actions.eat) this.interaction.eatSlot(inventory.selected);
      this.player.stop();
    } else {
      if (actions.cycle !== 0) inventory.cycle(actions.cycle);
      if (actions.use) this.interaction.use();
      else if (actions.interact) this.interaction.interact();
      else if (actions.eat) this.interaction.eatSlot(inventory.selected);
      const intent = this.controls.getMoveIntent();
      // Walking away reels the line in.
      if (this.fishing.active && (intent.x !== 0 || intent.y !== 0)) this.fishing.cancel();
      this.player.update(intent);
    }

    this.time_.update(delta);
    this.drops.update(delta, this.player.x, this.player.y, inventory);
    if (!this.away) this.audio.update(delta, { minute: this.time_.minute, weather: this.weather.current, season: this.time_.season });
    this.playFootsteps(delta, frozen);
    const night = LightingSystem.darkness(this.time_.minute) > 0.5;
    if (!frozen) {
      this.animals.update(delta, this.player.x, this.player.y, night);
      this.livestock.update(delta, night);
      this.npcs.update(delta, this.time_.minute, { x: this.player.x, y: this.player.y });
      this.fishing.update(delta);
    }
    if (this.coop) this.coopUpdate(delta);
    this.ambient.update(delta, {
      minute: this.time_.minute,
      season: this.time_.season,
      weather: this.weather.current,
      darkness: LightingSystem.darkness(this.time_.minute),
    });

    this.fpsElapsed += delta;
    if (this.fpsElapsed >= 500) {
      this.fpsElapsed = 0;
      gameEvents.emit('perf:fps', { fps: this.game.loop.actualFps });
    }
  }

  private lateUpdate(): void {
    this.player.lateUpdate();
    this.occlusion.update(this.player.x, this.player.y);
    if (!this.away) this.interaction.update(this.panel === null && !this.sleeping);

    const lights = this.build.lights();
    if (LightingSystem.darkness(this.time_.minute) > 0.3) lights.push({ x: this.player.x, y: this.player.y - 10, radius: 40 });
    this.lighting.update(this.time_.minute, this.weather.current, lights);

    const { tx, ty } = this.player.tile;
    const tileKey = ty * this.world.width + tx;
    if (tileKey !== this.lastTileKey) {
      this.lastTileKey = tileKey;
      this.rustle.onPlayerEnterTile(tx, ty, this.player.velocityX);
      const terrain = terrainAt(this.world, tx, ty);
      if (terrain >= 0) gameEvents.emit('player:tile', { tx, ty, terrain: TERRAIN_NAMES[terrain as TerrainType] });
    }
  }

  /** New games start with a small tilled plot near the cottage, ready for seeds. */
  private prepareStarterPlot(): void {
    const { home } = this.world;
    const free = (tx: number, ty: number) =>
      this.farming.canTill(tx, ty) && !this.resources.isBlocked(tx, ty) && !this.build.isBlocked(tx, ty);
    // Search outward from beside the cottage for a clear 3x3 patch.
    for (let r = 0; r <= 6; r++) {
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
          const x0 = home.tx + 4 + dx;
          const y0 = home.ty + dy;
          let ok = true;
          for (let y = y0; y < y0 + 3 && ok; y++) for (let x = x0; x < x0 + 3 && ok; x++) ok = free(x, y);
          if (!ok) continue;
          for (let y = y0; y < y0 + 3; y++) for (let x = x0; x < x0 + 3; x++) this.farming.till(x, y, true);
          return;
        }
      }
    }
  }

  /** Renders the world map from the current state and opens it. */
  private openMap(): void {
    const canvas = drawWorldMap(this.world, {
      season: this.time_.season,
      objects: this.resources.markers(),
      placed: this.build.serialize().map(({ kind, tx, ty }) => ({ kind, tx, ty })),
      plots: this.farming.markers(),
      people: [...this.npcs.positions(), ...(this.remotes?.positions() ?? [])],
      chickens: this.animals.serializeChickens(),
    });
    const toMap = (x: number, y: number) => ({ x: (x / GAME_CONFIG.tileSize) * MAP_SCALE, y: (y / GAME_CONFIG.tileSize) * MAP_SCALE });
    const { home } = this.world;
    gameEvents.emit('map:image', {
      url: canvas.toDataURL(),
      width: canvas.width,
      height: canvas.height,
      player: toMap(this.player.x, this.player.y),
      home: toMap((home.tx + 1.5) * GAME_CONFIG.tileSize, home.ty * GAME_CONFIG.tileSize),
    });
    this.setPanel('map');
  }

  /** Soft footsteps whose sound depends on the ground underfoot. */
  private playFootsteps(delta: number, frozen: boolean): void {
    const v = this.player.sprite.body.velocity;
    const speed = Math.hypot(v.x, v.y);
    if (frozen || speed < 1) {
      this.stepTimer = 0;
      return;
    }
    this.stepTimer -= delta;
    if (this.stepTimer > 0) return;
    const running = speed > GAME_CONFIG.player.walkSpeed + 5;
    this.stepTimer = running ? 200 : 290;
    const { tx, ty } = this.player.tile;
    const terrain = terrainAt(this.world, tx, ty);
    const onFloor = this.build.at(tx, ty);
    const wooden = terrain === Terrain.Bridge || onFloor?.kind === 'wood_path';
    const hard = terrain === Terrain.Path || onFloor?.kind === 'stone_path';
    const rate = wooden ? 0.65 : hard ? 1.35 : 1;
    sfx('step', { volume: this.time_.season === 'winter' && terrain === Terrain.Grass ? 0.5 : 0.35, rate, vary: 0.15 });
  }

  // ---------- Time ----------

  private onClockTick(): void {
    this.build.refreshMachines(gameTime(this.time_.day, this.time_.minute));
    if (this.weather.isWet) this.farming.waterAll();
    if (this.panel === 'shop' && this.shopNpc && !this.npcs.isPresent(this.shopNpc, this.time_.minute)) {
      gameEvents.emit('toast', { text: `${NPCS[this.shopNpc].name} is closing up for the day.` });
      this.setPanel(null);
    }
    this.emitTime();
  }

  /** Bedtime (or collapsing at 2am): fade out, start a new day at home, save, fade in. */
  private goToSleep(passedOut: boolean): void {
    if (this.away) this.leaveMine('quiet');
    if (this.coop) {
      this.enterBed();
      return;
    }
    if (this.sleeping) return;
    this.sleeping = true;
    this.setPanel(null);
    sfx('sleep');
    const camera = this.cameras.main;
    camera.fadeOut(700, 0, 0, 0);
    camera.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => {
      const previousSeason = this.time_.season;
      this.time_.startNewDay();
      const season = this.time_.season;
      const seasonChanged = season !== previousSeason;
      this.weather.set(this.weather.forecast(this.time_.day));

      const withered = this.farming.onNewDay(season, seasonChanged, this.weather.isWet);
      this.resources.onNewDay(this.time_.day, season);
      this.animals.onNewDay();
      this.livestock.morning(this.build.ofKind('barn'));
      const sprinkled = this.runSprinklers();
      this.quests.setDay(this.time_.day, season);
      if (seasonChanged) this.applySeasonTint();

      const { passOutRestore } = GAME_CONFIG.energy;
      this.state.setEnergyFraction(passedOut ? passOutRestore : 1);
      this.state.heal(this.state.maxHealth);
      const door = this.doorPosition();
      this.player.placeAt(door.x, door.y, 'down');
      this.time_.running = true;
      this.emitTime();
      this.saveGame(false);

      this.time.delayedCall(250, () => {
        camera.fadeIn(700, 0, 0, 0);
        this.sleeping = false;
        sfx('morning');
        const day = `Day ${this.time_.dayOfSeason} of ${season}`;
        if (passedOut) gameEvents.emit('toast', { text: `You passed out and woke up at home, still tired. ${day}.` });
        else gameEvents.emit('toast', { text: `Good morning! ${day}, ${this.weather.current}.` });
        if (seasonChanged) gameEvents.emit('toast', { text: `${season[0].toUpperCase()}${season.slice(1)} has arrived!` });
        if (withered > 0) gameEvents.emit('toast', { text: `${withered} out-of-season crop${withered > 1 ? 's' : ''} withered.` });
        if (sprinkled > 0) gameEvents.emit('toast', { text: `Your sprinklers watered ${sprinkled} plot${sprinkled > 1 ? 's' : ''}.` });
        if (this.quests.openCount() > 0) gameEvents.emit('toast', { text: 'New requests are up on the village notice board.' });
      });
    });
  }

  private doorPosition(): { x: number; y: number } {
    const size = GAME_CONFIG.tileSize;
    return { x: (this.world.home.tx + 1) * size + size / 2, y: (this.world.home.ty + 1) * size + 12 };
  }

  /** Grass tints with the seasons; in winter it is swapped for snow-covered tiles. */
  private applySeasonTint(): void {
    const season = this.time_.season;
    const tint = GROUND_TINT[season];
    const { width, groundVariant } = this.world;
    this.ground.forEachTile((tile) => {
      const grass = tile.index < 16 || (tile.index >= TILE.SNOW_START && tile.index < TILE.SNOW_START + GRASS_VARIANTS);
      if (!grass) return;
      const v = groundVariant[tile.y * width + tile.x];
      if (season === 'winter') tile.index = TILE.SNOW_START + (v < GRASS_VARIANTS ? v : v % 4);
      else tile.index = v < GRASS_VARIANTS ? TILE.GRASS_START + v : TILE.FLOWER_START + (v - GRASS_VARIANTS);
      tile.tint = tint;
    });
  }

  private emitTime(): void {
    gameEvents.emit('world:time', {
      day: this.time_.day,
      year: this.time_.year,
      season: this.time_.season,
      dayOfSeason: this.time_.dayOfSeason,
      minute: this.time_.minute,
      clock: formatClock(this.time_.minute),
      weather: this.weather.current,
      shopOpen: this.npcs?.isPresent('mira', this.time_.minute) ?? false,
    });
  }

  // ---------- Saving ----------

  private saveGame(announce: boolean, urgent = false): void {
    if (!this.state) return;
    if (this.coop) {
      // The server keeps the shared world; we report our own progress.
      this.reportState(true);
      if (announce) gameEvents.emit('toast', { text: 'Your progress is saved with the shared world.' });
      return;
    }
    const data = this.buildSave();
    void this.store.save(data, { urgent }).then((result) => {
      if (result.ok) this.lastSavedAt = data.savedAt;
      this.emitSaveInfo();
      if (urgent) return;
      const toast = (text: string) => gameEvents.emit('toast', { text });
      const expectsCloud = !(this.store instanceof LocalSaveStore);
      if (result.where === 'none') toast('Could not save (browser storage unavailable)');
      else if (expectsCloud && result.where === 'local') toast("Couldn't reach the server — saved in this browser for now");
      else if (announce) toast(result.where === 'cloud' ? 'Game saved to your account' : 'Game saved in this browser');
    });
  }

  /** The full current state as a save. */
  private buildSave(): SaveData {
    return {
      version: SAVE_VERSION,
      seed: this.seed,
      savedAt: Date.now(),
      time: { day: this.time_.day, minute: this.time_.minute },
      weather: this.weather.current,
      player: { ...this.state.serialize(), x: Math.round(this.player.x), y: Math.round(this.player.y), facing: this.player.facingDirection as Direction },
      resources: this.resources.serialize(),
      farm: this.farming.serialize(),
      placed: this.build.serialize().filter((p) => p.kind !== 'cottage'),
      chickens: this.animals.serializeChickens(),
      livestock: this.livestock.serialize(),
      social: this.social.serialize(),
      quests: this.quests.serialize(),
    };
  }

  private emitSaveInfo(): void {
    gameEvents.emit('save:info', { hasSave: this.lastSavedAt !== null, savedAt: this.lastSavedAt, storage: this.store.description });
  }

  // ---------- UI ----------

  private setPanel(panel: PanelId | null): void {
    if (panel === this.panel) return;
    if (panel) this.fishing?.cancel();
    // Closing the trade window (Esc, ✕) cancels the trade.
    if (this.panel === 'trade' && panel !== 'trade') this.coop?.session.send('trade:cancel');
    if (this.panel === 'shop' && panel !== 'shop') this.shopNpc = null;
    if (this.panel === 'chest') this.build.openChest = null;
    if (panel === 'dialogue') sfx('talk');
    else if (panel) sfx('uiOpen');
    else if (this.panel && this.panel !== 'dialogue') sfx('uiClose');
    this.panel = panel;
    gameEvents.emit('ui:panel', { panel });
  }

  private togglePanel(panel: PanelId): void {
    this.setPanel(this.panel === panel ? null : panel);
  }

  /** Commands from the React UI. All validation happens here, not in React. */
  private bindCommands(): () => void {
    const report = (result: TxResult, success: 'coin' | 'craft' = 'coin') => {
      gameEvents.emit('toast', { text: result.message });
      sfx(result.ok ? success : 'error');
    };
    const handlers: { [K in keyof GameCommandMap]: (payload: GameCommandMap[K]) => void } = {
      'inventory:select': ({ index }) => this.state.inventory.select(index),
      'inventory:move': ({ from, to }) => this.state.inventory.move(from, to),
      craft: ({ recipeId }) => report(craft(this.state, recipeId), 'craft'),
      'shop:buy': ({ itemId, quantity }) => {
        const npc = this.shopNpc;
        if (this.panel !== 'shop' || !npc) return;
        report(buyFrom(this.state, npc, itemId, quantity, this.time_.season, this.social.pointsOf(npc)));
        this.emitShop();
      },
      'shop:sell': ({ slot, quantity }) => {
        const npc = this.shopNpc;
        if (this.panel !== 'shop' || !npc) return;
        report(sellTo(this.state, npc, slot, quantity));
        this.emitShop();
      },
      'shop:barter': ({ index }) => {
        const npc = this.shopNpc;
        if (this.panel !== 'shop' || !npc) return;
        report(barterWith(this.state, npc, index), 'craft');
        this.emitShop();
      },
      'shop:gift': ({ slot }) => {
        const npc = this.shopNpc;
        if (this.panel !== 'shop' || !npc || !Number.isInteger(slot)) return;
        this.giveGift(npc, slot);
        this.emitShop();
      },
      'board:deliver': ({ index }) => {
        if (this.panel !== 'board') return;
        const result = this.quests.deliver(index, this.state, this.social);
        gameEvents.emit('toast', { text: result.message });
        sfx(result.ok ? 'quest' : 'error');
        this.emitBoard();
      },
      'ui:open': ({ panel }) => {
        if (panel === 'map' && this.away) gameEvents.emit('toast', { text: "There's no map of the mine." });
        else if (panel === 'map') this.openMap();
        else if (panel === 'inventory' || panel === 'crafting' || panel === 'character' || panel === 'menu') this.setPanel(panel);
      },
      'mine:enter': ({ floor }) => {
        if (this.panel !== 'mine' || this.away) return;
        if (!this.elevatorFloors().includes(floor)) return;
        this.enterMine(floor);
      },
      'item:eat': ({ slot }) => {
        if (Number.isInteger(slot) && !this.sleeping) this.interaction.eatSlot(slot);
      },
      'ui:close': () => this.setPanel(null),
      'chest:transfer': ({ from, slot }) => this.transferChest(from, slot),
      'appearance:set': ({ part, index }) => {
        if (this.state.setAppearancePart(part, index)) repaintPlayer(this, resolveAppearance(this.state.appearance));
      },
      'game:save': () => this.saveGame(true),
      'game:flush': () => this.saveGame(false, true),
      'audio:set': ({ channel, value }) => this.audio.set(channel, value),
      'audio:mute': () => this.audio.toggleMute(),
      'action:perform': ({ trigger }) => {
        if (this.panel || this.sleeping) return;
        if (trigger === 'use') this.interaction.use();
        else this.interaction.interact();
      },
      'coop:host': () => {
        if (this.coop) return void gameEvents.emit('toast', { text: `Friends can join with code ${this.coop.session.join.room.code}.` });
        gameEvents.emit('coop:hostRequest', { save: this.buildSave() });
      },
      'chat:send': ({ text }) => this.coop?.session.send('chat:send', { text }),
      'input:typing': ({ typing }) => this.setTyping(typing),
      'trade:request': ({ to }) => this.coop?.session.send('trade:request', { to }),
      'trade:respond': ({ from, accept }) => this.coop?.session.send('trade:respond', { from, accept }),
      'trade:offer': (offer) => this.coop?.session.send('trade:offer', offer),
      'trade:confirm': () => this.coop?.session.send('trade:confirm'),
      'trade:cancel': () => {
        this.coop?.session.send('trade:cancel');
        if (this.panel === 'trade') this.setPanel(null);
      },
      'game:new': () => {
        if (this.coop) return void gameEvents.emit('toast', { text: "You can't restart a shared world." });
        void this.store.clear(this.seed).then(() => {
          this.lastSavedAt = null;
          gameEvents.reset();
          this.scene.restart({ seed: this.seed, save: null });
        });
      },
    };
    const offs = (Object.keys(handlers) as (keyof GameCommandMap)[]).map((name) =>
      gameCommands.on(name, handlers[name] as (payload: GameCommandMap[typeof name]) => void),
    );
    return () => offs.forEach((off) => off());
  }

  // ---------- Co-op ----------

  /** A save built from the server's shared world and this player's own progress. */
  private coopSave(coop: CoopSceneData): SaveData {
    const me: CoopPlayerState = coop.me ?? {
      player: { ...new PlayerState().serialize(), ...this.doorPosition(), facing: 'down' },
    };
    return joinSave(coop.shared, me, SAVE_VERSION, Date.now());
  }

  /** Hooks up the network: other players, the shared world, chat and trading. */
  private startCoop(coop: CoopSceneData): void {
    const { session } = coop;
    const self = session.selfId;
    const room = session.join.room;
    this.remotes = new RemotePlayerSystem(this, self);
    this.remotes.setMembers(coop.members);
    for (const d of coop.shared.drops) this.drops.spawnShared(d.id, d.itemId, d.quantity, d.x, d.y);
    this.drops.setClaimer((id, done) => this.authority.request({ t: 'drop', id }, (g) => done(g.grant ?? null), () => done(null)));
    this.player.onToolUse = (style, texture) => session.send('player:anim', { kind: style, item: texture ? (texture.replace(/^item-/, '') as ItemId) : null });

    const on: CoopSession['on'] = (event, listener) => {
      const off = session.on(event, listener);
      this.netOffs.push(off);
      return off;
    };
    on('room:members', (members) => {
      coop.members = members;
      this.remotes?.setMembers(members);
      gameEvents.emit('coop:members', members);
    });
    on('room:positions', (positions) => this.remotes?.setPositions(positions));
    on('player:anim', ({ id, kind, item }) => this.remotes?.anim(id, kind, item));
    on('player:correct', ({ x, y }) => this.player.placeAt(x, y, this.player.facingDirection));
    on('world:op', ({ op }) => this.applyRemoteOp(op));
    on('world:chest', ({ tx, ty, items }) => this.build.setChestItems(tx, ty, items));
    on('world:time', ({ day, minute, weather }) => {
      if (day !== this.time_.day) return; // a new day is on its way
      this.time_.set(day, minute);
      if (weather !== this.weather.current) {
        this.weather.set(weather);
        if (this.weather.isWet) this.farming.waterAll();
      }
      this.emitTime();
    });
    on('world:newday', ({ shared, passedOut }) => this.startCoopMorning(shared, passedOut.includes(self)));
    on('chat:message', (m) => gameEvents.emit('chat:message', m));
    on('notice', ({ text }) => gameEvents.emit('toast', { text }));
    on('sleep:status', (s) => gameEvents.emit('coop:sleep', s.inBed > 0 ? s : null));
    on('room:closed', ({ reason }) => this.endCoop(reason));
    on('trade:incoming', (p) => {
      sfx('talk');
      gameEvents.emit('trade:incoming', p);
    });
    on('trade:state', (t) => {
      gameEvents.emit('trade:state', t);
      if (t && this.panel !== 'trade') this.setPanel('trade');
      else if (!t && this.panel === 'trade') this.setPanel(null);
    });
    on('trade:commit', ({ id, give }) => {
      const ok = this.handOver(give);
      session.send('trade:ack', { id, ok });
      this.reportState(true);
    });
    on('trade:deliver', ({ receive }) => {
      this.receive(receive);
      sfx('coin');
      gameEvents.emit('toast', { text: 'Trade complete!' });
      this.reportState(true);
    });
    on('trade:refund', ({ refund }) => {
      this.receive(refund);
      this.reportState(true);
    });

    gameEvents.emit('coop:info', { code: room.code, seed: room.seed, hostName: room.hostName, selfId: self, host: session.join.members.find((m) => m.id === self)?.host ?? false });
    gameEvents.emit('coop:members', coop.members);
    gameEvents.emit('coop:sleep', null);
    gameEvents.emit('trade:state', null);
    this.reportState(true);
  }

  /** Sends position updates and progress reports at a steady rate. */
  private coopUpdate(delta: number): void {
    this.remotes?.update(delta);
    const session = this.coop!.session;
    this.moveTimer -= delta;
    if (this.moveTimer <= 0) {
      this.moveTimer = 1000 / 10;
      const v = this.player.sprite.body.velocity;
      const moving = Math.hypot(v.x, v.y) > 1 ? 1 : 0;
      const x = Math.round(this.player.x * 10) / 10;
      const y = Math.round(this.player.y * 10) / 10;
      const f = this.player.facingDirection;
      const sig = `${x},${y},${f},${moving}`;
      if (sig !== this.lastSentMove) {
        this.lastSentMove = sig;
        session.send('player:move', { x, y, f, m: moving });
      }
    }
    this.stateTimer -= delta;
    if (this.stateTimer <= 0) {
      this.stateTimer = COOP_STATE_MS;
      this.reportState(false);
    }
  }

  /** Reports this player's own progress (backpack, gold…) if it changed. */
  private reportState(force: boolean): void {
    if (!this.coop || !this.state) return;
    const state: CoopPlayerState = {
      player: { ...this.state.serialize(), x: Math.round(this.player.x), y: Math.round(this.player.y), facing: this.player.facingDirection as Direction },
      social: this.social.serialize(),
      quests: this.quests.serialize(),
    };
    const sig = JSON.stringify(state);
    if (!force && sig === this.lastStateSig) return;
    this.lastStateSig = sig;
    this.coop.session.send('player:state', state);
  }

  /** Co-op bedtime: the day ends when everyone is in bed (or at 2am). */
  private enterBed(): void {
    if (this.inBed || !this.coop) return;
    this.inBed = true;
    this.sleeping = true;
    this.player.stop();
    this.setPanel(null);
    sfx('sleep');
    this.cameras.main.fadeOut(600, 0, 0, 0);
    this.coop.session.send('sleep:set', { inBed: true });
    const others = this.coop.members.length - 1;
    gameEvents.emit('toast', { text: others > 0 ? 'Waiting for everyone to go to bed… (move to get up)' : 'Good night…' });
  }

  private leaveBed(): void {
    if (!this.inBed || !this.coop) return;
    this.inBed = false;
    this.sleeping = false;
    this.cameras.main.fadeIn(400, 0, 0, 0);
    this.coop.session.send('sleep:set', { inBed: false });
  }

  /** The server started a new day: restart from its world, keeping our own progress. */
  private startCoopMorning(shared: SharedWorldState, passedOut: boolean): void {
    if (!this.coop) return;
    if (this.away) this.leaveMine('quiet');
    this.sleeping = true;
    this.setPanel(null);
    this.reportState(true);
    const door = this.doorPosition();
    const me: CoopPlayerState = {
      player: { ...this.state.serialize(), x: door.x, y: door.y, facing: 'down' },
      social: this.social.serialize(),
      quests: this.quests.serialize(),
    };
    const restart = () => this.scene.restart({ seed: this.seed, coop: { ...this.coop!, shared, me, morning: { passedOut } } });
    if (this.inBed) restart();
    else {
      this.cameras.main.fadeOut(500, 0, 0, 0);
      this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, restart);
    }
  }

  /** First frame of a new co-op day. */
  private wakeUpTogether(passedOut: boolean): void {
    const { passOutRestore } = GAME_CONFIG.energy;
    this.state.setEnergyFraction(passedOut ? passOutRestore : 1);
    this.state.heal(this.state.maxHealth);
    this.cameras.main.fadeIn(700, 0, 0, 0);
    sfx('morning');
    const day = `Day ${this.time_.dayOfSeason} of ${this.time_.season}`;
    gameEvents.emit('toast', { text: passedOut ? `You passed out and woke up at home, still tired. ${day}.` : `Good morning! ${day}, ${this.weather.current}.` });
    const sprinkled = this.build.ofKind('sprinkler').length;
    if (sprinkled > 0) gameEvents.emit('toast', { text: 'The sprinklers watered the fields.' });
    this.reportState(true);
  }

  /** The room closed (host left, server restarting…): stop and tell the player. */
  private endCoop(reason: string): void {
    if (this.away) this.leaveMine('quiet');
    this.sleeping = true;
    this.setPanel(null);
    this.player.stop();
    gameEvents.emit('coop:ended', { reason });
  }

  /** Another player changed the shared world: mirror it here (quieter when it happens far away). */
  private applyRemoteOp(op: WorldOp): void {
    const size = GAME_CONFIG.tileSize;
    const x = 'tx' in op ? op.tx * size + 8 : 'x' in op ? op.x : this.player.x;
    const y = 'ty' in op ? op.ty * size + 8 : 'y' in op ? op.y : this.player.y;
    const distance = Math.hypot(x - this.player.x, y - this.player.y);
    const volume = distance > 240 ? 0 : distance > 80 ? 0.4 : 0.8;
    withSfxVolume(volume, () => {
      const plot = 'tx' in op ? this.farming.plotAt(op.tx, op.ty) : undefined;
      switch (op.t) {
        case 'till':
          if (this.farming.canTill(op.tx, op.ty)) this.farming.till(op.tx, op.ty);
          break;
        case 'untill':
          if (plot) this.farming.untill(plot);
          break;
        case 'plant':
          if (plot && !plot.crop) this.farming.plant(plot, op.crop);
          break;
        case 'water':
          if (plot && !plot.watered) this.farming.water(plot);
          break;
        case 'fertilize':
          if (plot) this.farming.fertilize(plot);
          break;
        case 'harvest':
          if (plot) this.farming.harvest(plot, false);
          break;
        case 'node':
          this.resources.destroyAt(op.tx, op.ty);
          break;
        case 'berries': {
          const node = this.resources.nodeAt(op.tx, op.ty);
          if (node) this.resources.pickBerries(node, false);
          break;
        }
        case 'place':
          if (!this.build.at(op.tx, op.ty)) {
            this.build.place(op.kind, op.tx, op.ty);
            sfx('place');
          }
          break;
        case 'pickup': {
          const placed = this.build.at(op.tx, op.ty);
          if (placed) this.build.remove(placed);
          break;
        }
        case 'chicken':
          this.animals.addChicken(op.x, op.y);
          break;
        case 'drop':
          this.drops.removeShared(op.id);
          break;
        case 'machineLoad': {
          const placed = this.build.at(op.tx, op.ty);
          if (placed && isMachineKind(placed.kind) && op.readyAt !== undefined) {
            this.build.setMachine(placed, { input: op.itemId, output: MACHINES[placed.kind].output, readyAt: op.readyAt }, gameTime(this.time_.day, this.time_.minute));
          }
          break;
        }
        case 'livestock': {
          const barn = { tx: op.barnTx, ty: op.barnTy };
          if (op.id !== undefined && !this.livestock.get(op.id)) this.livestock.create(op.kind, barn, op.id, op.name);
          break;
        }
        case 'animalPet':
          this.livestock.pet(op.id, this.time_.day);
          break;
        case 'animalCollect':
          this.livestock.collect(op.id);
          break;
        case 'barnFeed': {
          const barn = this.build.at(op.tx, op.ty);
          if (barn) barn.hay = (barn.hay ?? 0) + op.quantity;
          break;
        }
        case 'machineCollect': {
          const placed = this.build.at(op.tx, op.ty);
          if (placed) this.build.setMachine(placed, null, gameTime(this.time_.day, this.time_.minute));
          break;
        }
      }
    });
  }

  /** Moving items in and out of a shared chest: the server holds its contents. */
  private transferSharedChest(from: 'chest' | 'inventory', slot: number): void {
    const placed = this.build.openChest;
    const inv = this.state.inventory;
    if (!placed?.storage) return;
    const { tx, ty } = placed;
    if (from === 'inventory') {
      const stack = inv.slots[slot];
      if (!stack) return;
      this.authority.request({ t: 'chestPut', tx, ty, itemId: stack.itemId, quantity: stack.quantity }, (g) => {
        const current = inv.slots[slot];
        if (current?.itemId === stack.itemId) inv.removeAt(slot, g.accepted ?? 0);
        else inv.remove(stack.itemId, g.accepted ?? 0);
      });
    } else {
      const stack = placed.storage.slots[slot];
      if (!stack) return;
      const room = inv.capacityFor(stack.itemId);
      if (room === 0) return void gameEvents.emit('toast', { text: `No room for ${ITEMS[stack.itemId].name}` });
      this.authority.request({ t: 'chestTake', tx, ty, slot, max: Math.min(room, stack.quantity) }, (g) => {
        if (!g.grant) return;
        const leftover = inv.add(g.grant.itemId, g.grant.quantity);
        if (leftover > 0) this.drops.spawn(g.grant.itemId, leftover, this.player.x, this.player.y + 4);
      });
    }
  }

  /** Trade: hand over our side. False if we no longer have it all (nothing is removed then). */
  private handOver(offer: TradeOffer): boolean {
    const inv = this.state.inventory;
    const totals = new Map<ItemId, number>();
    for (const it of offer.items) totals.set(it.itemId, (totals.get(it.itemId) ?? 0) + it.quantity);
    for (const [itemId, q] of totals) if (inv.count(itemId) < q) return false;
    if (offer.gold > this.state.gold) return false;
    for (const [itemId, q] of totals) inv.remove(itemId, q);
    if (offer.gold > 0) this.state.spendGold(offer.gold);
    return true;
  }

  /** Trade: take items and gold (anything that doesn't fit lands at our feet). */
  private receive(offer: TradeOffer): void {
    for (const it of offer.items as ItemAmount[]) {
      const leftover = this.state.inventory.add(it.itemId, it.quantity);
      if (leftover > 0) this.drops.spawn(it.itemId, leftover, this.player.x, this.player.y + 4);
      if (it.quantity - leftover > 0) gameEvents.emit('item:collected', { itemId: it.itemId, quantity: it.quantity - leftover });
    }
    this.state.receiveGold(offer.gold);
  }

  /** While a text field (chat) has focus, the game ignores the keyboard. */
  private setTyping(typing: boolean): void {
    const keyboard = this.input?.keyboard;
    if (!keyboard?.manager || !this.sys.isActive()) return;
    keyboard.enabled = !typing;
    if (typing) keyboard.disableGlobalCapture();
    else {
      keyboard.enableGlobalCapture();
      keyboard.resetKeys();
    }
  }

  // ---------- The mine ----------

  /** Floors the elevator can take you to: 1, and every 5th floor you've reached. */
  private elevatorFloors(): number[] {
    const floors = [1];
    for (let f = MINE.elevatorEvery; f <= this.state.mineDepth; f += MINE.elevatorEvery) floors.push(f);
    return floors;
  }

  private openMineEntrance(): void {
    const floors = this.elevatorFloors();
    if (floors.length === 1) return this.enterMine(1);
    gameEvents.emit('mine:elevator', { floors });
    this.setPanel('mine');
  }

  private enterMine(floor: number): void {
    if (this.away) return;
    this.setPanel(null);
    this.fishing.cancel();
    this.player.stop();
    this.away = true;
    this.interaction.update(false);
    const host: MineHost = {
      state: this.state,
      isFrozen: () => this.panel !== null || this.sleeping,
      exit: ({ fainted }) => this.leaveMine(fainted ? 'fainted' : 'climbed'),
    };
    this.cameras.main.fadeOut(300, 0, 0, 0);
    this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => {
      this.cameras.main.setVisible(false);
      this.scene.launch(SCENES.Mine, { floor, host } satisfies MineSceneData);
    });
    sfx('step', { rate: 0.6 });
  }

  /** Back above ground: climbed out, fainted, or pulled out by the day ending. */
  private leaveMine(how: 'climbed' | 'fainted' | 'quiet'): void {
    if (!this.away) return;
    this.away = false;
    this.scene.stop(SCENES.Mine);
    gameEvents.emit('mine:floor', null);
    const camera = this.cameras.main;
    camera.setVisible(true);
    if (how === 'quiet') return;
    const size = GAME_CONFIG.tileSize;
    if (how === 'fainted') {
      const lost = Math.min(MINE.faintGoldLossMax, Math.floor(this.state.gold * MINE.faintGoldLoss));
      if (lost > 0) this.state.spendGold(lost);
      this.state.heal(Math.round(this.state.maxHealth * 0.4));
      const door = this.doorPosition();
      this.player.placeAt(door.x, door.y, 'down');
      gameEvents.emit('toast', { text: `Someone carried you home from the mine.${lost > 0 ? ` You lost ${lost}g on the way.` : ''}` });
    } else {
      const { mine } = this.world;
      this.player.placeAt((mine.tx + 1) * size, (mine.ty + 1) * size + 12, 'down');
    }
    camera.fadeIn(500, 0, 0, 0);
  }

  // ---------- Village ----------

  private openShop(npcId: NpcId): void {
    if (!NPCS[npcId].shop) return;
    // Visiting the stall counts as today's chat.
    const { before, after } = this.social.talk(npcId, this.time_.day);
    this.shopNpc = npcId;
    this.emitShop();
    this.setPanel('shop');
    const npc = this.npcs.get(npcId);
    if (npc) this.npcs.face(npc, { x: this.player.x, y: this.player.y });
    if (after > before) this.heartUp(npcId);
  }

  private emitShop(): void {
    const id = this.shopNpc;
    if (!id) return;
    const def = NPCS[id];
    const hearts = this.social.hearts(id);
    const lines = def.lines;
    const pool = hearts >= 4 && lines.friend?.length ? lines.friend : lines.general;
    const offers: Partial<Record<ItemId, number>> = {};
    for (const itemId of ITEM_IDS) {
      const price = offerFor(id, itemId);
      if (price !== undefined) offers[itemId] = price;
    }
    gameEvents.emit('shop:context', {
      npcId: id,
      name: def.name,
      title: def.title,
      shopTitle: def.shop?.title ?? def.name,
      greeting: pool[this.time_.day % pool.length],
      hearts,
      discount: this.social.discount(id),
      giftedToday: this.social.giftedToday(id, this.time_.day),
      stock: stockFor(id, this.state.lifetimeEarnings, this.time_.season, this.social.pointsOf(id)),
      offers,
      barter: def.shop?.barter ?? [],
      loves: [...def.gifts.loved],
      likes: [...def.gifts.liked],
    });
  }

  private openBoard(): void {
    this.emitBoard();
    this.setPanel('board');
  }

  private emitBoard(): void {
    gameEvents.emit('board:state', {
      requests: this.quests.view(this.state).map((r) => ({
        index: r.index,
        npcName: r.npcName,
        itemId: r.itemId,
        itemName: r.itemName,
        quantity: r.quantity,
        have: r.have,
        reward: r.reward,
        text: r.text,
        done: r.done,
      })),
      friends: this.social.view(this.time_.day),
    });
  }

  private talkTo(npc: Npc): void {
    const id = npc.def.id;
    const { before, after } = this.social.talk(id, this.time_.day);
    const text = this.npcs.talk(
      npc,
      { day: this.time_.day, season: this.time_.season, weather: this.weather.current, hearts: this.social.hearts(id) },
      { x: this.player.x, y: this.player.y },
    );
    gameEvents.emit('dialogue', { speaker: npc.def.name, text, hearts: this.social.hearts(id) });
    this.setPanel('dialogue');
    if (after > before) this.heartUp(id);
  }

  private giveGift(npcId: NpcId, slot: number): void {
    const stack = this.state.inventory.slots[slot];
    if (!stack || !Social.giftable(stack.itemId)) {
      sfx('error');
      gameEvents.emit('toast', { text: "That can't be given as a gift." });
      return;
    }
    const itemId = stack.itemId;
    const name = NPCS[npcId].name;
    if (this.social.giftedToday(npcId, this.time_.day)) {
      sfx('error');
      gameEvents.emit('toast', { text: `You've already given ${name} a gift today.` });
      return;
    }
    if (this.state.inventory.removeAt(slot, 1) !== 1) return;
    const result = this.social.gift(npcId, itemId, this.time_.day)!;
    const reply =
      result.reaction === 'loved' ? 'I love this! Thank you so much!' : result.reaction === 'liked' ? 'Oh, how nice. Thank you!' : "Thanks, that's kind of you.";
    this.npcs.say(npcId, reply);
    const npc = this.npcs.get(npcId);
    if (npc) this.fx.burst('heart', npc.sprite.x, npc.sprite.y - 20, result.reaction === 'loved' ? 8 : result.reaction === 'liked' ? 5 : 2);
    sfx('heart');
    const mood = result.reaction === 'loved' ? 'loved' : result.reaction === 'liked' ? 'liked' : 'accepted';
    gameEvents.emit('toast', { text: `${name} ${mood} the ${ITEMS[itemId].name}.` });
    if (result.after > result.before) this.heartUp(npcId);
  }

  private heartUp(npcId: NpcId): void {
    const hearts = this.social.hearts(npcId);
    gameEvents.emit('toast', { text: `♥ ${NPCS[npcId].name} — ${hearts} heart${hearts === 1 ? '' : 's'}!${hearts % 2 === 0 && NPCS[npcId].shop ? ' (better prices)' : ''}` });
    sfx('heart');
  }

  /** Sitting on a bench: a short break that restores some energy. */
  private rest(): void {
    if (this.time_.minute >= TIME_CONFIG.dayEndMinute - 50) {
      gameEvents.emit('toast', { text: "It's too late to sit around — go to bed!" });
      sfx('error');
      return;
    }
    if (this.state.energy >= this.state.maxEnergy) {
      gameEvents.emit('toast', { text: "You're well rested already." });
      return;
    }
    this.time_.set(this.time_.day, this.time_.minute + 30);
    this.state.restoreEnergy(15);
    this.fx.burst('sparkle', this.player.x, this.player.y - 18, 6);
    sfx('eat', { rate: 0.8 });
    gameEvents.emit('toast', { text: 'You take a short break on the bench. (+15 energy)' });
    this.emitTime();
  }

  /** Each morning, every sprinkler waters the four plots next to it. */
  private runSprinklers(): number {
    let count = 0;
    for (const s of this.build.ofKind('sprinkler')) {
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) if (this.farming.soak(s.tx + dx, s.ty + dy)) count++;
    }
    return count;
  }

  /** Moves a whole stack between the open chest and the backpack. */
  private transferChest(from: 'chest' | 'inventory', slot: number): void {
    const chest = this.build.openChest?.storage;
    if (this.panel !== 'chest' || !chest || !Number.isInteger(slot)) return;
    if (this.coop) {
      this.transferSharedChest(from, slot);
      return;
    }
    const source = from === 'chest' ? chest : this.state.inventory;
    const target = from === 'chest' ? this.state.inventory : chest;
    const stack = source.slots[slot];
    if (!stack) return;
    const leftover = target.add(stack.itemId, stack.quantity);
    const moved = stack.quantity - leftover;
    if (moved > 0) source.removeAt(slot, moved);
    else gameEvents.emit('toast', { text: `No room for ${ITEMS[stack.itemId].name}` });
  }

  private toggleCollisionDebug(): void {
    const world = this.physics.world;
    const enable = !(world.drawDebug && world.debugGraphic?.visible);
    // Note: createDebugGraphic() itself switches drawDebug on, so set state after it.
    if (!world.debugGraphic) world.createDebugGraphic();
    world.drawDebug = enable;
    world.debugGraphic.clear().setVisible(enable).setDepth(DEPTH.debug);
  }
}
