import type * as Phaser from 'phaser';
import { FISH, FISHING, GAME_CONFIG, ITEMS, type ItemId, type Season, type WeatherKind } from '@farming/shared';
import { itemTextureKey, TEXTURES } from '../assets/registerTextures';
import { sfx } from '../audio/sfx';
import { DEPTH } from '../constants';
import type { Player } from '../entities/Player';
import { gameEvents } from '../events/GameEventBus';
import type { PlayerState } from '../state/PlayerState';
import type { DropSystem } from './DropSystem';
import type { FxSystem } from './FxSystem';

type Phase = 'idle' | 'casting' | 'waiting' | 'bite';

export interface FishingContext {
  minute: number;
  season: Season;
  weather: WeatherKind;
  /** The sea at the beach, or ponds and the river. */
  water?: 'fresh' | 'ocean';
}

const toast = (text: string) => gameEvents.emit('toast', { text });

/** Which fish are biting right now, weighted. */
export function fishPool(ctx: FishingContext): Array<{ itemId: ItemId; weight: number }> {
  const minute = ctx.minute % (24 * 60);
  const water = ctx.water ?? 'fresh';
  return FISH.filter((f) => {
    if ((f.water ?? 'fresh') !== water) return false;
    if (f.seasons && !f.seasons.includes(ctx.season)) return false;
    if (f.weather && !f.weather.includes(ctx.weather)) return false;
    if (f.hours) {
      const from = f.hours.from % (24 * 60);
      const to = f.hours.to % (24 * 60);
      const inside = from <= to ? minute >= from && minute < to : minute >= from || minute < to;
      if (!inside) return false;
    }
    return true;
  });
}

/**
 * Fishing: cast into water, wait for the bobber to dip, then press Use while
 * the "!" is showing. Too early or too late and the fish gets away.
 */
export class FishingSystem {
  private phase: Phase = 'idle';
  private readonly line: Phaser.GameObjects.Graphics;
  private readonly bobber: Phaser.GameObjects.Image;
  private readonly alert: Phaser.GameObjects.Image;
  private timer = 0;
  private bob = 0;
  private target = { x: 0, y: 0 };
  private ctx: FishingContext = { minute: 0, season: 'spring', weather: 'sunny' };

  constructor(
    private readonly scene: Phaser.Scene,
    private readonly player: Player,
    private readonly state: PlayerState,
    private readonly drops: DropSystem,
    private readonly fx: FxSystem,
  ) {
    this.line = scene.add.graphics().setDepth(DEPTH.fx - 3);
    this.bobber = scene.add.image(0, 0, TEXTURES.bobber).setVisible(false).setDepth(DEPTH.ySortBase - 1);
    this.alert = scene.add.image(0, 0, TEXTURES.alert).setOrigin(0.5, 1).setVisible(false).setDepth(DEPTH.fx);
  }

  get active(): boolean {
    return this.phase !== 'idle';
  }

  get biting(): boolean {
    return this.phase === 'bite';
  }

  /** Throws the line onto a water tile. */
  cast(tx: number, ty: number, ctx: FishingContext): void {
    if (this.active) return;
    if (!this.state.spendEnergy(FISHING.energyCost)) {
      toast("You're too tired to fish.");
      return;
    }
    const size = GAME_CONFIG.tileSize;
    this.ctx = ctx;
    this.target = { x: tx * size + size / 2, y: ty * size + size / 2 + 2 };
    this.phase = 'casting';
    const rod = itemTextureKey('fishing_rod');
    sfx('cast');
    this.player.useTool(rod, 'swing', () => undefined);
    // After the swing, keep the rod out and drop the bobber in.
    this.scene.time.delayedCall(340, () => {
      if (this.phase !== 'casting') return;
      this.player.hold(rod);
      this.bobber.setPosition(this.target.x, this.target.y).setVisible(true);
      this.fx.burst('water', this.target.x, this.target.y, 5);
      sfx('splash', { volume: 0.6 });
      this.phase = 'waiting';
      const [min, max] = FISHING.biteDelay;
      this.timer = min + Math.random() * (max - min);
    });
  }

  /** Use pressed while the line is out. */
  reel(): void {
    if (this.phase === 'casting') return;
    if (this.phase === 'bite') {
      this.land();
      return;
    }
    if (this.phase === 'waiting') {
      toast('Reeled in too early — nothing on the line.');
      this.stop();
    }
  }

  /** Walking away (or opening a menu) puts the rod away. */
  cancel(): void {
    if (this.active) this.stop();
  }

  update(delta: number): void {
    if (this.phase === 'idle' || this.phase === 'casting') return;
    this.timer -= delta;
    this.bob += delta;
    const tip = this.player.hold(itemTextureKey('fishing_rod'));

    if (this.phase === 'waiting') {
      this.bobber.y = this.target.y + Math.sin(this.bob / 280) * 0.7;
      if (this.timer <= 0) {
        this.phase = 'bite';
        this.timer = FISHING.reactionWindow;
        this.alert.setPosition(this.player.x + 9, this.player.y - 22).setVisible(true);
        sfx('bite');
        this.fx.burst('water', this.target.x, this.target.y, 4);
      }
    } else if (this.phase === 'bite') {
      // Bobber tugged under.
      this.bobber.y = this.target.y + 2 + Math.sin(this.bob / 40) * 1.2;
      this.alert.setPosition(this.player.x + 9, this.player.y - 22 - Math.abs(Math.sin(this.bob / 90)) * 2);
      if (this.timer <= 0) {
        toast('The fish got away!');
        this.stop();
        return;
      }
    }

    // A gently sagging line from the rod tip to the bobber.
    const g = this.line;
    g.clear();
    g.lineStyle(0.6, 0xf4efe0, 0.85);
    const bx = this.bobber.x;
    const by = this.bobber.y - 2;
    const mx = (tip.x + bx) / 2;
    const my = Math.max(tip.y, by) + 6;
    g.beginPath();
    g.moveTo(tip.x, tip.y);
    const steps = 10;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const x = (1 - t) * (1 - t) * tip.x + 2 * (1 - t) * t * mx + t * t * bx;
      const y = (1 - t) * (1 - t) * tip.y + 2 * (1 - t) * t * my + t * t * by;
      g.lineTo(x, y);
    }
    g.strokePath();
  }

  private land(): void {
    const pool = fishPool(this.ctx);
    let roll = Math.random() * pool.reduce((sum, f) => sum + f.weight, 0);
    let caught: ItemId = pool[0]?.itemId ?? 'sunfish';
    for (const f of pool) {
      roll -= f.weight;
      if (roll <= 0) {
        caught = f.itemId;
        break;
      }
    }
    const { x, y } = this.target;
    this.stop();
    this.fx.burst('water', x, y, 10);
    this.fx.burst('sparkle', this.player.x, this.player.y - 18, 8);
    sfx('splash');
    sfx('catch');
    // Show the catch held up for a moment.
    const shown = this.scene.add.image(this.player.x, this.player.y - 26, itemTextureKey(caught)).setDepth(DEPTH.fx);
    this.scene.tweens.add({ targets: shown, y: shown.y - 6, alpha: 0, delay: 600, duration: 500, onComplete: () => shown.destroy() });
    if (this.state.inventory.add(caught, 1) > 0) this.drops.spawn(caught, 1, this.player.x, this.player.y + 4);
    else gameEvents.emit('item:collected', { itemId: caught, quantity: 1 });
    const rare = caught === 'golden_carp';
    toast(rare ? `Wow! You caught a ${ITEMS[caught].name}!` : `You caught a ${ITEMS[caught].name}!`);
  }

  private stop(): void {
    this.phase = 'idle';
    this.line.clear();
    this.bobber.setVisible(false);
    this.alert.setVisible(false);
    this.player.hold(null);
  }
}
