import * as Phaser from 'phaser';
import { GAME_CONFIG } from '@farming/shared';
import { itemTextureKey } from '../assets/registerTextures';
import { PixelCanvas } from '../assets/PixelCanvas';
import { sfx } from '../audio/sfx';
import { DEPTH, SCENES } from '../constants';
import { gameEvents } from '../events/GameEventBus';
import { FishingSystem } from '../systems/FishingSystem';
import { createRng } from '../utils/random';
import { AreaScene, type AreaAction, type AreaHost } from './AreaScene';

export interface BeachSceneData {
  host: AreaHost;
  /** Shells and coral picked today (each spot can be picked once a day). */
  forage: { taken(day: number): number[]; take(day: number, id: number): void };
}

const W = 34;
const H = 22;
const SHORE = 24; // first water column
const PIER = { y: 9, x0: 20, x1: 31 };

type Tile = 'grass' | 'sand' | 'wet' | 'water' | 'pier';

/**
 * The beach east of the farm: sand, a little pier, and the open sea. Shells
 * and coral wash up each morning, and the sea has its own fish (tuna, and a
 * rare pufferfish on sunny afternoons).
 */
export class BeachScene extends AreaScene<BeachSceneData> {
  private forage!: BeachSceneData['forage'];
  private fishing!: FishingSystem;
  private tiles: Tile[] = [];
  private items: Array<{ id: number; sprite: Phaser.GameObjects.Image; itemId: 'seashell' | 'coral' }> = [];

  constructor() {
    super(SCENES.Beach);
  }

  init(data: BeachSceneData): void {
    super.init(data);
    this.forage = data.forage;
    this.items = [];
  }

  create(): void {
    const size = GAME_CONFIG.tileSize;
    const rng = createRng('beach-layout');
    this.tiles = [];
    for (let ty = 0; ty < H; ty++) {
      for (let tx = 0; tx < W; tx++) {
        // A wavy shoreline.
        const shore = SHORE + Math.round(Math.sin(ty * 0.6) * 1.2);
        let t: Tile = tx < 4 ? 'grass' : tx >= shore ? 'water' : tx >= shore - 1 ? 'wet' : 'sand';
        if (ty === PIER.y && tx >= PIER.x0 && tx <= PIER.x1) t = 'pier';
        this.tiles.push(t);
      }
    }
    const key = 'beach-ground';
    if (!this.textures.exists(key)) this.textures.addCanvas(key, this.drawGround(rng));
    this.add.image(0, 0, key).setOrigin(0).setDepth(DEPTH.ground);
    this.cameras.main.setBackgroundColor('#3a83b5');

    this.walls = this.physics.add.staticGroup();
    this.addSolidRuns(W, H, (tx, ty) => this.tileAt(tx, ty) === 'water');
    // The top and bottom edges.
    this.walls.add(this.add.zone((W * size) / 2, -4, W * size, 8));
    this.walls.add(this.add.zone((W * size) / 2, H * size + 4, W * size, 8));

    this.setupArea(W, H, { x: 2 * size, y: 11 * size + 12, facing: 'right' });
    this.fishing = new FishingSystem(this, this.player, this.host.state, this.drops, this.fx);
    this.spawnForage();
    gameEvents.emit('area:label', { label: '🏖 The Beach' });
    // Waves lapping.
    this.time.addEvent({ delay: 2600, loop: true, callback: () => sfx('splash', { volume: 0.12, rate: 0.6 + Math.random() * 0.2 }) });
  }

  protected tick(delta: number, frozen: boolean): void {
    if (frozen) this.fishing.cancel();
    const intent = this.controls.getMoveIntent();
    if (this.fishing.active && (intent.x !== 0 || intent.y !== 0)) this.fishing.cancel();
    this.fishing.update(delta);
    // Walk off the left edge to go home.
    if (!this.leaving && this.player.x < 6) this.leave();
    // Pick up shells by walking over them.
    for (let i = this.items.length - 1; i >= 0; i--) {
      const it = this.items[i];
      if (Math.hypot(it.sprite.x - this.player.x, it.sprite.y - this.player.y + 4) > 9) continue;
      if (this.host.state.inventory.add(it.itemId, 1) > 0) continue;
      this.forage.take(this.host.calendar().day, it.id);
      gameEvents.emit('item:collected', { itemId: it.itemId, quantity: 1 });
      sfx('pickup');
      it.sprite.destroy();
      this.items.splice(i, 1);
    }
  }

  protected resolve(mode: 'use' | 'interact'): AreaAction | null {
    if (this.fishing.active) {
      return this.fishing.biting
        ? { verb: 'Reel in!', key: 'E', run: () => this.fishing.reel() }
        : { verb: 'Waiting for a bite…', key: 'E', info: true, run: () => this.fishing.reel() };
    }
    const { tx, ty } = this.target();
    const feet = this.player.tile;
    if (feet.tx <= 1) return { verb: 'Back to the farm', key: 'E', run: () => this.leave() };
    const stack = this.host.state.inventory.selectedStack;
    const rod = stack?.itemId === 'fishing_rod';
    if (mode === 'use' && rod) {
      // Cast from the shore or the pier into the sea (one tile further from the pier's edge is fine too).
      const water = this.tileAt(tx, ty) === 'water' ? { tx, ty } : null;
      if (!water) return { verb: 'Face the sea to fish', key: 'Space', info: true, run: () => undefined };
      if (this.host.state.energy < 3) return { verb: 'Too tired', key: 'Space', blocked: true, run: () => undefined };
      return { verb: 'Cast line (sea)', key: 'Space', run: () => this.fishing.cast(water.tx, water.ty, { ...this.host.calendar(), water: 'ocean' }) };
    }
    return null;
  }

  private tileAt(tx: number, ty: number): Tile {
    if (tx < 0 || ty < 0 || tx >= W || ty >= H) return 'water';
    return this.tiles[ty * W + tx];
  }

  /** A handful of shells and coral on the sand, the same spots all day. */
  private spawnForage(): void {
    const size = GAME_CONFIG.tileSize;
    const day = this.host.calendar().day;
    const taken = new Set(this.forage.taken(day));
    const rng = createRng(`beach-forage:${day}`);
    const count = rng.int(4, 7);
    for (let id = 0, tries = 0; id < count && tries < 200; tries++) {
      const tx = rng.int(6, SHORE - 2);
      const ty = rng.int(2, H - 3);
      if (this.tileAt(tx, ty) === 'pier') continue;
      const itemId = rng.chance(0.25) ? 'coral' : 'seashell';
      if (!taken.has(id)) {
        const sprite = this.add.image(tx * size + 8, ty * size + 10, itemTextureKey(itemId)).setDepth(DEPTH.ySortBase + ty * size + 10).setScale(0.75);
        this.items.push({ id, sprite, itemId });
      }
      id++;
    }
  }

  private drawGround(rng: ReturnType<typeof createRng>): HTMLCanvasElement {
    const size = GAME_CONFIG.tileSize;
    const p = new PixelCanvas(W * size, H * size);
    const colors: Record<Tile, [string, string]> = {
      grass: ['#6aa84f', '#5a9a42'],
      sand: ['#ecd8a4', '#dcc48e'],
      wet: ['#c8b07a', '#b89e68'],
      water: ['#3a83b5', '#4a93c5'],
      pier: ['#a8723f', '#8a5a32'],
    };
    for (let ty = 0; ty < H; ty++) {
      for (let tx = 0; tx < W; tx++) {
        const t = this.tileAt(tx, ty);
        const [a, b] = colors[t];
        const x0 = tx * size;
        const y0 = ty * size;
        if (t === 'pier') {
          // Planks over the water.
          p.rect(x0, y0, size, size, colors.water[0]);
          p.rect(x0, y0 + 1, size, size - 2, a);
          for (let x = 0; x < size; x += 4) p.rect(x0 + x, y0 + 1, 1, size - 2, b);
          continue;
        }
        p.rect(x0, y0, size, size, a);
        for (let i = 0; i < (t === 'water' ? 3 : 6); i++) p.rect(x0 + rng.int(0, 14), y0 + rng.int(0, 15), t === 'water' ? 3 : 1, 1, t === 'water' ? '#8ec4e4' : b);
        // Foam where the waves meet the sand.
        if (t === 'water' && this.tileAt(tx - 1, ty) === 'wet') for (let y = 0; y < size; y += 2) p.set(x0 + (y % 4), y0 + y, '#f2f8fa');
      }
    }
    return p.toCanvas();
  }
}
