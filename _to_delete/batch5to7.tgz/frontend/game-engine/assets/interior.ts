import type { FurnitureKind } from '@farming/shared';
import { P } from './palette';
import { PixelCanvas } from './PixelCanvas';

/** Cottage interior art: room, bed and furniture. Base row = bottom row unless noted. */

export const FURNITURE_ORIGIN: Record<FurnitureKind, number> = {
  rug: 0.5,
  table: 1,
  chair: 1,
  bookshelf: 1,
  house_plant: 1,
  floor_lamp: 1,
  painting: 0.5,
};

/** The room: wooden floor, plaster walls with a wainscot, a window or two. */
export function drawRoom(width: number, height: number, size = 16): HTMLCanvasElement {
  const p = new PixelCanvas(width * size, height * size);
  const wallRows = 2;
  for (let ty = 0; ty < height; ty++) {
    for (let tx = 0; tx < width; tx++) {
      const x0 = tx * size;
      const y0 = ty * size;
      const edge = tx === 0 || tx === width - 1 || ty === height - 1;
      if (edge) {
        p.rect(x0, y0, size, size, '#3a2a22');
        continue;
      }
      if (ty < wallRows) {
        p.rect(x0, y0, size, size, '#e8d8b8');
        if (ty === wallRows - 1) {
          p.rect(x0, y0 + 9, size, 7, '#9c6a40');
          p.rect(x0, y0 + 9, size, 1, '#c08a5a');
        }
        continue;
      }
      // Floor planks.
      p.rect(x0, y0, size, size, (ty % 2) ? '#b07a48' : '#a8723f');
      p.rect(x0, y0 + 7, size, 1, '#8a5a32');
      p.rect(x0 + ((ty * 7) % 16), y0, 1, 7, '#8a5a32');
      p.rect(x0 + ((ty * 7 + 9) % 16), y0 + 8, 1, 8, '#8a5a32');
    }
  }
  // Windows.
  for (const wx of [3, width - 4]) {
    const x0 = wx * size + 2;
    p.rect(x0, 4, 12, 11, '#6e4638');
    p.rect(x0 + 1, 5, 10, 9, '#a8d4e8');
    p.rect(x0 + 6, 5, 1, 9, '#6e4638');
    p.rect(x0 + 1, 9, 10, 1, '#6e4638');
  }
  // Door mat at the bottom middle.
  const mx = Math.floor(width / 2) * size;
  p.rect(mx - 4, (height - 1) * size - 6, 24, 5, '#7a5a3a');
  return p.toCanvas();
}

/** The bed, 32x30, base row 29. */
export function drawBed(): PixelCanvas {
  const p = new PixelCanvas(32, 30);
  p.rect(1, 2, 30, 6, P.woodDark);
  p.rect(2, 3, 28, 4, P.wood);
  p.rect(2, 8, 28, 20, '#f3ead8');
  p.rect(4, 9, 10, 5, '#ffffff');
  p.rect(18, 9, 10, 5, '#ffffff');
  p.rect(2, 15, 28, 13, '#5a7ac8');
  for (let y = 17; y < 28; y += 3) p.rect(2, y, 28, 1, '#7a9ae0');
  p.rect(1, 27, 30, 3, P.woodDark);
  p.outline(P.outline);
  return p;
}

export function drawFurniture(kind: FurnitureKind): PixelCanvas {
  switch (kind) {
    case 'rug': {
      const p = new PixelCanvas(48, 32);
      p.rect(1, 1, 46, 30, '#a8443a');
      p.rect(4, 4, 40, 24, '#d8a050');
      p.rect(7, 7, 34, 18, '#a8443a');
      for (let x = 10; x < 40; x += 6) p.rect(x, 14, 3, 4, '#f3ead8');
      return p;
    }
    case 'table': {
      const p = new PixelCanvas(32, 22);
      p.rect(1, 4, 30, 8, P.wood);
      p.rect(1, 4, 30, 2, P.woodLight);
      p.rect(3, 12, 3, 9, P.woodDark);
      p.rect(26, 12, 3, 9, P.woodDark);
      p.rect(12, 1, 6, 4, '#f3ead8');
      p.rect(13, 0, 4, 2, '#e0443e');
      p.outline(P.outline);
      return p;
    }
    case 'chair': {
      const p = new PixelCanvas(14, 22);
      p.rect(2, 1, 10, 10, P.woodDark);
      p.rect(3, 2, 8, 8, P.wood);
      p.rect(1, 11, 12, 3, P.woodLight);
      p.rect(2, 14, 2, 7, P.woodDark);
      p.rect(10, 14, 2, 7, P.woodDark);
      p.outline(P.outline);
      return p;
    }
    case 'bookshelf': {
      const p = new PixelCanvas(32, 34);
      p.rect(1, 1, 30, 32, P.woodDark);
      p.rect(3, 3, 26, 28, '#5a3a24');
      const books = ['#c8443a', '#4a62c8', '#6cc45a', '#e8b83a', '#a06ac4', '#f3ead8'];
      for (let shelf = 0; shelf < 3; shelf++) {
        const y = 3 + shelf * 10;
        p.rect(3, y + 8, 26, 2, P.wood);
        for (let x = 4, i = shelf; x < 28; x += 3, i++) p.rect(x, y + 1 + (i % 2), 2, 7 - (i % 2), books[i % books.length]);
      }
      p.outline(P.outline);
      return p;
    }
    case 'house_plant': {
      const p = new PixelCanvas(16, 24);
      p.rect(4, 16, 8, 7, '#b8603a');
      p.rect(4, 16, 8, 1, '#d8805a');
      for (const [x, y, w, h] of [[7, 4, 2, 12], [3, 6, 4, 3], [9, 3, 4, 3], [2, 10, 5, 3], [9, 9, 5, 3], [6, 1, 4, 3]]) p.rect(x, y, w, h, P.leaf);
      p.rect(3, 6, 2, 1, P.leafLight);
      p.rect(10, 3, 2, 1, P.leafLight);
      p.outline(P.outline);
      return p;
    }
    case 'floor_lamp': {
      const p = new PixelCanvas(14, 30);
      p.rect(1, 1, 12, 8, '#f6d68a');
      p.rect(2, 2, 10, 6, '#ffe9a8');
      p.rect(6, 9, 2, 18, '#5a4a40');
      p.rect(3, 27, 8, 2, '#5a4a40');
      p.outline(P.outline);
      return p;
    }
    case 'painting': {
      const p = new PixelCanvas(32, 22);
      p.rect(0, 0, 32, 22, '#c8962a');
      p.rect(2, 2, 28, 18, '#a8d4e8');
      p.rect(2, 12, 28, 8, '#6cc45a');
      for (let i = 0; i < 8; i++) p.rect(8 + i, 12 - Math.min(i, 7 - i), 1, 1 + Math.min(i, 7 - i), '#8a9aa8');
      p.rect(22, 4, 4, 4, '#ffe27a');
      p.outline(P.outline);
      return p;
    }
  }
}

/** A wooden signpost pointing to the beach, 16x22, base row 21. */
export function drawSignpost(): PixelCanvas {
  const p = new PixelCanvas(16, 22);
  p.rect(7, 6, 2, 16, P.woodDark);
  p.rect(1, 3, 13, 6, P.wood);
  p.rect(1, 3, 13, 1, P.woodLight);
  p.set(14, 5, P.wood);
  p.set(14, 6, P.wood);
  p.set(15, 5, P.wood);
  p.rect(3, 5, 8, 1, '#5a3a24');
  p.rect(3, 7, 6, 1, '#5a3a24');
  p.outline(P.outline);
  return p;
}
