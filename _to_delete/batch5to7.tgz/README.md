# Farming Game (working title)

A browser-based, top-down 2D sandbox adventure: farming, exploration, gathering, crafting and building.
**Current state: Phase 5 + the big content update** — co-op multiplayer over Socket.IO (shared worlds the server is in charge of, synced movement, chat, trading, co-op farming, host migration), accounts, profiles and cloud saves in PostgreSQL, and a game with days and seasons, weather, building, a village market of five merchants with schedules, festivals, heart events and mail, a 30-floor mine with combat, 11 crops, a greenhouse and artisan machines, a barn with cows and sheep, a beach, a cottage you furnish, community projects, a collection with achievements, and settings for keys, UI size, day length, gamepads and touch screens.

## Quick start

```bash
npm install        # from the repo root (installs all workspaces)
npm run dev        # game on http://localhost:3000, API + co-op server on :4000
```

That's all — **no database to install.** By default the backend runs an embedded PostgreSQL
([PGlite](https://pglite.dev): real PostgreSQL compiled to WebAssembly) inside its own process,
storing data in `backend/.data/pglite/`. Tables are created automatically on first start.

- **Using a PostgreSQL server instead** (Homebrew, Postgres.app, a hosted database): copy
  `backend/.env.example` to `backend/.env` and set `DATABASE_URL`. The same SQL and migrations
  run there. (`npm run db:migrate` applies migrations by hand; stop the dev server first when using
  the embedded database.)
- **Resetting** the embedded database: stop the server and delete `backend/.data/`.
- If the database can't be opened, the game still works: you play as a guest with browser saves,
  and the backend keeps retrying.
- Game only / API only: `npm run dev:frontend`, `npm run dev:backend`.
- The game reaches the API through its own origin (`/api/*` is proxied to Express; set
  `BACKEND_URL` to point elsewhere).
- Production build: `npm run build && npm start` (set `NODE_ENV=production` for the backend so the
  session cookie is HTTPS-only).
- Type-check everything: `npm run typecheck`.
- **Co-op:** the game connects to the co-op server on port 4000 of the same machine it was loaded
  from (set `NEXT_PUBLIC_COOP_URL` if it lives elsewhere). To play with someone on your network,
  they open `http://<your-computer's-IP>:3000`, create an account there, and join with your code;
  both ports (3000 and 4000) must be reachable.

### Pages

| Route | What it is |
| --- | --- |
| `/` | Title screen: account, your worlds (cloud + this browser) with Export, import a save file, start a new world |
| `/play?seed=name` | The game. Each world name is its own map and its own save |
| `/play?seed=name&host=1` | Open that world to friends (co-op host) |
| `/play?join=CODE` | Join a friend's world with their code |
| `/login`, `/register` | Accounts |
| `/profile` | Display name, default character look, stats, manage/delete saved worlds |

### Controls

Every key below except Esc, Enter and the number row can be rebound in **Pause menu → Settings**
(the help text in the game follows your bindings).

| Key | Action |
| --- | --- |
| WASD / Arrow keys | Move (diagonals allowed, 4-direction facing) |
| Shift | Run |
| Space / J / left-click | Use the selected item on the tile you face (chop, mine, till, water, plant, cast a line, give a gift…) |
| E | Interact: talk, trade at a stall, read the notice board, harvest, pick berries, open chests, sit on a bench, go inside, enter the mine, walk to the beach |
| F (or right-click food in the hotbar) | Eat the selected food |
| M | World map |
| 1–9, 0 / mouse wheel | Select hotbar slot |
| I or Tab | Inventory (drag stacks, or click one slot then another) |
| C | Crafting |
| K | Collection & achievements |
| Esc | Close a menu, or open the pause menu (save, customise, new game) |
| Shift+M | Mute / unmute |
| Enter | Co-op chat (the game ignores keys while you type; Esc closes) |
| Click the floating button | Do the action shown above whatever you're facing |
| `` ` `` (backtick) | Toggle collision boxes (developer aid) |

**Gamepad** (any standard controller): left stick / D-pad move, A use, X interact, Y backpack,
B or Start menu, LB/RB hotbar, LT eat, RT run, View/Back map.
**Touch screens** get an on-screen joystick and buttons (Use, Act, Eat, Bag, Map, menu, Run toggle);
pushing the stick all the way runs. Settings can force them on or off.

### How to play

You wake up outside your cottage on Spring 1 with an axe, pickaxe, hoe, watering can, 12 turnip
seeds, some berries, 100g, and a freshly tilled plot beside the cottage. The village market is next door; Tobin walks the path most days.

1. **Days** run from 6am to 2am (~8 real minutes; change it in Settings). Go inside your cottage and get into bed to start the next
   day; stay up past 2am and you pass out and wake up tired. The game saves every morning (and when
   you close the tab). Time pauses while a menu is open.
2. **Energy** — tools cost energy; eat crops, berries or eggs (select and press F) or sleep.
3. **Farm** — plant seeds on tilled soil or straight onto grass, then water. Each morning every crop watered the day before grows a stage.
   Rain waters for you. Crops have seasons (turnip: spring/fall, carrot: spring–fall, pumpkin:
   summer/fall) and wither if the season changes under them. Nothing grows in winter.
4. **Gather** — trees, rocks, copper ore, fiber, berries. Everything grows back after a few days.
5. **Build** — craft fences (auto-connecting), wood/stone paths, lamp posts and chests; select one
   and press Space to place. Pick placed things back up with the pickaxe.
6. **Trade** — five merchants keep stalls in the market (see below). Mira's seed stock changes with
   the season, and more unlocks as you earn: pumpkin seeds at 150g lifetime sales, chickens at 300g.
   Chickens lay an egg every morning.
7. **Make friends** — talk to each villager once a day and give gifts to raise hearts. Every two
   hearts with a merchant takes 5% off their prices (up to 20%).
8. **Notice board** — two delivery requests are posted every morning, for gold and friendship.
9. **Fish** — buy a rod from Finn, face water and press Space, then press again when the "!" shows.
10. **Cook** — the Cooking tab in crafting turns crops, eggs, berries and fish into better food.
11. **Customise** your character from the pause menu.
12. **Play together** — see Co-op below.
13. **The mine** (north of the farm) — 30 floors of ore, gems and slimes; find the ladder down,
    an elevator every 5 floors. Watch your health; faint and you're carried home minus some gold.
14. **Artisan goods** — kegs make juice, preserves jars make pickles, the cheese press and loom turn
    milk and wool into cheese and cloth. The greenhouse grows any crop in any season.
15. **Barn animals** — build a barn, buy cows and sheep from Mira, keep hay in the barn, pet them daily.
16. **Village life** — villagers walk to their stalls and home again; festivals on day 8 of every
    season; heart events at 2/4/6 hearts; letters (with gifts) arrive in your mailbox.
17. **The beach** — follow the path east to the signpost: sea fishing from the pier, shells and coral.
18. **Your cottage** — walk in the front door. Buy furniture from Willa and place it; the bed is
    inside now. A House Extension (Willa, 2500g) gives you a much bigger room.
19. **Community projects** — Notice board → Community: five big goals everyone chips in to; each
    pays every player and mails a gift.
20. **Collection** (K) — every item you've found and 18 achievements with progress bars.
21. **Saves** — Pause menu → Export save file downloads a `.json`; import it on the title screen in
    any browser. Each world name is its own save slot.

## Architecture

```
farming/                     npm workspaces monorepo
├─ shared/                   @farming/shared — no runtime deps, used by front & back
│  └─ src/
│     ├─ constants/          tile size, world size, player speeds
│     ├─ types/              Terrain, WorldObjectSpec, Direction, CharacterAppearance, SaveData
│     ├─ validation/         validateSave(): server-side checks against the game rules
│     ├─ world/              generateWorld(seed), WorldData, seeded RNG/noise, weather forecast
│     │                      (moved here from the engine so the server builds the same map)
│     ├─ net/                the co-op protocol: typed Socket.IO events, world ops, trade views
│     └─ game-config/        GAME_CONFIG, starter kit, and the game rules as data: items, crops,
│                            recipes, resources, placeables, time/weather, NPCs, appearance
├─ scripts/dev-all.mjs       runs frontend + backend together (npm run dev)
├─ frontend/                 Next.js (App Router) + Phaser 3
│  ├─ app/                   routes: / (title), /play, /login, /register, /profile
│  ├─ components/            GameCanvas (mounts engine), Hud, Hotbar, Toasts, ItemSlot/Icon,
│  │                         CharacterPicker; menus/ (TitleScreen, AuthForm, ProfilePage)
│  │  └─ panels/             Inventory, Crafting, Trade, Board, Chest, Character, Menu, Map (+ Clock, EnergyBar, DialogueBox, Hearts)
│  ├─ hooks/                 useGameEvent (game → React), useSession (who is signed in)
│  ├─ services/              api.ts (typed backend client), saveStores.ts (cloud + browser saves),
│  │                         coop.ts (Socket.IO client: host / join, implements CoopSession)
│  └─ game-engine/           everything game-related; React-free
│     ├─ index.ts            createGame() → GameHandle (the only API React uses)
│     ├─ config.ts           Phaser config (pixelArt, RESIZE scaling, Arcade physics)
│     ├─ constants.ts        scene keys, render depth layers
│     ├─ events/             gameEvents (game → UI) and gameCommands (UI → game); no Phaser import
│     ├─ scenes/             BootScene (generate art) → WorldScene (wires systems together)
│     ├─ entities/           Player (movement, animation, tool swings)
│     ├─ net/                CoopSession (the engine's view of a connection) and Authority
│     │                      (local: apply now; server: apply once the server agrees)
│     ├─ state/              Inventory, PlayerState, economy rules, Social (friendship), Quests (notice board), save format + SaveStore
│     ├─ systems/            Time, Weather, Lighting, Build, Animal, Npc, Interaction, Fishing,
│     │                      AmbientLife, RemotePlayer, Resource, Farming, Drop, Fx, Camera, …
│     ├─ maps/               WorldData, WorldGenerator (seeded), tileResolver (autotiling)
│     ├─ assets/             procedural pixel art: palette, tileset, sprites, character
│     ├─ audio/              synthesiser (dsp), sound designs, AudioSystem (mixing, ambience, music)
│     └─ utils/              seeded RNG, value noise
└─ backend/                  Express + Socket.IO + PostgreSQL (run with tsx)
   └─ src/
      ├─ index.ts            server start, DB connect/migrate with retry, health monitor
      ├─ realtime/           Socket.IO: cookie sign-in, rooms (Room), the server's copy of the
      │                      shared world (CoopWorld), invite codes
      ├─ config.ts           env (DATABASE_URL, PGLITE_DATA_DIR, PORT, NODE_ENV; backend/.env loaded)
      ├─ api/                routes, session/rate-limit middleware, errors
      ├─ controllers/        auth, profile, worlds (+ inventory), game-data
      ├─ services/           auth (scrypt passwords, sessions), world saves (validation, conflicts)
      ├─ models/             SQL for users, sessions, profiles, worlds, inventory_items, coop_members
      └─ database/           db.ts (embedded PGlite or PostgreSQL server), migrate.ts, migrations/*.sql
```

### Key decisions

- **Engine/UI separation.** Phaser owns the game loop and all game state. React only mounts a
  `<div>`, holds an opaque `GameHandle`, renders typed events (`inventory:changed`,
  `player:stats`, `ui:panel`, `interaction:hint`…) and sends typed commands back
  (`inventory:move`, `craft`, `shop:buy`…). The game validates every command, so the same
  handlers can later accept commands from the network. Phaser is loaded with a dynamic
  `import()` inside `useEffect`, so it never runs during server rendering.
- **Rules as data.** Items, crops, recipes and resource nodes live in `shared/game-config`, so the
  backend can validate trades and crafting with the same definitions in Phase 4.
- **Data-first world.** `generateWorld(seed)` returns plain `WorldData` (typed arrays + object
  specs) with no engine references. The same structure can be saved to and loaded from the
  backend in Phase 3/4, and validated server-side for multiplayer.
- **Procedural, original pixel art.** All art (tileset, trees, rocks, character) is drawn in code
  at boot from one palette — no external assets, no licensing questions, consistent 16px grid.
  The character sheet is generated from a `CharacterAppearance`, which is the hook for
  customisation.
- **Crisp rendering.** `pixelArt: true`, an extruded tileset (no seams), and an integer camera
  zoom chosen from the window height, so every art pixel is the same size on any screen.
- **Top-down depth.** Objects and the player are y-sorted by their base. Collision bodies are
  small feet-level boxes, so you can walk behind trees; canopies fade when they hide the player.

## The big content update

Seven batches on top of Phase 5:

1. **Mine & tool upgrades** — `MineScene` (cellular-automaton caves, ore by depth, hidden ladders,
   slimes, health, lantern darkness, elevator); iron and gold tools, swords.
2. **Crops & machines** — 8 new crops (some regrow), the greenhouse, keg and preserves jar
   (`shared/game-config/machines.ts`, ready times in game minutes so the server can run them).
3. **Animal care** — barn, cows and sheep, hay, happiness, milk and wool, cheese press and loom
   (`livestock.ts`; the morning update is a pure function both the game and the server run).
4. **Village life** — NPC commutes, four festivals (egg hunt, fishing derby, harvest fair, winter
   lights), heart events, mail with gifts (`village.ts`, `Social`).
5. **Beach & cottage** — side areas share `AreaScene` (the world scene keeps the clock and menus
   while you're away): `BeachScene` (sea fishing, daily forage) and `InteriorScene` (furniture on
   floor/object/wall layers, lamps, the bed, the cottage extension).
6. **Co-op upgrades** — **host migration** (when the host leaves, the longest-connected player
   becomes host and the world stays open; the owner takes over again on return, and the world
   keeps saving into the owner's account); **community projects** on the notice board, shared
   through a `donate` world op the server clamps and checks; the server now keeps its copy of each
   backpack in step (items given to chests or projects must be in it; items it hands out are added
   to it) and rejects implausible gold jumps.
7. **Quality of life** — `game-engine/settings.ts` (rebindable keys, UI scale, day length, touch
   mode, saved in the browser), `InputSystem` reading keyboard, mouse, gamepad and the on-screen
   `virtualPad` together, `Collection` + `shared/game-config/achievements.ts`, save export/import
   (`state/saveFile.ts`, validated with the same `validateSave` the server uses).

## Co-op (Phase 5)

**How to play together.** Both players need an account.

1. The host opens a world and chooses **Invite friends (co-op)** in the pause menu, or **Host
   co-op** next to a world on the title screen. A six-letter code appears at the top left.
2. Friends enter the code under **Join a friend** on the title screen (or open `/play?join=CODE`).
   Up to four players per world.
3. Everyone sees each other move, swing tools and change the world. Press **Enter** to chat, and
   **Trade** next to a name to swap items and gold.
4. The day ends when **everyone** has gone to bed (anyone still up at 2am passes out). The whole
   world moves to the next morning together.
5. If the host leaves while others are playing, the longest-connected player becomes host and the
   world stays open (it keeps saving to the owner's account); the owner takes over again when they
   rejoin with the same code. If everyone leaves, the room closes after 30 seconds.

**What is shared, and who is in charge.** The server holds the shared world: soil and crops, trees,
rocks and bushes, buildings and chest contents, chickens and their eggs, the clock and the weather.
Every change is a request (`world:op`) that the server checks against its own copy, using the same
item, crop and resource rules as the game, before applying it and telling everyone. So two players
can never harvest the same crop, fell the same tree, pick up the same egg or take the same items
from a chest. The server also runs the clock and the morning update: crops grow, soil dries,
sprinklers water, things regrow and chickens lay.

**What each player keeps.** Your backpack, gold, energy, friendships and notice-board progress are
your own. Your game reports them every few seconds. The server checks each report against the game
rules (`validateSave`) and saves it: the host's in their world's save, guests' in `coop_members`.
Come back to the same world later and you have your things.

**Trading** is coordinated by the server:

- Offers are checked against what you last reported having.
- Any change un-accepts both sides.
- When both accept, each side hands over its items and the server confirms both did before
  delivering. If either side can't, whatever was handed over is refunded.

**Movement** is sent ten times a second each way and smoothed on screen. The server rejects moves
faster than running speed (with slack for lag) and snaps the player back.

**Honest limits.**

- The server does not run physics, so it doesn't check walls or water.
- Your own backpack is reported by your game rather than simulated on the server, so a modified
  client could misreport it, as in single-player. The server still enforces every rule about the
  shared world and between players, checks items put into chests and community projects against
  its own copy of your backpack, and rejects reports where gold jumps implausibly.
- Merchants, fishing and cooking work exactly as in single-player, per player.

**Protocol** (`shared/src/net/protocol.ts`, typed on both ends):

| Client → server | Server → client |
| --- | --- |
| `room:host` {save} / `room:join` {code} → `CoopJoin` | `room:members`, `room:positions` (10/s), `room:closed` |
| `player:move`, `player:anim`, `player:state` | `world:op`, `world:chest`, `world:time`, `world:newday` |
| `world:op` (with an `OpAck` reply) | `player:anim`, `player:correct` |
| `sleep:set`, `chat:send` | `sleep:status`, `chat:message`, `notice` |
| `trade:request` / `respond` / `offer` / `confirm` / `cancel` / `ack` | `trade:incoming`, `trade:state`, `trade:commit` / `deliver` / `refund` |

Sign-in uses the same `farm_sid` session cookie as the API. Connections are only accepted from pages
served by the same machine, or from origins in `CORS_ORIGINS`.

## The village market, friendship and more life

- **Five merchants**, each behind their own stall in the market row west of your cottage, each with
  their own hours, goods, prices and swap offers:

  | Merchant | Stall | Hours | Sells | Buys |
  | --- | --- | --- | --- | --- |
  | Mira | Seeds & goods | 8am–6pm | Seeds (by season), chickens | Anything with a price |
  | Rosa | Bakery | 7am–4pm | Bread, berry jam, pumpkin pie | Eggs, berries, crops |
  | Bram | Smithy | 9am–5pm | Copper tools, sprinklers, lamp posts | Stone, copper ore |
  | Finn | Fish stand | 6am–3pm | Fishing rod, grilled fish | Every fish |
  | Willa | Carpentry | 9am–6pm | Fences, paths, chests, benches, flower pots, scarecrows | Wood, fiber |

  The trade panel has Buy, Sell, Trade (swap items) and Gift tabs, and shows your hearts and
  friend discount.
- **Friendship:** hearts (0–10) per villager. A daily chat (+10) and one gift a day (loved +80,
  liked +40, anything else +15) raise them; friends say warmer things and give discounts. The
  notice board's Villagers tab lists everyone's hearts. Hold a gift and press Space on Tobin to
  give it to him; merchants take gifts from the trade panel.
- **Notice board:** two requests a day, chosen from the world seed and the day (everyone in the
  same world sees the same ones), paying gold plus friendship with whoever asked.
- **Fishing:** sunfish all year, trout in spring and fall, catfish at night or in the rain, and a
  rare golden carp. Reeling in too early or too late loses the fish; walking away reels in.
- **Cooking:** veggie soup, berry jam, grilled fish, omelette and pumpkin pie, in a new Cooking tab.
- **Sprinklers** water the four plots next to them every morning. **Benches** let you sit for a
  short break (+15 energy, 30 minutes). **Flower pots** and **scarecrows** are decoration.
- **Liveliness:** speech bubbles as villagers chat to themselves when you're close, ducks paddling
  on ponds, butterflies on sunny spring and summer days, fireflies on warm nights, and leaves
  drifting down in fall.
- **Older saves** get the new stalls and notice board automatically (anything growing in the
  market area is cleared).

## World map, eating and easier farming

- **World map (M, or the Map button):** the whole world drawn from live state: terrain, forests,
  rocks and copper, your cottage, Mira's stall, farmland (crops ready to harvest in yellow),
  your buildings, villagers and chickens, with a pulsing "you are here" marker.
- **Eating:** F eats the selected food from anywhere, right-click a food slot in the hotbar or
  inventory, or use the Eat button in the inventory. New games start with some berries.
- **Farming:** seeds can be planted straight onto grass ("Till & plant"); new games start with a
  tilled 3×3 plot next to the cottage. Facing a growing crop shows its progress on the action
  button ("Turnip · ready in 3 days · needs water"); mature crops show "Harvest".

## Sound and the action button

- **Floating action button:** whatever you face (tree, rock, crop, chest, NPC, chicken, stall, bed,
  empty soil…) gets a button above it showing the action and its key ("Space · Chop",
  "E · Talk to Mira"). Click it or press the key; blocked actions show in red with the reason.
  Its position is written straight to the DOM each frame, so it follows smoothly without React
  re-renders.
- **Sound, all synthesised in code** (`game-engine/audio/`, no audio files):
  - ~27 effects: chop, mine, wrong-tool clunk, tree fall, rock break, grass swish, berry rustle,
    till, water, refill, plant, harvest, fertilizer sparkle, item pickup, place/pick up, tool whoosh,
    eat, coins, craft, error, menu open/close, dialogue, chicken clucks, footsteps (grass, path,
    wood and snow sound different), going to bed, morning chime.
  - Ambience: birdsong on fair days, crickets on warm nights, rain and wind loops that fade with
    the weather, placed around you in stereo.
  - Music: a gentle generative score in a different key and mood each season, sparser at night.
  - Volume sliders (master, music, effects, ambience) and mute (Shift+M) in the pause menu;
    remembered in the browser.

## What Phase 4 adds

- **Accounts:** register / log in / log out. Passwords hashed with scrypt (Node built-in);
  sessions are random tokens in an `httpOnly`, `SameSite=Lax` cookie, stored server-side only as a
  SHA-256 hash, 30-day expiry with cleanup. Login and registration are rate-limited, and login
  timing doesn't reveal whether a username exists.
- **Profiles:** display name and a default character look for new worlds; stats across worlds.
- **Cloud saves:** signed-in players save to the server and to the browser at the same time.
  Loading uses whichever copy is newer and uploads a newer offline copy. The server rejects saves
  older than the one it has (409), so an old tab can't overwrite newer progress. Guests keep
  browser-only saves.
- **Validation:** every uploaded save is checked against the shared rules (known items, stack
  limits, map bounds, crop stages, chest sizes, value ranges) before it is stored.
- **Database (PostgreSQL):** embedded by default (PGlite, nothing to install) or any PostgreSQL
  server via `DATABASE_URL`, behind one small interface. Tables: `users`, `sessions`, `profiles`,
  `worlds` (full save as JSONB plus day/gold/earnings columns) and `inventory_items` (backpack and
  every chest, one row per slot, for queries and future trading). Plain SQL migrations, applied
  automatically.
- **APIs:**

  | Method & path | Purpose |
  | --- | --- |
  | `GET /api/health` | Service + database status |
  | `GET /api/game-data` | Items, crops, recipes, resources, placeables, NPCs, time and weather rules |
  | `POST /api/auth/register` · `login` · `logout`, `GET /api/auth/me` | Accounts and session |
  | `GET` / `PATCH /api/profile` | Profile and stats |
  | `GET /api/worlds` | Saved worlds (summaries) |
  | `GET` / `PUT` / `DELETE /api/worlds/:seed` | Load / save / delete one world |
  | `GET /api/worlds/:seed/inventory` | Normalised inventory rows for a world |
- **Menus in Next.js:** title screen, login/register, profile; "Save & quit to title" in-game.
- **Resilience:** the backend keeps running if the database is unavailable, reports it on
  `/api/health`, reconnects automatically, and the game falls back to browser saves.

## What Phase 3 adds

- **Time:** a 06:00–02:00 day clock, sleeping in the cottage, passing out at 2am, 4 seasons of
  10 days, years. Menus pause time.
- **Day/night lighting:** dusk and night overlays with lights cut out for lamp posts, cottage windows
  and the player's lantern (canvas light map, redrawn only when something changes).
- **Weather:** sunny, cloudy, rain (waters crops) and snow, rolled per day from the seed.
- **Seasons:** seasonal foliage for every tree, bush and tuft of grass, autumn ground colours,
  snow-covered ground in winter, seasonal crops and shop stock.
- **Energy:** tools cost energy; food restores it; sleep refills it.
- **Building:** fences, wood and stone paths, lamp posts, chests (20-slot storage); placement
  preview; pick-up with the pickaxe; the player's cottage.
- **NPCs:** Mira (merchant, keeps shop hours behind her stall) and Tobin (walks the path); both talk,
  with lines that react to season and weather.
- **Animals:** wild rabbits that flee and hide at night; chickens you buy, release and pet, which lay
  eggs every morning.
- **Progression:** shop items unlock with lifetime earnings; resources regrow over days.
- **Saving:** full game state (player, inventory, chests, farm, buildings, resources and pending
  regrowth, chickens, time, weather) saved to local storage per world, via a `SaveStore`
  interface that Phase 4 can back with the API. Pause menu: save now, new game.
- **Character customisation:** skin, hair, shirt and trousers, applied live.

## What Phase 2 adds

- Facing-tile targeting with a cursor and a contextual hint ("Space · Chop", "E · Shop").
- Tool swings with impact timing, hit shake, particle bursts, toppling trees.
- Resource nodes with HP and tool requirements; trees leave stumps; everything respawns
  (never on top of the player or on soil you've tilled).
- Dropped items that pop out, get pulled to the player, and merge into the inventory.
- 30-slot stacking inventory with a 10-slot hotbar, drag & drop, and pickup toasts.
- Farming: tilled soil layer, dry/wet soil, three crops with stage art, growth, harvest.
- Crafting (5 recipes, copper tool upgrades) and a merchant to buy seeds and sell goods.
- All new art (18 item icons, crop stages, soil, stall, copper ore, particles) is procedural.

## What Phase 1 includes

- Seeded world (96×72 tiles): ponds, a winding river, a path with a bridge, forests (oak/pine),
  rocks, bushes, stumps, tall grass, flower meadows, and a clearing at spawn.
- Autotiled shorelines and path borders (16 edge variants each).
- Player with 4-direction walk cycles, running, shadow, and world-bound clamping.
- Arcade Physics collisions with water and obstacles.
- Smooth-follow camera clamped to the world; responsive to window size.
- Ambient touches: water glints, tall grass that sways when walked through, canopy fade.
- HUD showing seed, terrain/tile under the player, and FPS.

## Next steps

1. **Fully server-owned backpacks:** the server now checks and updates its copy of each
   backpack for chests and projects, but crafting, shopping and harvesting still happen on the
   player's side and are reported; moving those onto the server would close the remaining gaps.
2. **Public lobbies** and friends lists, instead of invite codes.
3. **Server physics** (collision against the map) for stricter movement checks.
4. **Menus by gamepad** — the pad plays the game and closes menus, but can't yet move through
   menu buttons.
5. **More areas** — a forest with foraging, a deeper skull cavern below the mine.
