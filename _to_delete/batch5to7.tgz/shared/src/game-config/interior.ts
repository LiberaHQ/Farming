/** Furniture for the cottage interior. */
export type FurnitureKind = 'rug' | 'table' | 'chair' | 'bookshelf' | 'house_plant' | 'floor_lamp' | 'painting';

export interface FurnitureDef {
  kind: FurnitureKind;
  /** Footprint in tiles. */
  width: number;
  height: number;
  /** Rugs lie on the floor (walkable, drawn under everything); paintings hang on the wall. */
  layer: 'floor' | 'object' | 'wall';
  /** Casts light at night. */
  light?: boolean;
}

export const FURNITURE: Record<FurnitureKind, FurnitureDef> = {
  rug: { kind: 'rug', width: 3, height: 2, layer: 'floor' },
  table: { kind: 'table', width: 2, height: 1, layer: 'object' },
  chair: { kind: 'chair', width: 1, height: 1, layer: 'object' },
  bookshelf: { kind: 'bookshelf', width: 2, height: 1, layer: 'object' },
  house_plant: { kind: 'house_plant', width: 1, height: 1, layer: 'object' },
  floor_lamp: { kind: 'floor_lamp', width: 1, height: 1, layer: 'object', light: true },
  painting: { kind: 'painting', width: 2, height: 1, layer: 'wall' },
};

export const FURNITURE_KINDS = Object.keys(FURNITURE) as FurnitureKind[];

/** Room size in tiles (including the walls) for each cottage level. */
export const COTTAGE_ROOMS = [
  { width: 11, height: 8 },
  { width: 16, height: 10 },
] as const;

export interface InteriorSave {
  level: number;
  furniture: Array<{ kind: FurnitureKind; tx: number; ty: number }>;
}
