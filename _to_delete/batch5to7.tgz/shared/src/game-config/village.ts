import type { ItemAmount } from './recipes';
import type { NpcId } from './npcs';
import type { Season } from './time';
import { dayOfSeason, seasonOfDay } from './time';

// ---------- Festivals ----------

export type FestivalId = 'egg_festival' | 'fishing_derby' | 'harvest_fair' | 'winter_lights';

export interface FestivalDef {
  id: FestivalId;
  name: string;
  season: Season;
  /** Day of the season. */
  day: number;
  /** One line for the notice board and the morning toast. */
  tagline: string;
  /** What to do. */
  details: string;
}

export const FESTIVALS: Record<FestivalId, FestivalDef> = {
  egg_festival: {
    id: 'egg_festival',
    name: 'Egg Festival',
    season: 'spring',
    day: 8,
    tagline: 'Painted eggs are hidden around the market!',
    details: 'Find painted eggs hidden around the market. Rosa swaps 8 of them for a Golden Egg.',
  },
  fishing_derby: {
    id: 'fishing_derby',
    name: 'Fishing Derby',
    season: 'summer',
    day: 8,
    tagline: 'Finn pays double for every fish today!',
    details: 'Catch what you can — Finn pays double for fish all day.',
  },
  harvest_fair: {
    id: 'harvest_fair',
    name: 'Harvest Fair',
    season: 'fall',
    day: 8,
    tagline: 'Enter your best crop at the notice board!',
    details: 'Enter one crop at the notice board. The judges pay three times its value and award a ribbon.',
  },
  winter_lights: {
    id: 'winter_lights',
    name: 'Festival of Winter Lights',
    season: 'winter',
    day: 8,
    tagline: 'Lanterns at the market — gifts mean twice as much today.',
    details: 'Lanterns light the market tonight, and every gift earns double friendship.',
  },
};

/** The festival on a given day, if any. */
export function festivalOn(day: number): FestivalDef | null {
  const season = seasonOfDay(day);
  const dos = dayOfSeason(day);
  return Object.values(FESTIVALS).find((f) => f.season === season && f.day === dos) ?? null;
}

/** Painted eggs hidden for the Egg Festival. */
export const EGG_HUNT = { count: 10, trade: 8 } as const;

// ---------- Heart events ----------

export interface HeartEvent {
  hearts: number;
  lines: readonly string[];
  /** Sent by mail afterwards. */
  gift?: ItemAmount;
}

export const HEART_EVENTS: Record<NpcId, readonly HeartEvent[]> = {
  mira: [
    { hearts: 2, lines: ['Can I tell you something? I almost closed this stall last spring.', 'Then you showed up and started farming. Business has never been better!'], gift: { itemId: 'carrot_seeds', quantity: 5 } },
    { hearts: 4, lines: ['My grandmother started this stall with one sack of turnip seeds.', 'I keep her old seed tin under the counter. For luck.', "I'd like you to have some of what I saved. Plant them well."], gift: { itemId: 'pumpkin_seeds', quantity: 5 } },
    { hearts: 6, lines: ["You know what? You're not a customer anymore.", "You're a friend. The best one this market has."], gift: { itemId: 'golden_carp', quantity: 1 } },
  ],
  rosa: [
    { hearts: 2, lines: ['I burned three loaves this morning.', "Don't tell anyone. Here — the good ones are for you."], gift: { itemId: 'bread', quantity: 3 } },
    { hearts: 4, lines: ['Every pie I bake has a little secret ingredient.', '…It’s cinnamon. Everyone knows. But I like that you listened.'], gift: { itemId: 'pumpkin_pie', quantity: 1 } },
    { hearts: 6, lines: ["When I was little I wanted to bake for the whole valley.", "Now I do. And you're my favourite taster."], gift: { itemId: 'berry_jam', quantity: 3 } },
  ],
  bram: [
    { hearts: 2, lines: ['Hmph. You swing a pickaxe like you mean it.', 'Take this ore. Better in your hands than gathering dust.'], gift: { itemId: 'copper_ore', quantity: 10 } },
    { hearts: 4, lines: ['My father forged the bridge rails over the river.', "Forty years and they haven't rusted. That's what good work looks like."], gift: { itemId: 'iron_ore', quantity: 6 } },
    { hearts: 6, lines: ["I don't say this often.", "You've earned a smith's respect. Come to me if anything ever needs mending."], gift: { itemId: 'gold_ore', quantity: 4 } },
  ],
  finn: [
    { hearts: 2, lines: ['Shh — the trout are rising.', '…There. Gone. You have to be patient with the river.'], gift: { itemId: 'grilled_fish', quantity: 2 } },
    { hearts: 4, lines: ['I once saw a golden carp as long as my arm.', "Nobody believes me. You do, though, don't you?"], gift: { itemId: 'trout', quantity: 3 } },
    { hearts: 6, lines: ["Here's a secret: catfish bite best in the rain at night.", "Don't tell the other anglers. Not that there are any."], gift: { itemId: 'catfish', quantity: 3 } },
  ],
  willa: [
    { hearts: 2, lines: ['Wood remembers how it grew. You can see it in the grain.', 'Here, some offcuts. Too nice to burn.'], gift: { itemId: 'wood', quantity: 25 } },
    { hearts: 4, lines: ['I built half the benches in this valley.', 'Sit on one sometime and think of me. Or don’t. They’re comfy either way.'], gift: { itemId: 'bench', quantity: 1 } },
    { hearts: 6, lines: ["I've been making something for you.", 'A chest, with your initials carved in. Every farm needs one more chest.'], gift: { itemId: 'chest', quantity: 2 } },
  ],
  tobin: [
    { hearts: 2, lines: ['When I was your age this whole meadow was wheat.', 'Nice to see it farmed again.'], gift: { itemId: 'wheat_seeds', quantity: 10 } },
    { hearts: 4, lines: ['My knees tell me when rain is coming.', 'Tomorrow? Maybe. Ask me again in the morning.'], gift: { itemId: 'veggie_soup', quantity: 1 } },
    { hearts: 6, lines: ["You've made an old man very happy, you know.", 'This valley needed someone like you.'], gift: { itemId: 'amethyst', quantity: 2 } },
  ],
};

// ---------- Mail ----------

export interface Letter {
  id: number;
  day: number;
  from: string;
  subject: string;
  body: string;
  attachment?: ItemAmount;
  read: boolean;
  claimed: boolean;
}

export const MAX_LETTERS = 30;

/** Little things friends (4+ hearts) sometimes send. */
export const FRIEND_GIFTS: Record<NpcId, ItemAmount> = {
  mira: { itemId: 'turnip_seeds', quantity: 5 },
  rosa: { itemId: 'bread', quantity: 2 },
  bram: { itemId: 'copper_ore', quantity: 5 },
  finn: { itemId: 'grilled_fish', quantity: 1 },
  willa: { itemId: 'wood', quantity: 15 },
  tobin: { itemId: 'berries', quantity: 6 },
};
/** Chance per friend per morning. */
export const FRIEND_GIFT_CHANCE = 0.12;
