import type { CropId, ItemId } from '@farming/shared';
import { P } from './palette';
import { PixelCanvas } from './PixelCanvas';

/**
 * 16x16 item icons. Pure drawing code (no Phaser), so the same art is used
 * by the game (dropped items, the tool in the player's hand) and by the React
 * UI (hotbar, inventory, shop) via data URLs.
 */

const METAL = { base: '#b9c0c6', light: '#eef1f3', dark: '#7d858d' };
const COPPER = { base: '#d9823b', light: '#f4b07a', dark: '#9c5525' };
const CAN = { base: '#5f97bb', light: '#9cc8e0', dark: '#3f6f8f' };
const PAPER = { base: '#eadfc4', dark: '#c9b993' };
const ORANGE = { base: '#e8812f', light: '#f6a95c', dark: '#b8601c' };
const TURNIP = { white: '#f3efe6', purple: '#a35bb5', purpleLight: '#c487d2' };
const SACK = { base: '#9c7a4f', light: '#b8956a', dark: '#765a37' };

type Metal = typeof METAL;

function handle(p: PixelCanvas, x: number, top: number, bottom: number): void {
  for (let y = top; y <= bottom; y++) {
    p.set(x, y, P.wood);
    p.set(x + 1, y, P.woodDark);
  }
}

function axe(p: PixelCanvas, m: Metal): void {
  handle(p, 8, 3, 14);
  p.rect(3, 2, 5, 5, m.base);
  p.rect(3, 2, 1, 5, m.light);
  p.rect(4, 6, 4, 1, m.dark);
  p.rect(7, 3, 1, 3, m.dark);
}

function pickaxe(p: PixelCanvas, m: Metal): void {
  handle(p, 7, 4, 14);
  p.rect(4, 2, 8, 1, m.light);
  p.rect(3, 3, 10, 2, m.base);
  p.rect(5, 4, 6, 1, m.dark);
  p.set(2, 4, m.base);
  p.set(2, 5, m.dark);
  p.set(13, 4, m.base);
  p.set(13, 5, m.dark);
}

function hoe(p: PixelCanvas): void {
  handle(p, 8, 2, 14);
  p.rect(3, 2, 5, 2, METAL.base);
  p.rect(3, 2, 5, 1, METAL.light);
  p.rect(3, 4, 2, 2, METAL.dark);
}

function wateringCan(p: PixelCanvas): void {
  p.rect(3, 6, 8, 7, CAN.base);
  p.rect(3, 6, 1, 7, CAN.light);
  p.rect(10, 6, 1, 7, CAN.dark);
  p.rect(3, 12, 8, 1, CAN.dark);
  p.rect(4, 4, 6, 1, CAN.dark);
  p.set(4, 5, CAN.dark);
  p.set(9, 5, CAN.dark);
  for (let i = 0; i < 4; i++) {
    p.set(11 + i, 9 - i, CAN.base);
    p.set(11 + i, 10 - i, CAN.dark);
  }
  p.set(14, 4, CAN.light);
}

function log(p: PixelCanvas): void {
  p.rect(2, 6, 10, 1, P.trunkLight);
  p.rect(2, 7, 10, 3, P.trunk);
  p.rect(2, 10, 10, 1, P.trunkDark);
  p.set(5, 8, P.trunkDark);
  p.set(8, 7, P.trunkDark);
  p.rect(12, 6, 2, 5, P.woodLight);
  p.set(12, 8, P.wood);
  p.set(13, 6, P.wood);
  // second log behind
  p.rect(4, 3, 9, 1, P.trunkLight);
  p.rect(4, 4, 9, 2, P.trunk);
  p.rect(13, 3, 2, 3, P.woodLight);
}

function stoneBlob(p: PixelCanvas, speck?: { base: string; light: string }): void {
  for (let y = 4; y <= 13; y++) {
    for (let x = 2; x <= 13; x++) {
      const nx = (x - 7.5) / 5.5;
      const ny = (y - 9) / 4.5;
      if (nx * nx + ny * ny > 1) continue;
      const l = -(nx * 0.55 + ny * 0.85);
      p.set(x, y, l > 0.4 ? P.stoneLight : l < -0.35 ? P.stoneDark : P.stone);
    }
  }
  p.set(6, 6, P.stoneHi);
  if (speck) {
    // Chunky copper nuggets so ore reads clearly at icon size.
    for (const [x, y] of [
      [4, 8],
      [8, 6],
      [9, 10],
    ] as const) {
      p.rect(x, y, 2, 2, speck.base);
      p.set(x, y, speck.light);
      p.set(x + 1, y + 1, COPPER.dark);
    }
  }
}

function fiber(p: PixelCanvas): void {
  for (let x = 5; x <= 10; x++) {
    for (let y = 2; y <= 14; y++) {
      const lean = y < 8 ? Math.round((x - 7.5) * ((8 - y) / 6)) : 0;
      p.set(x + lean, y, (x + y) % 2 === 0 ? P.grassLight : P.grass);
    }
  }
  p.rect(5, 8, 6, 2, P.wood);
  p.rect(5, 9, 6, 1, P.woodDark);
}

function berries(p: PixelCanvas): void {
  const dots: Array<[number, number]> = [
    [5, 9],
    [10, 9],
    [7, 12],
  ];
  for (const [cx, cy] of dots) {
    for (let y = -2; y <= 2; y++) for (let x = -2; x <= 2; x++) if (x * x + y * y <= 4) p.set(cx + x, cy + y, P.berry);
    p.set(cx - 1, cy - 1, P.berryHi);
  }
  p.rect(7, 3, 2, 3, P.leafDark);
  p.rect(5, 3, 2, 2, P.leaf);
  p.rect(9, 3, 2, 2, P.leafLight);
}

function turnip(p: PixelCanvas, x0 = 0, y0 = 0, s = 1): void {
  for (let y = -4; y <= 4; y++) {
    for (let x = -4; x <= 4; x++) {
      if (x * x + y * y > 17) continue;
      const c = y < 0 ? (x < -1 ? TURNIP.purpleLight : TURNIP.purple) : TURNIP.white;
      p.set(x0 + 8 + x * s, y0 + 10 + y * s, c);
    }
  }
  p.rect(x0 + 6, y0 + 2, 2, 4, P.leaf);
  p.rect(x0 + 9, y0 + 3, 2, 3, P.leafLight);
}

function carrot(p: PixelCanvas): void {
  for (let y = 5; y <= 14; y++) {
    const half = Math.max(0, Math.round(3 - (y - 5) * 0.33));
    for (let x = 8 - half; x <= 8 + half; x++) p.set(x, y, x === 8 + half ? ORANGE.dark : ORANGE.base);
    if (half > 0) p.set(8 - half, y, ORANGE.light);
  }
  p.set(7, 8, ORANGE.dark);
  p.set(9, 11, ORANGE.dark);
  p.rect(6, 1, 1, 4, P.leaf);
  p.rect(8, 1, 1, 4, P.leafLight);
  p.rect(10, 2, 1, 3, P.leaf);
}

function pumpkin(p: PixelCanvas, cx = 7.5, cy = 9.5, rx = 6, ry = 4.5): void {
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const nx = (x - cx) / rx;
      const ny = (y - cy) / ry;
      if (nx * nx + ny * ny > 1) continue;
      let c = ORANGE.base;
      if (Math.abs(x - cx + 2.5) < 0.6 || Math.abs(x - cx - 2.5) < 0.6) c = ORANGE.dark;
      else if (nx < -0.4 && ny < 0.2) c = ORANGE.light;
      if (ny > 0.75) c = ORANGE.dark;
      p.set(x, y, c);
    }
  }
  p.rect(Math.round(cx) - 1, Math.round(cy - ry) - 2, 2, 3, P.trunk);
  p.set(Math.round(cx) + 1, Math.round(cy - ry) - 2, P.leaf);
}

function seedPacket(p: PixelCanvas, crop: CropId): void {
  p.rect(4, 2, 8, 12, PAPER.base);
  p.rect(4, 2, 8, 2, PAPER.dark);
  p.rect(11, 4, 1, 10, PAPER.dark);
  // picture of the crop
  const pic = new PixelCanvas(16, 16);
  if (crop === 'turnip') {
    pic.rect(6, 7, 4, 2, TURNIP.purple);
    pic.rect(6, 9, 4, 2, TURNIP.white);
    pic.rect(7, 5, 2, 2, P.leaf);
  } else if (crop === 'carrot') {
    pic.rect(7, 7, 2, 4, ORANGE.base);
    pic.set(7, 11, ORANGE.base);
    pic.rect(7, 5, 2, 2, P.leaf);
  } else {
    pic.rect(5, 7, 6, 4, ORANGE.base);
    pic.set(7, 7, ORANGE.dark);
    pic.rect(7, 5, 2, 2, P.trunk);
  }
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) if (pic.filled(x, y)) p.copyPixel(pic, x, y, x, y);
  p.set(6, 12, P.trunkDark);
  p.set(8, 12, P.trunkDark);
  p.set(10, 12, P.trunkDark);
}

function fertilizer(p: PixelCanvas): void {
  p.rect(4, 5, 8, 9, SACK.base);
  p.rect(4, 5, 1, 9, SACK.light);
  p.rect(11, 5, 1, 9, SACK.dark);
  p.rect(5, 3, 6, 2, SACK.base);
  p.rect(6, 4, 4, 1, SACK.dark);
  p.rect(6, 8, 4, 3, P.leaf);
  p.set(7, 8, P.leafHi);
  p.set(8, 11, P.leafDark);
}

function egg(p: PixelCanvas): void {
  for (let y = 3; y <= 13; y++) {
    for (let x = 3; x <= 12; x++) {
      const nx = (x - 7.5) / 4.5;
      const ny = (y - 8.5) / (y < 8.5 ? 5.5 : 4.5);
      if (nx * nx + ny * ny > 1) continue;
      p.set(x, y, nx < -0.3 && ny < 0 ? '#fffdf6' : ny > 0.5 || nx > 0.55 ? '#d9cbb0' : '#f3ead8');
    }
  }
  p.set(6, 5, '#ffffff');
}

function fenceIcon(p: PixelCanvas): void {
  for (const y of [6, 10]) {
    p.rect(1, y, 14, 1, P.woodLight);
    p.rect(1, y + 1, 14, 1, P.woodDark);
  }
  for (const x of [3, 11]) {
    p.rect(x, 3, 2, 11, P.wood);
    p.set(x, 3, P.woodLight);
    p.rect(x + 1, 4, 1, 10, P.woodDark);
  }
}

function pathIcon(p: PixelCanvas, stone: boolean): void {
  if (stone) {
    for (const [x, y, w, h] of [
      [2, 3, 5, 4],
      [8, 2, 6, 5],
      [2, 8, 6, 5],
      [9, 8, 5, 5],
    ] as const) {
      p.rect(x, y, w, h, P.stone);
      p.rect(x, y, w, 1, P.stoneHi);
      p.rect(x, y + h - 1, w, 1, P.stoneDark);
    }
  } else {
    for (let y = 3; y <= 12; y++) p.rect(2, y, 12, 1, y % 3 === 2 ? P.woodDark : y % 3 === 0 ? P.woodLight : P.wood);
  }
}

function lampIcon(p: PixelCanvas): void {
  p.rect(7, 7, 2, 7, '#3b3b45');
  p.rect(5, 13, 6, 1, P.stoneDark);
  p.rect(5, 2, 6, 5, '#3b3b45');
  p.rect(6, 3, 4, 3, '#ffe9a8');
  p.set(6, 3, '#fff6d6');
}

function chestIcon(p: PixelCanvas): void {
  p.rect(2, 7, 12, 7, P.wood);
  p.rect(2, 3, 12, 4, P.woodLight);
  p.rect(2, 6, 12, 1, P.woodDark);
  p.rect(2, 13, 12, 1, P.woodDark);
  for (const x of [4, 11]) p.rect(x, 3, 1, 11, '#9c5525');
  p.rect(7, 6, 2, 3, '#e8c25a');
}

function chickenIcon(p: PixelCanvas): void {
  for (let y = 6; y <= 13; y++) {
    for (let x = 3; x <= 13; x++) {
      const nx = (x - 8.5) / 5;
      const ny = (y - 10) / 3.5;
      if (nx * nx + ny * ny <= 1) p.set(x, y, ny > 0.4 ? '#d6d0c4' : '#f4f1ea');
    }
  }
  for (let y = 2; y <= 7; y++) for (let x = 3; x <= 7; x++) if ((x - 5) ** 2 + (y - 5) ** 2 <= 5) p.set(x, y, '#f4f1ea');
  p.rect(4, 1, 3, 1, '#d2404c');
  p.set(2, 5, '#e8a33a');
  p.set(4, 4, P.eye);
  p.set(13, 7, '#f4f1ea');
}

function fishingRod(p: PixelCanvas): void {
  for (let i = 0; i < 11; i++) {
    p.set(3 + i, 13 - i, i < 4 ? P.woodDark : P.wood);
  }
  p.rect(3, 11, 2, 2, P.trunkDark); // handle
  p.set(5, 10, '#b9c0c6'); // reel
  for (let y = 3; y <= 9; y++) p.set(14, y, '#e6e1d8'); // line
  p.set(14, 10, P.berry); // bobber
  p.set(14, 11, '#ffffff');
}

function fish(p: PixelCanvas, body: string, belly: string, fin: string): void {
  for (let y = 5; y <= 11; y++) {
    for (let x = 2; x <= 11; x++) {
      const nx = (x - 6.5) / 4.5;
      const ny = (y - 8) / 3;
      if (nx * nx + ny * ny > 1) continue;
      p.set(x, y, y > 8 ? belly : body);
    }
  }
  // tail
  p.rect(12, 6, 1, 5, fin);
  p.rect(13, 5, 1, 2, fin);
  p.rect(13, 10, 1, 2, fin);
  p.set(6, 4, fin); // dorsal fin
  p.set(7, 4, fin);
  p.set(4, 7, P.eye);
}

function bread(p: PixelCanvas): void {
  for (let y = 5; y <= 12; y++) {
    for (let x = 2; x <= 13; x++) {
      const nx = (x - 7.5) / 6;
      const ny = (y - 9) / 4;
      if (nx * nx + ny * ny > 1) continue;
      p.set(x, y, y < 8 ? '#d9a05a' : '#c08442');
    }
  }
  for (const x of [5, 8, 11]) p.set(x, 7, '#f0d199');
}

function bowl(p: PixelCanvas, soup: string, bits: string): void {
  p.rect(2, 8, 12, 1, soup);
  p.rect(3, 9, 10, 3, '#e6e1d8');
  p.rect(4, 12, 8, 1, '#bdb5a3');
  p.rect(5, 13, 6, 1, '#bdb5a3');
  p.set(5, 8, bits);
  p.set(9, 8, bits);
  p.set(7, 5, '#e6e1d8');
  p.set(8, 4, '#e6e1d8');
}

function jar(p: PixelCanvas): void {
  p.rect(4, 4, 8, 2, P.woodLight);
  p.rect(4, 6, 8, 8, '#a8304a');
  p.rect(5, 7, 2, 5, '#d2506a');
  p.rect(6, 9, 4, 2, '#f1e3c4');
}

function grilledFish(p: PixelCanvas): void {
  fish(p, '#b8763a', '#d9a05a', '#8a5426');
  for (const x of [5, 7, 9]) p.set(x, 7, '#6b4222');
  p.rect(1, 12, 14, 1, '#e6e1d8');
}

function omelette(p: PixelCanvas): void {
  p.rect(2, 9, 12, 3, '#e6e1d8');
  for (let y = 6; y <= 10; y++) for (let x = 3; x <= 12; x++) if (((x - 7.5) / 5) ** 2 + ((y - 9) / 3) ** 2 <= 1) p.set(x, y, y < 8 ? '#f6d65a' : '#e8b83a');
  p.set(6, 7, P.leafLight);
  p.set(9, 8, P.leafLight);
}

function pie(p: PixelCanvas): void {
  p.rect(2, 10, 12, 3, '#c08442');
  for (let y = 6; y <= 10; y++) for (let x = 2; x <= 13; x++) if (((x - 7.5) / 6) ** 2 + ((y - 10) / 4) ** 2 <= 1) p.set(x, y, y < 9 ? '#e58a2c' : '#c96d1c');
  p.rect(2, 9, 12, 1, '#d9a05a');
  p.set(7, 7, '#f6a95c');
}

function sprinklerIcon(p: PixelCanvas): void {
  p.rect(6, 7, 4, 7, '#9c5525');
  p.rect(6, 7, 1, 7, '#d9823b');
  p.rect(4, 5, 8, 2, '#b9c0c6');
  p.rect(7, 3, 2, 2, '#b9c0c6');
  for (const [x, y] of [
    [2, 3],
    [13, 3],
    [1, 6],
    [14, 6],
  ] as const) p.set(x, y, '#58a4d2');
}

function benchIcon(p: PixelCanvas): void {
  p.rect(2, 6, 12, 2, P.woodLight);
  p.rect(2, 8, 12, 1, P.woodDark);
  p.rect(2, 3, 12, 2, P.wood);
  p.rect(3, 9, 2, 5, P.woodDark);
  p.rect(11, 9, 2, 5, P.woodDark);
}

function flowerPotIcon(p: PixelCanvas): void {
  p.rect(4, 9, 8, 5, '#b8603a');
  p.rect(3, 9, 10, 1, '#d07a4a');
  p.rect(7, 5, 2, 4, P.leaf);
  for (const [x, y, c] of [
    [5, 4, P.flowerPink],
    [10, 4, P.flowerYellow],
    [7, 2, P.flowerBlue],
  ] as const) {
    p.rect(x, y, 2, 2, c);
  }
}

function scarecrowIcon(p: PixelCanvas): void {
  p.rect(7, 6, 2, 9, P.woodDark);
  p.rect(2, 7, 12, 2, P.wood);
  p.rect(5, 6, 6, 5, '#8a5aa8');
  p.rect(6, 2, 4, 4, '#e8c47a');
  p.rect(4, 1, 8, 2, '#8a6a2c');
  p.set(7, 3, P.eye);
  p.set(9, 3, P.eye);
}

const DRAW: Record<ItemId, (p: PixelCanvas) => void> = {
  axe: (p) => axe(p, METAL),
  pickaxe: (p) => pickaxe(p, METAL),
  hoe,
  watering_can: wateringCan,
  copper_axe: (p) => axe(p, COPPER),
  copper_pickaxe: (p) => pickaxe(p, COPPER),
  wood: log,
  stone: (p) => stoneBlob(p),
  copper_ore: (p) => stoneBlob(p, { base: COPPER.base, light: COPPER.light }),
  fiber,
  berries,
  turnip_seeds: (p) => seedPacket(p, 'turnip'),
  carrot_seeds: (p) => seedPacket(p, 'carrot'),
  pumpkin_seeds: (p) => seedPacket(p, 'pumpkin'),
  turnip: (p) => turnip(p),
  carrot,
  pumpkin: (p) => pumpkin(p),
  fertilizer,
  egg,
  fence: fenceIcon,
  wood_path: (p) => pathIcon(p, false),
  stone_path: (p) => pathIcon(p, true),
  lamp_post: lampIcon,
  chest: chestIcon,
  chicken: chickenIcon,
  fishing_rod: fishingRod,
  sunfish: (p) => fish(p, '#e8b83a', '#f6d65a', '#d2553f'),
  trout: (p) => fish(p, '#7a9a6a', '#d9c7b0', '#5a7a4a'),
  catfish: (p) => fish(p, '#6b5a4a', '#a8957f', '#4a3d31'),
  golden_carp: (p) => fish(p, '#f4c24a', '#fff0a8', '#e8812f'),
  bread,
  veggie_soup: (p) => bowl(p, '#d9823b', P.leaf),
  berry_jam: jar,
  grilled_fish: grilledFish,
  omelette,
  pumpkin_pie: pie,
  sprinkler: sprinklerIcon,
  bench: benchIcon,
  flower_pot: flowerPotIcon,
  scarecrow: scarecrowIcon,
};

export function drawItemIcon(id: ItemId): PixelCanvas {
  const p = new PixelCanvas(16, 16);
  DRAW[id](p);
  p.outline(P.outline);
  return p;
}

// Reused by crop sprites.
export const cropArt = { turnip, carrot, pumpkin, ORANGE, TURNIP };
