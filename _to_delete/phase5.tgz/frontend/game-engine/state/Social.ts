import { discountFor, FRIENDSHIP, heartsFor, ITEMS, NPC_IDS, NPCS, type ItemId, type NpcId, type SocialSave } from '@farming/shared';

export type GiftReaction = 'loved' | 'liked' | 'neutral';

export interface FriendView {
  id: NpcId;
  name: string;
  title: string;
  hearts: number;
  /** 0–1 progress towards the next heart. */
  progress: number;
  talkedToday: boolean;
  giftedToday: boolean;
}

const isNpcId = (id: string): id is NpcId => (NPC_IDS as string[]).includes(id);

/**
 * Friendship with the villagers. Pure model: talking once a day and one gift
 * a day raise friendship; hearts unlock friendlier lines and shop discounts.
 */
export class Social {
  private points: Partial<Record<NpcId, number>> = {};
  private talkedDay: Partial<Record<NpcId, number>> = {};
  private giftedDay: Partial<Record<NpcId, number>> = {};

  constructor(private readonly onChange: () => void = () => undefined) {}

  pointsOf(id: NpcId): number {
    return this.points[id] ?? 0;
  }

  hearts(id: NpcId): number {
    return heartsFor(this.pointsOf(id));
  }

  discount(id: NpcId): number {
    return discountFor(this.pointsOf(id));
  }

  talkedToday(id: NpcId, day: number): boolean {
    return this.talkedDay[id] === day;
  }

  giftedToday(id: NpcId, day: number): boolean {
    return this.giftedDay[id] === day;
  }

  /** Records today's chat. Returns the hearts before and after (equal if nothing changed). */
  talk(id: NpcId, day: number): { gained: number; before: number; after: number } {
    const before = this.hearts(id);
    if (this.talkedToday(id, day)) return { gained: 0, before, after: before };
    this.talkedDay[id] = day;
    this.add(id, FRIENDSHIP.talk);
    return { gained: FRIENDSHIP.talk, before, after: this.hearts(id) };
  }

  reactionTo(id: NpcId, itemId: ItemId): GiftReaction {
    const { loved, liked } = NPCS[id].gifts;
    if (loved.includes(itemId)) return 'loved';
    if (liked.includes(itemId)) return 'liked';
    return 'neutral';
  }

  /** Whether an item can be given as a gift at all (not tools or structures). */
  static giftable(itemId: ItemId): boolean {
    const def = ITEMS[itemId];
    return !def.tool && !def.places && !def.releases;
  }

  /** Records a gift (one per villager per day). Null when already gifted today. */
  gift(id: NpcId, itemId: ItemId, day: number): { reaction: GiftReaction; gained: number; before: number; after: number } | null {
    if (this.giftedToday(id, day)) return null;
    const before = this.hearts(id);
    const reaction = this.reactionTo(id, itemId);
    const gained = reaction === 'loved' ? FRIENDSHIP.giftLoved : reaction === 'liked' ? FRIENDSHIP.giftLiked : FRIENDSHIP.giftNeutral;
    this.giftedDay[id] = day;
    this.add(id, gained);
    return { reaction, gained, before, after: this.hearts(id) };
  }

  add(id: NpcId, amount: number): void {
    const max = FRIENDSHIP.maxHearts * FRIENDSHIP.pointsPerHeart;
    this.points[id] = Math.max(0, Math.min(max, this.pointsOf(id) + amount));
    this.onChange();
  }

  view(day: number): FriendView[] {
    return NPC_IDS.map((id) => {
      const pts = this.pointsOf(id);
      const hearts = heartsFor(pts);
      return {
        id,
        name: NPCS[id].name,
        title: NPCS[id].title,
        hearts,
        progress: hearts >= FRIENDSHIP.maxHearts ? 1 : (pts % FRIENDSHIP.pointsPerHeart) / FRIENDSHIP.pointsPerHeart,
        talkedToday: this.talkedToday(id, day),
        giftedToday: this.giftedToday(id, day),
      };
    });
  }

  serialize(): SocialSave {
    return { points: { ...this.points }, talkedDay: { ...this.talkedDay }, giftedDay: { ...this.giftedDay } };
  }

  restore(save: SocialSave | undefined): void {
    this.points = {};
    this.talkedDay = {};
    this.giftedDay = {};
    if (!save) return;
    for (const [id, v] of Object.entries(save.points)) if (isNpcId(id)) this.points[id] = v;
    for (const [id, v] of Object.entries(save.talkedDay)) if (isNpcId(id)) this.talkedDay[id] = v;
    for (const [id, v] of Object.entries(save.giftedDay)) if (isNpcId(id)) this.giftedDay[id] = v;
    this.onChange();
  }
}
