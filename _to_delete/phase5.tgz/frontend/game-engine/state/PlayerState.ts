import {
  APPEARANCE_OPTIONS,
  DEFAULT_APPEARANCE_CHOICE,
  GAME_CONFIG,
  ITEM_IDS,
  ITEMS,
  STARTER_KIT,
  isItemId,
  type AppearanceChoice,
  type AppearancePart,
  type PlayerSave,
} from '@farming/shared';
import { gameEvents } from '../events/GameEventBus';
import { Inventory } from './Inventory';

export type { PlayerSave } from '@farming/shared';

/**
 * Everything the player owns. Kept separate from the Player entity (which is
 * about rendering and movement) so it can be saved, loaded and later synced
 * with the backend without touching Phaser objects.
 */
export class PlayerState {
  readonly inventory: Inventory;
  readonly waterCapacity: number = GAME_CONFIG.farming.wateringCanCapacity;
  readonly maxEnergy: number = GAME_CONFIG.energy.max;
  private goldAmount: number = GAME_CONFIG.economy.startingGold;
  private earnings = 0;
  private waterAmount: number = GAME_CONFIG.farming.wateringCanCapacity;
  private energyAmount: number = GAME_CONFIG.energy.max;
  private look: AppearanceChoice = { ...DEFAULT_APPEARANCE_CHOICE };

  constructor() {
    const { size, hotbarSize } = GAME_CONFIG.inventory;
    this.inventory = new Inventory(size, hotbarSize, () => gameEvents.emit('inventory:changed', this.inventory.snapshot()));
    for (const { itemId, quantity } of STARTER_KIT) this.inventory.add(itemId, quantity);
  }

  get gold(): number {
    return this.goldAmount;
  }

  get lifetimeEarnings(): number {
    return this.earnings;
  }

  get water(): number {
    return this.waterAmount;
  }

  get energy(): number {
    return this.energyAmount;
  }

  get appearance(): AppearanceChoice {
    return { ...this.look };
  }

  /** Income from selling. Also tracks lifetime earnings, which unlock new shop stock. */
  earn(amount: number): void {
    const before = this.earnings;
    this.goldAmount += amount;
    this.earnings += amount;
    this.emitStats();
    for (const id of ITEM_IDS) {
      const unlock = ITEMS[id].unlockAtEarnings;
      if (unlock !== undefined && before < unlock && this.earnings >= unlock) {
        gameEvents.emit('toast', { text: `New at the stall: ${ITEMS[id].name}` });
      }
    }
  }

  /** Gold from another player (a trade): not counted as sales. */
  receiveGold(amount: number): void {
    if (amount <= 0) return;
    this.goldAmount += amount;
    this.emitStats();
  }

  /** Returns false (and changes nothing) if the player cannot afford it. */
  spendGold(amount: number): boolean {
    if (amount > this.goldAmount) return false;
    this.goldAmount -= amount;
    this.emitStats();
    return true;
  }

  useWater(): boolean {
    if (this.waterAmount <= 0) return false;
    this.waterAmount -= 1;
    this.emitStats();
    return true;
  }

  refillWater(): void {
    this.waterAmount = this.waterCapacity;
    this.emitStats();
  }

  /** Returns false (and spends nothing) if there isn't enough energy. */
  spendEnergy(cost: number): boolean {
    if (cost > this.energyAmount) return false;
    this.energyAmount -= cost;
    this.emitStats();
    return true;
  }

  restoreEnergy(amount: number): void {
    this.energyAmount = Math.min(this.maxEnergy, this.energyAmount + amount);
    this.emitStats();
  }

  setEnergyFraction(fraction: number): void {
    this.energyAmount = Math.round(this.maxEnergy * fraction);
    this.emitStats();
  }

  setAppearancePart(part: AppearancePart, index: number): boolean {
    if (!(part in APPEARANCE_OPTIONS) || !Number.isInteger(index)) return false;
    if (index < 0 || index >= APPEARANCE_OPTIONS[part].length) return false;
    this.look = { ...this.look, [part]: index };
    gameEvents.emit('player:appearance', { choice: this.appearance });
    return true;
  }

  emitAll(): void {
    gameEvents.emit('inventory:changed', this.inventory.snapshot());
    gameEvents.emit('player:appearance', { choice: this.appearance });
    this.emitStats();
  }

  serialize(): PlayerSave {
    const snap = this.inventory.snapshot();
    return {
      gold: this.goldAmount,
      lifetimeEarnings: this.earnings,
      energy: this.energyAmount,
      water: this.waterAmount,
      appearance: this.appearance,
      inventory: { slots: snap.slots, selected: snap.selected },
    };
  }

  /** Restores from a save, ignoring anything malformed. */
  restore(save: PlayerSave): void {
    const num = (v: unknown, fallback: number) => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);
    this.goldAmount = Math.max(0, num(save.gold, this.goldAmount));
    this.earnings = Math.max(0, num(save.lifetimeEarnings, 0));
    this.energyAmount = Math.max(0, Math.min(this.maxEnergy, num(save.energy, this.maxEnergy)));
    this.waterAmount = Math.max(0, Math.min(this.waterCapacity, num(save.water, this.waterCapacity)));
    for (const part of Object.keys(APPEARANCE_OPTIONS) as AppearancePart[]) {
      this.setAppearancePart(part, num(save.appearance?.[part], 0));
    }
    const slots = Array.isArray(save.inventory?.slots) ? save.inventory.slots : [];
    for (let i = 0; i < this.inventory.slots.length; i++) {
      const s = slots[i];
      this.inventory.slots[i] =
        s && isItemId(s.itemId) && Number.isInteger(s.quantity) && s.quantity > 0
          ? { itemId: s.itemId, quantity: Math.min(s.quantity, ITEMS[s.itemId].maxStack) }
          : null;
    }
    this.inventory.select(num(save.inventory?.selected, 0));
  }

  private emitStats(): void {
    gameEvents.emit('player:stats', {
      gold: this.goldAmount,
      lifetimeEarnings: this.earnings,
      water: this.waterAmount,
      waterCapacity: this.waterCapacity,
      energy: this.energyAmount,
      maxEnergy: this.maxEnergy,
    });
  }
}
