import * as Phaser from 'phaser';

export interface MoveIntent {
  /** -1, 0 or 1 */
  x: number;
  /** -1, 0 or 1 */
  y: number;
  run: boolean;
}

/** Discrete actions triggered this frame (edge-triggered, not held). */
export interface ActionIntent {
  use: boolean;
  interact: boolean;
  toggleInventory: boolean;
  toggleCrafting: boolean;
  toggleMap: boolean;
  /** Eat the selected food. */
  eat: boolean;
  close: boolean;
  /** Hotbar slot chosen with the number keys, or null. */
  hotbar: number | null;
  /** -1 / +1 from the mouse wheel, or 0. */
  cycle: number;
}

type MoveKey = 'up' | 'down' | 'left' | 'right' | 'w' | 'a' | 's' | 'd' | 'run';
type ActionKey = 'space' | 'j' | 'e' | 'i' | 'tab' | 'c' | 'esc' | 'm' | 'f';

const HOTBAR_KEYS = ['ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'ZERO'] as const;

/** Translates raw keyboard and mouse state into device-independent intents. */
export class InputSystem {
  private readonly move: Record<MoveKey, Phaser.Input.Keyboard.Key>;
  private readonly actions: Record<ActionKey, Phaser.Input.Keyboard.Key>;
  private readonly hotbar: Phaser.Input.Keyboard.Key[];
  private pointerUse = false;
  private wheel = 0;

  constructor(scene: Phaser.Scene) {
    const keyboard = scene.input.keyboard;
    if (!keyboard) throw new Error('Keyboard input is not available');
    const K = Phaser.Input.Keyboard.KeyCodes;
    this.move = keyboard.addKeys(
      { up: K.UP, down: K.DOWN, left: K.LEFT, right: K.RIGHT, w: K.W, a: K.A, s: K.S, d: K.D, run: K.SHIFT },
      true,
    ) as Record<MoveKey, Phaser.Input.Keyboard.Key>;
    this.actions = keyboard.addKeys({ space: K.SPACE, j: K.J, e: K.E, i: K.I, tab: K.TAB, c: K.C, esc: K.ESC, m: K.M, f: K.F }, true) as Record<
      ActionKey,
      Phaser.Input.Keyboard.Key
    >;
    this.hotbar = HOTBAR_KEYS.map((name) => keyboard.addKey(K[name], true));

    scene.input.on(Phaser.Input.Events.POINTER_DOWN, (pointer: Phaser.Input.Pointer) => {
      if (pointer.leftButtonDown()) this.pointerUse = true;
    });
    scene.input.on(Phaser.Input.Events.POINTER_WHEEL, (_p: Phaser.Input.Pointer, _o: unknown, _dx: number, dy: number) => {
      this.wheel += Math.sign(dy);
    });
  }

  getMoveIntent(): MoveIntent {
    const k = this.move;
    const left = k.left.isDown || k.a.isDown;
    const right = k.right.isDown || k.d.isDown;
    const up = k.up.isDown || k.w.isDown;
    const down = k.down.isDown || k.s.isDown;
    return {
      x: (right ? 1 : 0) - (left ? 1 : 0),
      y: (down ? 1 : 0) - (up ? 1 : 0),
      run: k.run.isDown,
    };
  }

  /** Must be called exactly once per frame. */
  getActions(): ActionIntent {
    const pressed = Phaser.Input.Keyboard.JustDown;
    const a = this.actions;
    // Poll every key once, so no key's "just pressed" state lingers to a later frame.
    const hotbarPressed = this.hotbar.map((key) => pressed(key));
    const hotbar = hotbarPressed.indexOf(true);
    const [space, j, i, tab] = [pressed(a.space), pressed(a.j), pressed(a.i), pressed(a.tab)];
    const result: ActionIntent = {
      use: space || j || this.pointerUse,
      interact: pressed(a.e),
      toggleInventory: i || tab,
      toggleCrafting: pressed(a.c),
      // Shift+M is mute (handled by the scene); plain M opens the map.
      toggleMap: pressed(a.m) && !a.m.shiftKey,
      eat: pressed(a.f),
      close: pressed(a.esc),
      hotbar: hotbar >= 0 ? hotbar : null,
      cycle: this.wheel,
    };
    this.pointerUse = false;
    this.wheel = 0;
    return result;
  }
}
