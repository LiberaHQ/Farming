'use client';

import { useGameEvent } from '@/hooks/useGameEvent';

/** Vertical stamina bar beside the hotbar. */
export function EnergyBar() {
  const stats = useGameEvent('player:stats');
  if (!stats) return null;
  const pct = Math.round((stats.energy / stats.maxEnergy) * 100);
  const level = pct > 50 ? 'high' : pct > 20 ? 'mid' : 'low';
  return (
    <div className="energy" title={`Energy ${stats.energy}/${stats.maxEnergy}`}>
      <div className="energy-track">
        <div className={`energy-fill energy-${level}`} style={{ height: `${pct}%` }} />
      </div>
      <span>E</span>
    </div>
  );
}
