'use client';

import Link from 'next/link';
import { useState } from 'react';
import { gameCommands } from '@/game-engine/events/GameEventBus';
import { useGameEvent } from '@/hooks/useGameEvent';
import { Panel } from './Panel';

/** Pause menu: save, customise, controls, new game. */
export function MenuPanel() {
  const save = useGameEvent('save:info');
  const audio = useGameEvent('audio:settings');
  const coop = useGameEvent('coop:info');
  const [confirmNew, setConfirmNew] = useState(false);
  const savedAt = save?.savedAt ? new Date(save.savedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : null;

  return (
    <Panel
      title="Paused"
      footer={
        <span className="hud-muted">
          {save?.storage}. {savedAt ? `Last saved at ${savedAt}. ` : ''}The game also saves every morning.
        </span>
      }
    >
      <div className="menu">
        <button type="button" className="btn" onClick={() => gameCommands.emit('ui:close', {})}>
          Resume
        </button>
        <button type="button" className="btn" onClick={() => gameCommands.emit('game:save', {})}>
          Save now
        </button>
        <button type="button" className="btn" onClick={() => gameCommands.emit('ui:open', { panel: 'character' })}>
          Customise character
        </button>
        <Link className="btn" href="/">
          {coop ? 'Leave & quit to title' : 'Save & quit to title'}
        </Link>
        {coop ? (
          <div className="menu-coop">
            Friends join with code <strong>{coop.code}</strong> (Title screen → Join a friend).
          </div>
        ) : (
          <button type="button" className="btn btn-primary" onClick={() => gameCommands.emit('coop:host', {})}>
            Invite friends (co-op)
          </button>
        )}
        {coop ? null : confirmNew ? (
          <div className="menu-confirm">
            <span>Start over? This deletes your save for this world.</span>
            <button type="button" className="btn btn-danger" onClick={() => gameCommands.emit('game:new', {})}>
              Yes, new game
            </button>
            <button type="button" className="btn" onClick={() => setConfirmNew(false)}>
              Cancel
            </button>
          </div>
        ) : (
          <button type="button" className="btn" onClick={() => setConfirmNew(true)}>
            New game…
          </button>
        )}
      </div>
      {audio && (
        <>
          <h3 className="panel-subtitle">Sound</h3>
          <div className="sound-settings">
            {(
              [
                ['master', 'Master'],
                ['music', 'Music'],
                ['sfx', 'Effects'],
                ['ambience', 'Ambience'],
              ] as const
            ).map(([channel, label]) => (
              <label key={channel} className="sound-row">
                <span>{label}</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(audio[channel] * 100)}
                  disabled={audio.muted}
                  onChange={(e) => gameCommands.emit('audio:set', { channel, value: Number(e.target.value) / 100 })}
                />
                <span className="hud-muted">{Math.round(audio[channel] * 100)}%</span>
              </label>
            ))}
            <label className="sound-row">
              <span>Mute</span>
              <input type="checkbox" checked={audio.muted} onChange={() => gameCommands.emit('audio:mute', {})} />
              <span className="hud-muted">
                or <kbd>Shift</kbd>+<kbd>M</kbd>
              </span>
            </label>
          </div>
        </>
      )}
      <h3 className="panel-subtitle">Controls</h3>
      <ul className="controls-list">
        <li><kbd>WASD</kbd>/<kbd>Arrows</kbd> move, <kbd>Shift</kbd> run</li>
        <li><kbd>Space</kbd>/click use the selected item on the tile you face</li>
        <li><kbd>E</kbd> interact: talk, shop, harvest, open chests, sleep</li>
        <li><kbd>1–0</kbd>/mouse wheel select hotbar slot</li>
        <li><kbd>I</kbd> inventory · <kbd>C</kbd> crafting · <kbd>Esc</kbd> this menu</li>
        <li>Eat: select food and press <kbd>F</kbd> (or right-click it in the hotbar)</li>
        <li>Seeds can go straight onto grass: the soil is tilled for you</li>
        <li><kbd>M</kbd> world map</li>
        <li>Pick up placed items with the pickaxe</li>
        <li>Click the button above what you're facing to do its action · <kbd>Shift</kbd>+<kbd>M</kbd> mute</li>
      </ul>
    </Panel>
  );
}
