'use client';

import { useState } from 'react';
import { ITEMS, RECIPE_CATEGORIES, RECIPES, type ItemId, type RecipeCategory } from '@farming/shared';
import { gameCommands, type GameEventMap } from '@/game-engine/events/GameEventBus';
import { ItemIcon } from '../ItemIcon';
import { Panel } from './Panel';

type InventoryView = GameEventMap['inventory:changed'];

function countOf(inventory: InventoryView, itemId: ItemId): number {
  return inventory.slots.reduce((sum, s) => (s?.itemId === itemId ? sum + s.quantity : sum), 0);
}

/** Recipe list. Availability is shown here; the game re-validates on craft. */
export function CraftingPanel({ inventory }: { inventory: InventoryView }) {
  const [category, setCategory] = useState<RecipeCategory>('tools');
  return (
    <Panel title="Crafting">
      <nav className="tabs" role="tablist">
        {RECIPE_CATEGORIES.map((c) => (
          <button key={c.id} type="button" role="tab" aria-selected={category === c.id} className={`tab${category === c.id ? ' active' : ''}`} onClick={() => setCategory(c.id)}>
            {c.label}
          </button>
        ))}
      </nav>
      <ul className="recipe-list">
        {RECIPES.filter((r) => r.category === category).map((recipe) => {
          const out = ITEMS[recipe.output.itemId];
          const craftable = recipe.inputs.every((input) => countOf(inventory, input.itemId) >= input.quantity);
          return (
            <li key={recipe.id} className="recipe">
              <ItemIcon id={recipe.output.itemId} />
              <div className="recipe-info">
                <div>
                  <strong>{out.name}</strong>
                  {recipe.output.quantity > 1 && <span className="hud-muted"> ×{recipe.output.quantity}</span>}
                  {out.energy !== undefined && <span className="hud-muted"> · +{out.energy} energy</span>}
                </div>
                <div className="recipe-inputs">
                  {recipe.inputs.map((input) => {
                    const have = countOf(inventory, input.itemId);
                    return (
                      <span key={input.itemId} className={have >= input.quantity ? 'have' : 'lack'} title={ITEMS[input.itemId].name}>
                        <ItemIcon id={input.itemId} size={16} /> {have}/{input.quantity}
                      </span>
                    );
                  })}
                </div>
              </div>
              <button
                type="button"
                className="btn"
                disabled={!craftable}
                onClick={() => gameCommands.emit('craft', { recipeId: recipe.id })}
              >
                Craft
              </button>
            </li>
          );
        })}
      </ul>
    </Panel>
  );
}
