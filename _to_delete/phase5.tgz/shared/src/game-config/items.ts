import type { CropId } from './crops';
import type { PlaceableKind } from './placeables';

export const ITEM_IDS = [
  'axe',
  'pickaxe',
  'hoe',
  'watering_can',
  'copper_axe',
  'copper_pickaxe',
  'wood',
  'stone',
  'copper_ore',
  'fiber',
  'berries',
  'turnip_seeds',
  'carrot_seeds',
  'pumpkin_seeds',
  'turnip',
  'carrot',
  'pumpkin',
  'fertilizer',
  'egg',
  'fence',
  'wood_path',
  'stone_path',
  'lamp_post',
  'chest',
  'chicken',
  'fishing_rod',
  'sunfish',
  'trout',
  'catfish',
  'golden_carp',
  'bread',
  'veggie_soup',
  'berry_jam',
  'grilled_fish',
  'omelette',
  'pumpkin_pie',
  'sprinkler',
  'bench',
  'flower_pot',
  'scarecrow',
] as const;

export type ItemId = (typeof ITEM_IDS)[number];

export type ToolKind = 'axe' | 'pickaxe' | 'hoe' | 'watering_can' | 'fishing_rod';
export type ItemCategory = 'tool' | 'resource' | 'seed' | 'crop' | 'consumable' | 'placeable' | 'animal' | 'fish' | 'food';

export interface ItemDef {
  id: ItemId;
  name: string;
  description: string;
  category: ItemCategory;
  maxStack: number;
  /** Price the merchant pays. Undefined = cannot be sold. */
  sellPrice?: number;
  /** Price at the merchant. Undefined = not sold in the shop. */
  buyPrice?: number;
  tool?: { kind: ToolKind; power: number };
  /** Seeds: the crop they grow. */
  plants?: CropId;
  /** Food: energy restored when eaten. */
  energy?: number;
  /** Buildables: what gets placed in the world. */
  places?: PlaceableKind;
  /** Animals: released onto the farm. */
  releases?: 'chicken';
  /** Shop items that only appear once the player has earned this much in total. */
  unlockAtEarnings?: number;
}

export const ITEMS: Record<ItemId, ItemDef> = {
  axe: {
    id: 'axe',
    name: 'Axe',
    description: 'Chops trees, stumps and bushes.',
    category: 'tool',
    maxStack: 1,
    tool: { kind: 'axe', power: 1 },
  },
  pickaxe: {
    id: 'pickaxe',
    name: 'Pickaxe',
    description: 'Breaks rocks and ore. Also clears empty tilled soil.',
    category: 'tool',
    maxStack: 1,
    tool: { kind: 'pickaxe', power: 1 },
  },
  hoe: {
    id: 'hoe',
    name: 'Hoe',
    description: 'Tills grass into soil you can plant in.',
    category: 'tool',
    maxStack: 1,
    tool: { kind: 'hoe', power: 1 },
  },
  watering_can: {
    id: 'watering_can',
    name: 'Watering Can',
    description: 'Waters soil. Refill it at any pond or river.',
    category: 'tool',
    maxStack: 1,
    tool: { kind: 'watering_can', power: 1 },
  },
  copper_axe: {
    id: 'copper_axe',
    name: 'Copper Axe',
    description: 'Chops twice as hard as a plain axe.',
    category: 'tool',
    maxStack: 1,
    tool: { kind: 'axe', power: 2 },
  },
  copper_pickaxe: {
    id: 'copper_pickaxe',
    name: 'Copper Pickaxe',
    description: 'Breaks stone twice as fast as a plain pickaxe.',
    category: 'tool',
    maxStack: 1,
    tool: { kind: 'pickaxe', power: 2 },
  },
  wood: { id: 'wood', name: 'Wood', description: 'Sturdy timber.', category: 'resource', maxStack: 99, sellPrice: 2 },
  stone: { id: 'stone', name: 'Stone', description: 'A common building stone.', category: 'resource', maxStack: 99, sellPrice: 2 },
  copper_ore: {
    id: 'copper_ore',
    name: 'Copper Ore',
    description: 'Found in copper-veined rocks.',
    category: 'resource',
    maxStack: 99,
    sellPrice: 6,
  },
  fiber: { id: 'fiber', name: 'Fiber', description: 'Plant fibre cut from tall grass.', category: 'resource', maxStack: 99, sellPrice: 1 },
  berries: {
    id: 'berries',
    name: 'Wild Berries',
    description: 'Picked from berry bushes. Edible.',
    category: 'resource',
    maxStack: 99,
    sellPrice: 8,
    energy: 8,
  },
  turnip_seeds: {
    id: 'turnip_seeds',
    name: 'Turnip Seeds',
    description: 'Quick to grow. Plant in tilled soil and keep it watered.',
    category: 'seed',
    maxStack: 99,
    buyPrice: 10,
    sellPrice: 5,
    plants: 'turnip',
  },
  carrot_seeds: {
    id: 'carrot_seeds',
    name: 'Carrot Seeds',
    description: 'Plant in tilled soil and keep it watered.',
    category: 'seed',
    maxStack: 99,
    buyPrice: 20,
    sellPrice: 10,
    plants: 'carrot',
  },
  pumpkin_seeds: {
    id: 'pumpkin_seeds',
    name: 'Pumpkin Seeds',
    description: 'Slow to grow, but pumpkins sell for a lot.',
    category: 'seed',
    maxStack: 99,
    buyPrice: 45,
    sellPrice: 20,
    plants: 'pumpkin',
    unlockAtEarnings: 150,
  },
  turnip: { id: 'turnip', name: 'Turnip', description: 'A crisp, earthy root. Edible.', category: 'crop', maxStack: 99, sellPrice: 25, energy: 20 },
  carrot: { id: 'carrot', name: 'Carrot', description: 'Sweet and crunchy. Edible.', category: 'crop', maxStack: 99, sellPrice: 45, energy: 30 },
  pumpkin: { id: 'pumpkin', name: 'Pumpkin', description: 'A prize-worthy squash. Edible.', category: 'crop', maxStack: 99, sellPrice: 150, energy: 60 },
  fertilizer: {
    id: 'fertilizer',
    name: 'Fertilizer',
    description: 'Use on a growing crop to advance it one stage.',
    category: 'consumable',
    maxStack: 99,
    sellPrice: 3,
  },
  egg: { id: 'egg', name: 'Egg', description: 'Laid by your chickens each morning. Edible.', category: 'resource', maxStack: 99, sellPrice: 30, energy: 20 },
  fence: { id: 'fence', name: 'Fence', description: 'Place to build fences. Posts connect automatically.', category: 'placeable', maxStack: 99, places: 'fence' },
  wood_path: { id: 'wood_path', name: 'Wood Path', description: 'A walkable plank floor tile.', category: 'placeable', maxStack: 99, places: 'wood_path' },
  stone_path: { id: 'stone_path', name: 'Stone Path', description: 'A walkable cobblestone floor tile.', category: 'placeable', maxStack: 99, places: 'stone_path' },
  lamp_post: { id: 'lamp_post', name: 'Lamp Post', description: 'Lights up the night.', category: 'placeable', maxStack: 99, places: 'lamp_post' },
  chest: { id: 'chest', name: 'Chest', description: 'Stores 20 stacks of items.', category: 'placeable', maxStack: 99, places: 'chest' },
  chicken: {
    id: 'chicken',
    name: 'Chicken',
    description: 'Release on your farm. Lays an egg every morning.',
    category: 'animal',
    maxStack: 9,
    buyPrice: 120,
    releases: 'chicken',
    unlockAtEarnings: 300,
  },
  fishing_rod: {
    id: 'fishing_rod',
    name: 'Fishing Rod',
    description: 'Cast into a pond or river, wait for a bite, then reel in (Space) when you see "!".',
    category: 'tool',
    maxStack: 1,
    tool: { kind: 'fishing_rod', power: 1 },
  },
  sunfish: { id: 'sunfish', name: 'Sunfish', description: 'A common, bright little fish. Edible.', category: 'fish', maxStack: 99, sellPrice: 20, energy: 12 },
  trout: { id: 'trout', name: 'Trout', description: 'Likes cool water in spring and fall. Edible.', category: 'fish', maxStack: 99, sellPrice: 45, energy: 18 },
  catfish: { id: 'catfish', name: 'Catfish', description: 'Bites at night and in the rain. Edible.', category: 'fish', maxStack: 99, sellPrice: 70, energy: 22 },
  golden_carp: { id: 'golden_carp', name: 'Golden Carp', description: 'A rare, shimmering fish. Finn would love it.', category: 'fish', maxStack: 99, sellPrice: 300 },
  bread: { id: 'bread', name: 'Bread', description: "Fresh from Rosa's oven.", category: 'food', maxStack: 99, sellPrice: 15, energy: 35 },
  veggie_soup: { id: 'veggie_soup', name: 'Veggie Soup', description: 'Turnip and carrot, simmered.', category: 'food', maxStack: 99, sellPrice: 110, energy: 60 },
  berry_jam: { id: 'berry_jam', name: 'Berry Jam', description: 'Sweet and sticky.', category: 'food', maxStack: 99, sellPrice: 55, energy: 30 },
  grilled_fish: { id: 'grilled_fish', name: 'Grilled Fish', description: 'Simple and filling.', category: 'food', maxStack: 99, sellPrice: 50, energy: 45 },
  omelette: { id: 'omelette', name: 'Omelette', description: 'Two eggs, well cooked.', category: 'food', maxStack: 99, sellPrice: 80, energy: 50 },
  pumpkin_pie: { id: 'pumpkin_pie', name: 'Pumpkin Pie', description: 'The pride of any harvest festival.', category: 'food', maxStack: 99, sellPrice: 260, energy: 90 },
  sprinkler: {
    id: 'sprinkler',
    name: 'Sprinkler',
    description: 'Waters the 4 tiles around it every morning.',
    category: 'placeable',
    maxStack: 99,
    places: 'sprinkler',
  },
  bench: { id: 'bench', name: 'Bench', description: 'A spot to rest. Decoration.', category: 'placeable', maxStack: 99, places: 'bench' },
  flower_pot: { id: 'flower_pot', name: 'Flower Pot', description: 'Brightens up the farm. Decoration.', category: 'placeable', maxStack: 99, places: 'flower_pot' },
  scarecrow: { id: 'scarecrow', name: 'Scarecrow', description: 'Keeps watch over your crops. Decoration.', category: 'placeable', maxStack: 99, places: 'scarecrow' },
};

export function isItemId(value: unknown): value is ItemId {
  return typeof value === 'string' && (ITEM_IDS as readonly string[]).includes(value);
}
