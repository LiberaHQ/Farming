import type { ItemId } from './items';

export interface ItemAmount {
  itemId: ItemId;
  quantity: number;
}

export type RecipeCategory = 'tools' | 'farm' | 'building' | 'cooking';

export interface RecipeDef {
  id: string;
  category: RecipeCategory;
  output: ItemAmount;
  inputs: readonly ItemAmount[];
}

export const RECIPES: readonly RecipeDef[] = [
  {
    id: 'copper_axe',
    category: 'tools',
    output: { itemId: 'copper_axe', quantity: 1 },
    inputs: [
      { itemId: 'wood', quantity: 10 },
      { itemId: 'copper_ore', quantity: 5 },
    ],
  },
  {
    id: 'copper_pickaxe',
    category: 'tools',
    output: { itemId: 'copper_pickaxe', quantity: 1 },
    inputs: [
      { itemId: 'wood', quantity: 6 },
      { itemId: 'copper_ore', quantity: 8 },
    ],
  },
  {
    id: 'fertilizer',
    category: 'farm',
    output: { itemId: 'fertilizer', quantity: 2 },
    inputs: [
      { itemId: 'fiber', quantity: 5 },
      { itemId: 'stone', quantity: 1 },
    ],
  },
  {
    id: 'carrot_seeds',
    category: 'farm',
    output: { itemId: 'carrot_seeds', quantity: 3 },
    inputs: [
      { itemId: 'turnip', quantity: 1 },
      { itemId: 'fiber', quantity: 2 },
    ],
  },
  {
    id: 'pumpkin_seeds',
    category: 'farm',
    output: { itemId: 'pumpkin_seeds', quantity: 2 },
    inputs: [
      { itemId: 'carrot', quantity: 2 },
      { itemId: 'fiber', quantity: 4 },
    ],
  },
  { id: 'fence', category: 'building', output: { itemId: 'fence', quantity: 4 }, inputs: [{ itemId: 'wood', quantity: 2 }] },
  { id: 'wood_path', category: 'building', output: { itemId: 'wood_path', quantity: 5 }, inputs: [{ itemId: 'wood', quantity: 1 }] },
  { id: 'stone_path', category: 'building', output: { itemId: 'stone_path', quantity: 5 }, inputs: [{ itemId: 'stone', quantity: 1 }] },
  {
    id: 'lamp_post',
    category: 'building',
    output: { itemId: 'lamp_post', quantity: 1 },
    inputs: [
      { itemId: 'wood', quantity: 4 },
      { itemId: 'copper_ore', quantity: 2 },
    ],
  },
  {
    id: 'chest',
    category: 'building',
    output: { itemId: 'chest', quantity: 1 },
    inputs: [
      { itemId: 'wood', quantity: 12 },
      { itemId: 'stone', quantity: 2 },
    ],
  },
  {
    id: 'sprinkler',
    category: 'farm',
    output: { itemId: 'sprinkler', quantity: 1 },
    inputs: [
      { itemId: 'copper_ore', quantity: 4 },
      { itemId: 'stone', quantity: 5 },
    ],
  },
  { id: 'veggie_soup', category: 'cooking', output: { itemId: 'veggie_soup', quantity: 1 }, inputs: [{ itemId: 'turnip', quantity: 1 }, { itemId: 'carrot', quantity: 1 }] },
  { id: 'berry_jam', category: 'cooking', output: { itemId: 'berry_jam', quantity: 1 }, inputs: [{ itemId: 'berries', quantity: 4 }] },
  { id: 'grilled_fish', category: 'cooking', output: { itemId: 'grilled_fish', quantity: 1 }, inputs: [{ itemId: 'sunfish', quantity: 1 }, { itemId: 'wood', quantity: 1 }] },
  { id: 'omelette', category: 'cooking', output: { itemId: 'omelette', quantity: 1 }, inputs: [{ itemId: 'egg', quantity: 2 }] },
  {
    id: 'pumpkin_pie',
    category: 'cooking',
    output: { itemId: 'pumpkin_pie', quantity: 1 },
    inputs: [
      { itemId: 'pumpkin', quantity: 1 },
      { itemId: 'egg', quantity: 1 },
      { itemId: 'bread', quantity: 1 },
    ],
  },
];

export const RECIPE_CATEGORIES: Array<{ id: RecipeCategory; label: string }> = [
  { id: 'tools', label: 'Tools' },
  { id: 'farm', label: 'Farming' },
  { id: 'building', label: 'Building' },
  { id: 'cooking', label: 'Cooking' },
];

export function findRecipe(id: string): RecipeDef | undefined {
  return RECIPES.find((r) => r.id === id);
}
