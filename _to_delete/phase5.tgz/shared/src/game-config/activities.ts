import type { ItemId } from './items';
import type { NpcId } from './npcs';
import type { Season, WeatherKind } from './time';

/** Fish you can catch, and when. Weights are relative chances among the fish that are biting. */
export interface FishDef {
  itemId: ItemId;
  weight: number;
  seasons?: Season[];
  /** Only between these minutes of day (wraps past midnight if from > to). */
  hours?: { from: number; to: number };
  weather?: WeatherKind[];
}

export const FISH: FishDef[] = [
  { itemId: 'sunfish', weight: 60 },
  { itemId: 'trout', weight: 30, seasons: ['spring', 'fall'] },
  { itemId: 'catfish', weight: 25, hours: { from: 19 * 60, to: 26 * 60 } },
  { itemId: 'catfish', weight: 25, weather: ['rain'] },
  { itemId: 'golden_carp', weight: 3 },
];

export const FISHING = {
  energyCost: 3,
  /** Wait for a bite, in real milliseconds. */
  biteDelay: [1400, 5200] as const,
  /** How long the "!" lasts — press Use within this window. */
  reactionWindow: 900,
} as const;

/** Daily requests on the village notice board. */
export interface RequestDef {
  npc: NpcId;
  itemId: ItemId;
  quantity: number;
  reward: number;
  seasons?: Season[];
  text: string;
}

export const REQUESTS: RequestDef[] = [
  { npc: 'rosa', itemId: 'egg', quantity: 3, reward: 150, text: 'I need eggs for a big batch of cakes!' },
  { npc: 'rosa', itemId: 'berries', quantity: 8, reward: 110, text: 'Berries for jam, please!' },
  { npc: 'rosa', itemId: 'pumpkin', quantity: 1, reward: 260, seasons: ['summer', 'fall'], text: 'One perfect pumpkin for a pie contest.' },
  { npc: 'bram', itemId: 'copper_ore', quantity: 5, reward: 110, text: 'Running low on copper. Bring ore!' },
  { npc: 'bram', itemId: 'stone', quantity: 15, reward: 80, text: 'Need stone to rebuild the forge wall.' },
  { npc: 'finn', itemId: 'sunfish', quantity: 3, reward: 110, text: 'Caught nothing all week. Spare a few sunfish?' },
  { npc: 'finn', itemId: 'trout', quantity: 1, reward: 120, seasons: ['spring', 'fall'], text: 'Looking for a nice trout for supper.' },
  { npc: 'willa', itemId: 'wood', quantity: 20, reward: 120, text: 'Big order of furniture — I need timber!' },
  { npc: 'willa', itemId: 'fiber', quantity: 10, reward: 70, text: 'Fiber for rope, please.' },
  { npc: 'mira', itemId: 'turnip', quantity: 4, reward: 160, seasons: ['spring', 'fall'], text: 'Customers keep asking for turnips!' },
  { npc: 'mira', itemId: 'carrot', quantity: 3, reward: 200, seasons: ['spring', 'summer', 'fall'], text: 'Carrots, carrots, carrots!' },
  { npc: 'tobin', itemId: 'veggie_soup', quantity: 1, reward: 180, text: 'A bowl of veggie soup would warm these old bones.' },
  { npc: 'tobin', itemId: 'bread', quantity: 2, reward: 90, text: "My oven's broken. Could you bring me bread?" },
];

/** Requests posted per day. */
export const REQUESTS_PER_DAY = 2;
/** Friendship gained with the requester when a request is completed. */
export const REQUEST_FRIENDSHIP = 40;
