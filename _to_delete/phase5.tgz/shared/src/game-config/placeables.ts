import type { ItemId } from './items';

export type PlaceableKind =
  | 'fence'
  | 'wood_path'
  | 'stone_path'
  | 'lamp_post'
  | 'chest'
  | 'cottage'
  | 'sprinkler'
  | 'bench'
  | 'flower_pot'
  | 'scarecrow';

export interface PlaceableDef {
  kind: PlaceableKind;
  /** Item returned when picked up (null = permanent, e.g. the cottage). */
  item: ItemId | null;
  /** Footprint in tiles. */
  width: number;
  /** Floors are drawn on the ground and are walkable. */
  floor: boolean;
  /** Radius (px) of light cast at night. */
  light?: number;
}

export const PLACEABLES: Record<PlaceableKind, PlaceableDef> = {
  fence: { kind: 'fence', item: 'fence', width: 1, floor: false },
  wood_path: { kind: 'wood_path', item: 'wood_path', width: 1, floor: true },
  stone_path: { kind: 'stone_path', item: 'stone_path', width: 1, floor: true },
  lamp_post: { kind: 'lamp_post', item: 'lamp_post', width: 1, floor: false, light: 64 },
  chest: { kind: 'chest', item: 'chest', width: 1, floor: false },
  cottage: { kind: 'cottage', item: null, width: 3, floor: false, light: 40 },
  sprinkler: { kind: 'sprinkler', item: 'sprinkler', width: 1, floor: false },
  bench: { kind: 'bench', item: 'bench', width: 1, floor: false },
  flower_pot: { kind: 'flower_pot', item: 'flower_pot', width: 1, floor: false },
  scarecrow: { kind: 'scarecrow', item: 'scarecrow', width: 1, floor: false },
};

export const CHEST_SIZE = 20;
