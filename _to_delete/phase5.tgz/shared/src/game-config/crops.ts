import type { ItemId } from './items';
import type { Season } from './time';

export type CropId = 'turnip' | 'carrot' | 'pumpkin';

export interface CropDef {
  id: CropId;
  name: string;
  seedItem: ItemId;
  harvestItem: ItemId;
  /** Stage 0 is freshly planted; the crop is harvestable at this stage. */
  matureStage: number;
  /** Inclusive range of items harvested. */
  yield: readonly [min: number, max: number];
  /** Seasons the crop grows in. Out of season it can't be planted, and withers when the season changes. */
  seasons: readonly Season[];
}

export const CROPS: Record<CropId, CropDef> = {
  turnip: { id: 'turnip', name: 'Turnip', seedItem: 'turnip_seeds', harvestItem: 'turnip', matureStage: 3, yield: [1, 2], seasons: ['spring', 'fall'] },
  carrot: { id: 'carrot', name: 'Carrot', seedItem: 'carrot_seeds', harvestItem: 'carrot', matureStage: 4, yield: [1, 2], seasons: ['spring', 'summer', 'fall'] },
  pumpkin: { id: 'pumpkin', name: 'Pumpkin', seedItem: 'pumpkin_seeds', harvestItem: 'pumpkin', matureStage: 5, yield: [1, 1], seasons: ['summer', 'fall'] },
};

export const CROP_IDS = Object.keys(CROPS) as CropId[];
