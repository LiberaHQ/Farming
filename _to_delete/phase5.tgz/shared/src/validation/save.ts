import { CHEST_SIZE, PLACEABLES, type PlaceableKind } from '../game-config/placeables';
import { CROPS, type CropId } from '../game-config/crops';
import { GAME_CONFIG } from '../game-config';
import { ITEMS, isItemId } from '../game-config/items';
import { TIME_CONFIG, type WeatherKind } from '../game-config/time';
import { WORLD_HEIGHT_TILES, WORLD_WIDTH_TILES } from '../constants/world';
import { NPC_IDS } from '../game-config/npcs';
import { SAVE_VERSION, type QuestSave, type SaveData, type SlotData, type SocialSave } from '../types/save';
import type { WorldObjectKind, WorldObjectSpec } from '../types/world';

/**
 * Server-side sanity check for a save uploaded by a client. It is not
 * anti-cheat for a single-player game; it guarantees the stored data is
 * well-formed, within the game's rules and limits, and safe to load.
 */
export type SaveValidation = { ok: true; data: SaveData } | { ok: false; error: string };

const OBJECT_KINDS: WorldObjectKind[] = ['oak', 'pine', 'rock', 'copperRock', 'bush', 'stump', 'tallGrass', 'stall', 'board'];
const WEATHER: WeatherKind[] = ['sunny', 'cloudy', 'rain', 'snow'];
const DIRECTIONS = ['down', 'left', 'right', 'up'] as const;
const MAX_GOLD = 1_000_000_000;
const MAX_NODES = 6_000;

class Invalid extends Error {}

const fail = (msg: string): never => {
  throw new Invalid(msg);
};
const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);
const int = (v: unknown, min: number, max: number, field: string): number =>
  typeof v === 'number' && Number.isInteger(v) && v >= min && v <= max ? v : fail(`${field} must be an integer in [${min}, ${max}]`);
const num = (v: unknown, min: number, max: number, field: string): number =>
  typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max ? v : fail(`${field} must be a number in [${min}, ${max}]`);
const arr = (v: unknown, max: number, field: string): unknown[] =>
  Array.isArray(v) && v.length <= max ? v : fail(`${field} must be an array of at most ${max} entries`);
const tileX = (v: unknown, field: string) => int(v, 0, WORLD_WIDTH_TILES - 1, field);
const tileY = (v: unknown, field: string) => int(v, 0, WORLD_HEIGHT_TILES - 1, field);

function slot(v: unknown, field: string): SlotData {
  if (v === null || v === undefined) return null;
  if (!isObj(v) || !isItemId(v.itemId)) return fail(`${field}: unknown item`);
  return { itemId: v.itemId, quantity: int(v.quantity, 1, ITEMS[v.itemId].maxStack, `${field}.quantity`) };
}

function spec(v: unknown, field: string): WorldObjectSpec {
  if (!isObj(v) || !OBJECT_KINDS.includes(v.kind as WorldObjectKind)) return fail(`${field}: unknown object kind`);
  return { kind: v.kind as WorldObjectKind, tx: tileX(v.tx, `${field}.tx`), ty: tileY(v.ty, `${field}.ty`), variant: int(v.variant, 0, 7, `${field}.variant`) };
}

function npcNumbers(v: unknown, min: number, max: number, field: string): Record<string, number> {
  const out: Record<string, number> = {};
  if (v === undefined || v === null) return out;
  if (!isObj(v)) return fail(`${field} must be an object`);
  for (const [k, n] of Object.entries(v)) {
    if (!(NPC_IDS as string[]).includes(k)) continue; // ignore unknown villagers
    out[k] = int(n, min, max, `${field}.${k}`);
  }
  return out;
}

function social(v: unknown): SocialSave | undefined {
  if (v === undefined || v === null) return undefined;
  if (!isObj(v)) return fail('social must be an object');
  return {
    points: npcNumbers(v.points, 0, 10_000, 'social.points'),
    talkedDay: npcNumbers(v.talkedDay, 0, 200_000, 'social.talkedDay'),
    giftedDay: npcNumbers(v.giftedDay, 0, 200_000, 'social.giftedDay'),
  };
}

function quests(v: unknown): QuestSave | undefined {
  if (v === undefined || v === null) return undefined;
  if (!isObj(v)) return fail('quests must be an object');
  return { day: int(v.day, 0, 200_000, 'quests.day'), done: arr(v.done, 10, 'quests.done').map((d) => int(d, 0, 9, 'quests.done[]')) };
}

export function validateSave(input: unknown, expectedSeed?: string): SaveValidation {
  try {
    if (!isObj(input)) fail('Save must be an object');
    const s = input as Record<string, unknown>;
    if (s.version !== SAVE_VERSION) fail(`Unsupported save version (expected ${SAVE_VERSION})`);
    if (typeof s.seed !== 'string' || s.seed.length < 1 || s.seed.length > 64) fail('seed must be 1–64 characters');
    if (expectedSeed !== undefined && s.seed !== expectedSeed) fail('seed does not match the world');

    const time = isObj(s.time) ? s.time : fail('time missing');
    const p = isObj(s.player) ? s.player : fail('player missing');
    const inv = isObj(p.inventory) ? p.inventory : fail('player.inventory missing');
    const appearance = isObj(p.appearance) ? p.appearance : fail('player.appearance missing');
    const res = isObj(s.resources) ? s.resources : fail('resources missing');

    const data: SaveData = {
      version: SAVE_VERSION,
      seed: s.seed as string,
      savedAt: int(s.savedAt, 0, Number.MAX_SAFE_INTEGER, 'savedAt'),
      time: {
        day: int(time.day, 1, 100_000, 'time.day'),
        minute: int(time.minute, TIME_CONFIG.dayStartMinute, TIME_CONFIG.dayEndMinute, 'time.minute'),
      },
      weather: WEATHER.includes(s.weather as WeatherKind) ? (s.weather as WeatherKind) : fail('unknown weather'),
      player: {
        x: num(p.x, 0, WORLD_WIDTH_TILES * GAME_CONFIG.tileSize, 'player.x'),
        y: num(p.y, 0, WORLD_HEIGHT_TILES * GAME_CONFIG.tileSize, 'player.y'),
        facing: DIRECTIONS.includes(p.facing as (typeof DIRECTIONS)[number]) ? (p.facing as (typeof DIRECTIONS)[number]) : 'down',
        gold: int(p.gold, 0, MAX_GOLD, 'player.gold'),
        lifetimeEarnings: int(p.lifetimeEarnings, 0, MAX_GOLD, 'player.lifetimeEarnings'),
        energy: num(p.energy, 0, GAME_CONFIG.energy.max, 'player.energy'),
        water: int(p.water, 0, GAME_CONFIG.farming.wateringCanCapacity, 'player.water'),
        appearance: {
          skin: int(appearance.skin, 0, 20, 'appearance.skin'),
          hair: int(appearance.hair, 0, 20, 'appearance.hair'),
          shirt: int(appearance.shirt, 0, 20, 'appearance.shirt'),
          pants: int(appearance.pants, 0, 20, 'appearance.pants'),
        },
        inventory: {
          slots: arr(inv.slots, GAME_CONFIG.inventory.size, 'inventory.slots').map((v, i) => slot(v, `inventory[${i}]`)),
          selected: int(inv.selected, 0, GAME_CONFIG.inventory.hotbarSize - 1, 'inventory.selected'),
        },
      },
      resources: {
        nodes: arr(res.nodes, MAX_NODES, 'resources.nodes').map((v, i) => {
          const n = isObj(v) ? v : fail(`resources.nodes[${i}]`);
          return {
            spec: spec(n.spec, `nodes[${i}].spec`),
            hasBerries: n.hasBerries === true,
            berryDueDay: n.berryDueDay === null || n.berryDueDay === undefined ? null : int(n.berryDueDay, 0, 200_000, 'berryDueDay'),
            regrowsInto: n.regrowsInto ? spec(n.regrowsInto, `nodes[${i}].regrowsInto`) : null,
          };
        }),
        pending: arr(res.pending, MAX_NODES, 'resources.pending').map((v, i) => {
          const r = isObj(v) ? v : fail(`resources.pending[${i}]`);
          return { spec: spec(r.spec, `pending[${i}].spec`), dueDay: int(r.dueDay, 0, 200_000, 'dueDay') };
        }),
      },
      farm: arr(s.farm, WORLD_WIDTH_TILES * WORLD_HEIGHT_TILES, 'farm').map((v, i) => {
        const f = isObj(v) ? v : fail(`farm[${i}]`);
        const crop = f.crop === null || f.crop === undefined ? null : isObj(f.crop) ? f.crop : fail(`farm[${i}].crop`);
        return {
          tx: tileX(f.tx, `farm[${i}].tx`),
          ty: tileY(f.ty, `farm[${i}].ty`),
          watered: f.watered === true,
          crop: crop
            ? {
                id: (crop.id as string) in CROPS ? (crop.id as CropId) : fail(`farm[${i}]: unknown crop`),
                stage: int(crop.stage, 0, CROPS[crop.id as CropId].matureStage, `farm[${i}].stage`),
              }
            : null,
        };
      }),
      placed: arr(s.placed, 5_000, 'placed').map((v, i) => {
        const b = isObj(v) ? v : fail(`placed[${i}]`);
        const kind = (b.kind as string) in PLACEABLES ? (b.kind as PlaceableKind) : fail(`placed[${i}]: unknown kind`);
        return {
          kind,
          tx: tileX(b.tx, `placed[${i}].tx`),
          ty: tileY(b.ty, `placed[${i}].ty`),
          ...(kind === 'chest' ? { items: arr(b.items ?? [], CHEST_SIZE, `placed[${i}].items`).map((it, j) => slot(it, `chest[${i}][${j}]`)) } : {}),
        };
      }),
      chickens: arr(s.chickens, 200, 'chickens').map((v, i) => {
        const c = isObj(v) ? v : fail(`chickens[${i}]`);
        const maxX = WORLD_WIDTH_TILES * GAME_CONFIG.tileSize;
        const maxY = WORLD_HEIGHT_TILES * GAME_CONFIG.tileSize;
        return {
          x: num(c.x, 0, maxX, 'chicken.x'),
          y: num(c.y, 0, maxY, 'chicken.y'),
          homeX: num(c.homeX, 0, maxX, 'chicken.homeX'),
          homeY: num(c.homeY, 0, maxY, 'chicken.homeY'),
        };
      }),
    };
    const socialData = social(s.social);
    const questData = quests(s.quests);
    if (socialData) data.social = socialData;
    if (questData) data.quests = questData;
    return { ok: true, data };
  } catch (err) {
    if (err instanceof Invalid) return { ok: false, error: err.message };
    throw err;
  }
}
