'use client';

import { useEffect, useState } from 'react';
import { ITEMS } from '@farming/shared';
import { gameCommands } from '@/game-engine/events/GameEventBus';
import { useGameEvent } from '@/hooks/useGameEvent';
import { Hearts } from '../Hearts';
import { ItemIcon } from '../ItemIcon';
import { Panel } from './Panel';

/** The village notice board: today's delivery requests, and how well you know everyone. */
export function BoardPanel() {
  const board = useGameEvent('board:state');
  const festival = useGameEvent('festival:today');
  const inventory = useGameEvent('inventory:changed');
  const [tab, setTab] = useState<'requests' | 'villagers' | 'festival'>(festival ? 'festival' : 'requests');
  // On a festival day, open on the festival tab once its info arrives.
  const festivalId = festival?.id ?? null;
  useEffect(() => {
    if (festivalId) setTab('festival');
  }, [festivalId]);
  if (!board) return null;
  return (
    <Panel title="Village Notice Board" footer={<span className="hud-muted">New requests every morning. Talk to villagers daily and bring gifts to make friends.</span>}>
      <nav className="tabs" role="tablist">
        <button type="button" role="tab" aria-selected={tab === 'requests'} className={`tab${tab === 'requests' ? ' active' : ''}`} onClick={() => setTab('requests')}>
          Requests
        </button>
        <button type="button" role="tab" aria-selected={tab === 'villagers'} className={`tab${tab === 'villagers' ? ' active' : ''}`} onClick={() => setTab('villagers')}>
          Villagers
        </button>
        {festival && (
          <button type="button" role="tab" aria-selected={tab === 'festival'} className={`tab${tab === 'festival' ? ' active' : ''}`} onClick={() => setTab('festival')}>
            🎉 {festival.name}
          </button>
        )}
      </nav>

      {tab === 'festival' && festival && (
        <div className="festival">
          <p className="festival-tagline">{festival.tagline}</p>
          <p>{festival.details}</p>
          {festival.id === 'harvest_fair' &&
            (festival.canEnterFair ? (
              <ul className="shop-list">
                {(inventory?.slots ?? [])
                  .map((s, slot) => ({ s, slot }))
                  .filter(({ s }) => s && ITEMS[s.itemId].category === 'crop')
                  .map(({ s, slot }) => (
                    <li key={slot}>
                      <ItemIcon id={s!.itemId} />
                      <span className="shop-name">
                        {ITEMS[s!.itemId].name} <span className="hud-muted">· judged at {(ITEMS[s!.itemId].sellPrice ?? 0) * 3}g</span>
                      </span>
                      <button type="button" className="btn btn-primary" onClick={() => gameCommands.emit('festival:enter', { slot })}>
                        Enter
                      </button>
                    </li>
                  ))}
              </ul>
            ) : (
              <p className="hud-muted">You've entered this year. Thanks for taking part!</p>
            ))}
        </div>
      )}

      {tab === 'requests' && (
        <ul className="board-list">
          {board.requests.length === 0 && <li className="hud-muted">No requests today.</li>}
          {board.requests.map((r) => (
            <li key={r.index} className={`board-note${r.done ? ' done' : ''}`}>
              <div className="board-note-text">
                <p>“{r.text}”</p>
                <span className="hud-muted">— {r.npcName}</span>
              </div>
              <div className="board-note-want">
                <ItemIcon id={r.itemId} />
                <span className={r.have >= r.quantity ? 'have' : 'lack'}>
                  {Math.min(r.have, r.quantity)}/{r.quantity} {r.itemName}
                </span>
                <span className="board-reward">+{r.reward}g ♥</span>
              </div>
              <button type="button" className="btn" disabled={r.done || r.have < r.quantity} onClick={() => gameCommands.emit('board:deliver', { index: r.index })}>
                {r.done ? 'Done ✓' : 'Deliver'}
              </button>
            </li>
          ))}
        </ul>
      )}

      {tab === 'villagers' && (
        <ul className="friend-list">
          {board.friends.map((f) => (
            <li key={f.id}>
              <div>
                <strong>{f.name}</strong> <span className="hud-muted">· {f.title}</span>
              </div>
              <Hearts count={f.hearts} compact />
              <span className="friend-today hud-muted">
                {f.talkedToday ? '✓ talked' : '· not talked'} {f.giftedToday ? '✓ gift' : ''}
              </span>
            </li>
          ))}
        </ul>
      )}
    </Panel>
  );
}
