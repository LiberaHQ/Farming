import type { CropId } from '../game-config/crops';
import type { ItemId } from '../game-config/items';
import type { PlaceableKind } from '../game-config/placeables';
import type { MachineState } from '../game-config/machines';
import type { LivestockSave } from '../game-config/livestock';
import type { Letter } from '../game-config/village';
import type { AppearanceChoice } from '../game-config';
import type { WeatherKind } from '../game-config/time';
import type { Direction } from './player';
import type { WorldObjectSpec } from './world';

/**
 * The complete, engine-free snapshot of one game world. Produced by the game,
 * stored in the browser and/or on the server, and validated server-side.
 */
export const SAVE_VERSION = 1;

export interface ItemStackData {
  itemId: ItemId;
  quantity: number;
}

export type SlotData = ItemStackData | null;

export interface PlayerSave {
  gold: number;
  lifetimeEarnings: number;
  energy: number;
  water: number;
  appearance: AppearanceChoice;
  inventory: { slots: SlotData[]; selected: number };
  /** Added with the mine; optional so older saves still load. */
  health?: number;
  /** Deepest mine floor reached (unlocks the elevator every 5 floors). */
  mineDepth?: number;
}

export interface NodeSave {
  spec: WorldObjectSpec;
  hasBerries: boolean;
  berryDueDay: number | null;
  regrowsInto: WorldObjectSpec | null;
}

export interface ResourceSave {
  nodes: NodeSave[];
  pending: Array<{ spec: WorldObjectSpec; dueDay: number }>;
}

export interface PlotSave {
  tx: number;
  ty: number;
  watered: boolean;
  crop: { id: CropId; stage: number } | null;
}

export interface PlacedSave {
  kind: PlaceableKind;
  tx: number;
  ty: number;
  items?: SlotData[];
  /** Kegs and jars: what's inside and when it's ready. */
  machine?: MachineState;
  /** Barns: hay in the trough. */
  hay?: number;
}

export interface ChickenSave {
  x: number;
  y: number;
  homeX: number;
  homeY: number;
}

/** Friendship with each villager (points), and when you last talked to / gifted them. */
export interface SocialSave {
  points: Record<string, number>;
  talkedDay: Record<string, number>;
  giftedDay: Record<string, number>;
  /** Heart scenes seen, per villager (heart levels). */
  events?: Record<string, number[]>;
  mail?: Letter[];
  /** Festival progress on a given day (Harvest Fair entry). */
  festival?: { day: number; entered: boolean; eggs?: boolean };
}

/** Notice-board requests completed today. */
export interface QuestSave {
  day: number;
  done: number[];
}

export interface SaveData {
  version: typeof SAVE_VERSION;
  seed: string;
  /** Client timestamp (ms). Newer saves win when the same world is saved from two places. */
  savedAt: number;
  time: { day: number; minute: number };
  weather: WeatherKind;
  player: PlayerSave & { x: number; y: number; facing: Direction };
  resources: ResourceSave;
  farm: PlotSave[];
  placed: PlacedSave[];
  chickens: ChickenSave[];
  /** Added with the village update; optional so older saves still load. */
  social?: SocialSave;
  quests?: QuestSave;
  /** Cows and sheep (added with barns). */
  livestock?: LivestockSave[];
}

/** Summary of a saved world, for menus. */
export interface WorldSummary {
  seed: string;
  day: number;
  gold: number;
  lifetimeEarnings: number;
  savedAt: number;
}
