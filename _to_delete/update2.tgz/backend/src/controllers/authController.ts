import type { RequestHandler } from 'express';
import { clearSessionCookie, setSessionCookie } from '../api/middleware';
import { findProfile } from '../models/profileModel';
import { login, logout, parseCredentials, register } from '../services/authService';

export const registerHandler: RequestHandler = async (req, res) => {
  const { user, session } = await register(parseCredentials(req.body));
  setSessionCookie(res, session.token, session.expiresAt);
  res.status(201).json({ user: { ...user, displayName: user.username } });
};

export const loginHandler: RequestHandler = async (req, res) => {
  const { user, session } = await login(parseCredentials(req.body));
  setSessionCookie(res, session.token, session.expiresAt);
  const profile = await findProfile(user.id);
  res.json({ user: { ...user, displayName: profile?.display_name ?? user.username } });
};

export const logoutHandler: RequestHandler = async (req, res) => {
  await logout(req.sessionToken);
  clearSessionCookie(res);
  res.json({ ok: true });
};

export const meHandler: RequestHandler = async (req, res) => {
  if (!req.user) {
    res.json({ user: null });
    return;
  }
  const profile = await findProfile(req.user.id);
  res.json({ user: { ...req.user, displayName: profile?.display_name ?? req.user.username } });
};
