'use client';

import { useState } from 'react';
import { ACHIEVEMENTS, ITEM_IDS, ITEMS, type ItemCategory } from '@farming/shared';
import { useGameEvent } from '@/hooks/useGameEvent';
import { ItemIcon } from '../ItemIcon';
import { Panel } from './Panel';

const GROUPS: { label: string; categories: ItemCategory[] }[] = [
  { label: 'Crops & seeds', categories: ['crop', 'seed'] },
  { label: 'Fish', categories: ['fish'] },
  { label: 'Food', categories: ['food', 'consumable'] },
  { label: 'Resources', categories: ['resource'] },
  { label: 'Tools', categories: ['tool'] },
  { label: 'Buildings & animals', categories: ['placeable', 'animal'] },
  { label: 'Furniture', categories: ['furniture'] },
];

/** Every item you've found, and achievements with their progress. */
export function CollectionPanel() {
  const data = useGameEvent('collection:state');
  const [tab, setTab] = useState<'items' | 'achievements'>('items');
  if (!data) return null;
  const found = new Set(data.found);
  const earned = data.achievements.filter((a) => a.earned).length;
  return (
    <Panel
      title="Collection"
      footer={
        <span className="hud-muted">
          {found.size}/{ITEM_IDS.length} items found · {earned}/{ACHIEVEMENTS.length} achievements
        </span>
      }
    >
      <nav className="tabs" role="tablist">
        <button type="button" role="tab" aria-selected={tab === 'items'} className={`tab${tab === 'items' ? ' active' : ''}`} onClick={() => setTab('items')}>
          Items
        </button>
        <button type="button" role="tab" aria-selected={tab === 'achievements'} className={`tab${tab === 'achievements' ? ' active' : ''}`} onClick={() => setTab('achievements')}>
          Achievements
        </button>
      </nav>

      {tab === 'items' &&
        GROUPS.map((g) => {
          const ids = ITEM_IDS.filter((id) => g.categories.includes(ITEMS[id].category));
          if (ids.length === 0) return null;
          return (
            <section key={g.label} className="collection-group">
              <h3 className="panel-subtitle">
                {g.label} <span className="hud-muted">{ids.filter((id) => found.has(id)).length}/{ids.length}</span>
              </h3>
              <ul className="collection-grid">
                {ids.map((id) => (
                  <li key={id} className={found.has(id) ? 'found' : 'missing'} title={found.has(id) ? `${ITEMS[id].name} — ${ITEMS[id].description}` : 'Not found yet'}>
                    <ItemIcon id={id} />
                  </li>
                ))}
              </ul>
            </section>
          );
        })}

      {tab === 'achievements' && (
        <ul className="achievement-list">
          {ACHIEVEMENTS.map((a) => {
            const p = data.achievements.find((x) => x.id === a.id);
            const have = Math.min(p?.have ?? 0, p?.need ?? 1);
            const need = p?.need ?? 1;
            return (
              <li key={a.id} className={p?.earned ? 'earned' : ''}>
                <span className="achievement-icon">
                  <ItemIcon id={a.icon} />
                </span>
                <div>
                  <strong>
                    {p?.earned ? '🏆 ' : ''}
                    {a.name}
                  </strong>
                  <div className="hud-muted">{a.description}</div>
                  {!p?.earned && need > 1 && (
                    <div className="community-bar" aria-label={`${have} of ${need}`}>
                      <span style={{ width: `${(have / need) * 100}%` }} />
                    </div>
                  )}
                </div>
                <span className="hud-muted">{p?.earned ? 'Done' : need > 1 ? `${have.toLocaleString()}/${need.toLocaleString()}` : ''}</span>
              </li>
            );
          })}
        </ul>
      )}
    </Panel>
  );
}
