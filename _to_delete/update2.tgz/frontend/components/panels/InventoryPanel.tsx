'use client';

import { useState } from 'react';
import { ITEMS } from '@farming/shared';
import { gameCommands, type GameEventMap } from '@/game-engine/events/GameEventBus';
import { useGameEvent } from '@/hooks/useGameEvent';
import { ItemIcon } from '../ItemIcon';
import { ItemSlot } from '../ItemSlot';
import { Panel } from './Panel';

type InventoryView = GameEventMap['inventory:changed'];

/** 30-slot grid; the top row is the hotbar. Drag a stack, or click two slots, to move it. */
export function InventoryPanel({ inventory }: { inventory: InventoryView }) {
  const [held, setHeld] = useState<number | null>(null);
  const worn = useGameEvent('player:equipment');
  const [hovered, setHovered] = useState<number | null>(null);
  const [lastFocused, setLastFocused] = useState<number | null>(null);

  const move = (from: number, to: number) => gameCommands.emit('inventory:move', { from, to });
  const onSlotClick = (index: number) => {
    if (held === null) {
      if (inventory.slots[index]) setHeld(index);
    } else {
      if (held !== index) move(held, index);
      setHeld(null);
    }
  };

  const focus = hovered ?? held ?? lastFocused;
  const focusStack = focus !== null ? inventory.slots[focus] : null;
  const def = focusStack ? ITEMS[focusStack.itemId] : null;

  return (
    <Panel
      title="Inventory"
      footer={
        def ? (
          <div>
            <strong>{def.name}</strong> <span className="hud-muted">— {def.description}</span>
            {def.sellPrice !== undefined && <span className="hud-muted"> · sells for {def.sellPrice}g</span>}
            {def.energy && focus !== null && (
              <button type="button" className="btn btn-primary eat-button" onClick={() => gameCommands.emit('item:eat', { slot: focus })}>
                Eat (+{def.energy} energy)
              </button>
            )}
            {def.equip && focus !== null && (
              <button type="button" className="btn btn-primary eat-button" onClick={() => gameCommands.emit('equip:wear', { slot: focus })}>
                Wear
              </button>
            )}
          </div>
        ) : (
          <span className="hud-muted">Drag items between slots, or click one slot and then another. The top row is your hotbar.</span>
        )
      }
    >
      <div className="equipment-row">
        {(['ring', 'armor'] as const).map((which) => {
          const id = worn?.[which];
          return (
            <div key={which} className="equipment-slot" title={id ? ITEMS[id].description : `No ${which === 'ring' ? 'ring' : 'armour'} worn`}>
              <span className="hud-muted">{which === 'ring' ? 'Ring' : 'Armour'}</span>
              {id ? <ItemIcon id={id} /> : <span className="equipment-empty" />}
              {id && (
                <button type="button" className="btn" onClick={() => gameCommands.emit('equip:remove', { which })}>
                  Take off
                </button>
              )}
            </div>
          );
        })}
      </div>
      <div className="inventory-grid" style={{ gridTemplateColumns: `repeat(${inventory.hotbarSize}, auto)` }}>
        {inventory.slots.map((stack, i) => (
          <ItemSlot
            key={i}
            stack={stack}
            selected={i === inventory.selected}
            held={i === held}
            label={i < inventory.hotbarSize ? String((i + 1) % 10) : undefined}
            onClick={() => onSlotClick(i)}
            draggableIndex={i}
            onDropIndex={(from) => {
              move(from, i);
              setHeld(null);
            }}
            onHover={(h) => {
              setHovered(h ? i : null);
              if (h && stack) setLastFocused(i);
            }}
            onSecondary={stack && ITEMS[stack.itemId].energy ? () => gameCommands.emit('item:eat', { slot: i }) : stack && ITEMS[stack.itemId].equip ? () => gameCommands.emit('equip:wear', { slot: i }) : undefined}
          />
        ))}
      </div>
    </Panel>
  );
}
