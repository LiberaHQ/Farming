import { AuthForm } from '@/components/menus/AuthForm';

export const metadata = { title: 'Create account — Farming Game' };

export default function RegisterPage() {
  return <AuthForm mode="register" />;
}
