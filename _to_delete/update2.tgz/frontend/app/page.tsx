import { TitleScreen } from '@/components/menus/TitleScreen';

export default function HomePage() {
  return <TitleScreen />;
}
