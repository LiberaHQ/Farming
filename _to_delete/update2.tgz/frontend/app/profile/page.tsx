import { ProfilePage } from '@/components/menus/ProfilePage';

export const metadata = { title: 'Profile — Farming Game' };

export default function Profile() {
  return <ProfilePage />;
}
