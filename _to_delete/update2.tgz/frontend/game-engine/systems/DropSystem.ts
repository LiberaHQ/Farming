import * as Phaser from 'phaser';
import type { ItemId } from '@farming/shared';
import { itemTextureKey } from '../assets/registerTextures';
import { DEPTH } from '../constants';
import { sfx } from '../audio/sfx';
import { gameEvents } from '../events/GameEventBus';
import type { Inventory } from '../state/Inventory';

interface Drop {
  sprite: Phaser.GameObjects.Image;
  itemId: ItemId;
  quantity: number;
  readyAt: number;
  /** Co-op: a drop in the shared world (eggs); the server decides who gets it. */
  sharedId?: number;
  claiming?: boolean;
}

/** Asks whether this player may pick up a shared drop; calls back with the items granted (or null). */
export type DropClaimer = (id: number, done: (granted: { itemId: ItemId; quantity: number } | null) => void) => void;

const MAGNET_RADIUS = 36;
const PICKUP_RADIUS = 6;
const MAX_SPRITES_PER_SPAWN = 5;

/**
 * Items lying in the world. They pop out of whatever produced them, then get
 * pulled toward the player and into the inventory (if there is room).
 */
export class DropSystem {
  private readonly drops: Drop[] = [];
  private fullWarningAt = 0;

  private claimer: DropClaimer | null = null;

  constructor(private readonly scene: Phaser.Scene) {}

  setClaimer(claimer: DropClaimer): void {
    this.claimer = claimer;
  }

  /** A drop that exists for every co-op player (eggs laid in the shared world). */
  spawnShared(id: number, itemId: ItemId, quantity: number, x: number, y: number): void {
    const sprite = this.scene.add.image(x, y, itemTextureKey(itemId));
    this.drops.push({ sprite, itemId, quantity, readyAt: 0, sharedId: id });
  }

  /** Someone else picked up a shared drop. */
  removeShared(id: number): void {
    const i = this.drops.findIndex((d) => d.sharedId === id);
    if (i < 0) return;
    this.drops[i].sprite.destroy();
    this.drops.splice(i, 1);
  }

  spawn(itemId: ItemId, quantity: number, x: number, y: number): void {
    if (quantity <= 0) return;
    const pieces = Math.min(quantity, MAX_SPRITES_PER_SPAWN);
    for (let i = 0; i < pieces; i++) {
      const share = Math.floor(quantity / pieces) + (i < quantity % pieces ? 1 : 0);
      const sprite = this.scene.add.image(x, y, itemTextureKey(itemId));
      const tx = x + Phaser.Math.Between(-12, 12);
      const ty = y + Phaser.Math.Between(2, 12);
      const arc = Phaser.Math.Between(8, 14);
      this.scene.tweens.addCounter({
        from: 0,
        to: 1,
        duration: 360,
        ease: 'Linear',
        onUpdate: (tween) => {
          const t = tween.getValue() ?? 1;
          sprite.setPosition(x + (tx - x) * t, y + (ty - y) * t - Math.sin(Math.PI * t) * arc);
        },
      });
      this.drops.push({ sprite, itemId, quantity: share, readyAt: this.scene.time.now + 500 });
    }
  }

  private claimShared(drop: Drop, inventory: Inventory): void {
    drop.claiming = true;
    drop.sprite.setAlpha(0.4);
    this.claimer!(drop.sharedId!, (granted) => {
      const i = this.drops.indexOf(drop);
      if (i >= 0) this.drops.splice(i, 1);
      drop.sprite.destroy();
      if (!granted) return;
      const leftover = inventory.add(granted.itemId, granted.quantity);
      if (granted.quantity - leftover > 0) {
        gameEvents.emit('item:collected', { itemId: granted.itemId, quantity: granted.quantity - leftover });
        sfx('pickup', { volume: 0.7 });
      }
      if (leftover > 0) this.spawn(granted.itemId, leftover, drop.sprite.x, drop.sprite.y);
    });
  }

  update(delta: number, px: number, py: number, inventory: Inventory): void {
    const now = this.scene.time.now;
    const targetY = py - 6;
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const drop = this.drops[i];
      const s = drop.sprite;
      s.setDepth(DEPTH.ySortBase + s.y + 6);
      if (now < drop.readyAt) continue;

      const dx = px - s.x;
      const dy = targetY - s.y;
      const dist = Math.hypot(dx, dy);
      if (dist > MAGNET_RADIUS) continue;

      if (inventory.capacityFor(drop.itemId) === 0) {
        if (now > this.fullWarningAt) {
          gameEvents.emit('toast', { text: 'Inventory full' });
          this.fullWarningAt = now + 3000;
        }
        continue;
      }

      if (drop.sharedId !== undefined) {
        if (dist <= PICKUP_RADIUS * 2 && !drop.claiming && this.claimer) this.claimShared(drop, inventory);
        continue;
      }

      if (dist <= PICKUP_RADIUS) {
        const leftover = inventory.add(drop.itemId, drop.quantity);
        const collected = drop.quantity - leftover;
        if (collected > 0) {
          gameEvents.emit('item:collected', { itemId: drop.itemId, quantity: collected });
          sfx('pickup', { volume: 0.7 });
        }
        if (leftover === 0) {
          s.destroy();
          this.drops.splice(i, 1);
        } else {
          drop.quantity = leftover;
        }
        continue;
      }

      const speed = 120 + (MAGNET_RADIUS - dist) * 7;
      const step = Math.min(dist, (speed * delta) / 1000);
      s.setPosition(s.x + (dx / dist) * step, s.y + (dy / dist) * step);
    }
  }
}
