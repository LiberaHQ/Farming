import * as Phaser from 'phaser';
import { GAME_CONFIG } from '@farming/shared';
import { TEXTURES } from '../assets/registerTextures';
import { DEPTH } from '../constants';

type Kind = 'cat' | 'dog';

/**
 * Your pet: it trots after you around the farm, naps by the cottage door at
 * night (and while you're away), and can be petted once a day. Before you've
 * adopted one, two strays — a cat and a dog — wait by the door.
 */
export class PetSystem {
  private sprites: Array<{ kind: Kind; sprite: Phaser.GameObjects.Sprite; shadow: Phaser.GameObjects.Image }> = [];
  private bob = 0;

  constructor(
    private readonly scene: Phaser.Scene,
    private readonly door: () => { x: number; y: number },
  ) {}

  /** Shows the adopted pet, or both strays (pass null), or nothing (undefined). */
  show(pet: Kind | null | undefined): void {
    for (const s of this.sprites) {
      s.sprite.destroy();
      s.shadow.destroy();
    }
    this.sprites = [];
    if (pet === undefined) return;
    const d = this.door();
    const kinds: Kind[] = pet ? [pet] : ['cat', 'dog'];
    kinds.forEach((kind, i) => {
      const x = d.x + (i === 0 ? -20 : 20);
      const y = d.y + 10;
      const sprite = this.scene.add.sprite(x, y, kind === 'cat' ? TEXTURES.petCat : TEXTURES.petDog, 0).setOrigin(0.5, 1);
      const shadow = this.scene.add.image(x, y - 1, TEXTURES.shadowSmall).setDepth(DEPTH.shadow).setScale(0.8);
      this.sprites.push({ kind, sprite, shadow });
    });
  }

  /** The pet (or stray) close to a point, if any. */
  near(x: number, y: number, range = 20): Kind | null {
    for (const s of this.sprites) if (Math.hypot(s.sprite.x - x, s.sprite.y - y) < range) return s.kind;
    return null;
  }

  position(): { x: number; y: number } | null {
    const s = this.sprites[0];
    return s ? { x: s.sprite.x, y: s.sprite.y } : null;
  }

  /** Follow the player, or nap by the door. */
  update(delta: number, player: { x: number; y: number }, opts: { follow: boolean; sleep: boolean }): void {
    this.bob += delta;
    for (const s of this.sprites) {
      const spr = s.sprite;
      if (opts.sleep || !opts.follow) {
        const d = this.door();
        const home = { x: d.x + (s.kind === 'cat' ? -20 : 20), y: d.y + 10 };
        if (opts.sleep && Math.hypot(spr.x - home.x, spr.y - home.y) > 2) spr.setPosition(home.x, home.y);
        spr.setFrame(opts.sleep ? 2 : Math.floor(this.bob / 900) % 4 === 0 ? 1 : 0);
      } else {
        const dx = player.x - spr.x;
        const dy = player.y - spr.y;
        const dist = Math.hypot(dx, dy);
        if (dist > 260) {
          spr.setPosition(player.x - 18, player.y + 4);
        } else if (dist > 26) {
          const speed = (dist > 80 ? GAME_CONFIG.player.runSpeed : GAME_CONFIG.player.walkSpeed) * (delta / 1000);
          spr.x += (dx / dist) * speed;
          spr.y += (dy / dist) * speed;
          if (Math.abs(dx) > 2) spr.setFlipX(dx < 0);
          spr.setFrame(Math.floor(this.bob / 140) % 2);
        } else {
          spr.setFrame(0);
        }
      }
      spr.setDepth(DEPTH.ySortBase + spr.y);
      s.shadow.setPosition(spr.x, spr.y - 1);
    }
  }

  setVisible(v: boolean): void {
    for (const s of this.sprites) {
      s.sprite.setVisible(v);
      s.shadow.setVisible(v);
    }
  }

  hop(): void {
    const s = this.sprites[0];
    if (s) this.scene.tweens.add({ targets: s.sprite, y: s.sprite.y - 6, duration: 120, yoyo: true });
  }
}
