import { P } from './palette';
import { PixelCanvas } from './PixelCanvas';

/**
 * Pet sprites, facing right (flip for left): stand, walk, curled up asleep.
 * Sheet of three 16x14 frames.
 */
export function drawPetSheet(kind: 'cat' | 'dog'): PixelCanvas {
  const p = new PixelCanvas(48, 14);
  const body = kind === 'cat' ? '#e8923a' : '#9a6a3a';
  const light = kind === 'cat' ? '#f6c08a' : '#c8945a';
  const dark = kind === 'cat' ? '#b8642a' : '#6a4422';
  for (let f = 0; f < 2; f++) {
    const ox = f * 16;
    // Body.
    p.rect(ox + 3, 6, 9, 4, body);
    p.rect(ox + 3, 6, 9, 1, light);
    // Head.
    p.rect(ox + 10, 3, 5, 5, body);
    p.rect(ox + 11, 6, 3, 1, light);
    p.set(ox + 13, 4, '#1a1412');
    if (kind === 'cat') {
      p.set(ox + 10, 2, body);
      p.set(ox + 14, 2, body);
    } else {
      p.rect(ox + 10, 3, 1, 3, dark);
      p.set(ox + 15, 6, '#1a1412');
    }
    // Legs (walk frame shifts them).
    const s = f === 1 ? 1 : 0;
    for (const x of [4 + s, 6 - s, 9 + s, 11 - s]) p.rect(ox + x, 10, 1, 3, dark);
    // Tail.
    if (kind === 'cat') {
      p.rect(ox + 1, 3, 1, 4, body);
      p.set(ox + 2, 6, body);
    } else {
      p.rect(ox + 1, 4 + f, 2, 1, body);
      p.set(ox + 2, 5, body);
    }
  }
  // Asleep: a curled ball.
  const ox = 32;
  for (let y = 6; y <= 12; y++) for (let x = 2; x <= 13; x++) if (((x - 7.5) / 6) ** 2 + ((y - 9.5) / 3.5) ** 2 <= 1) p.set(ox + x, y, y < 8 ? light : body);
  p.rect(ox + 9, 8, 3, 1, dark);
  if (kind === 'cat') p.set(ox + 11, 6, body);
  p.outline(P.outline);
  return p;
}
