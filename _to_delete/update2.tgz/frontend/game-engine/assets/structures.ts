import { P } from './palette';
import { PixelCanvas } from './PixelCanvas';
import type { Rng } from '../utils/random';

const METAL = { base: '#3b3b45', light: '#5c5c6a' };
const GLASS = { day: '#9fd3ea', glow: '#ffe9a8', glowLight: '#fff6d6' };
const ROOF = { base: '#a3483a', dark: '#7e3329', light: '#c45f4c' };

/**
 * Fence segment, 16x22, standing on row 21. `east`/`west` draw rails toward
 * neighbouring fences; vertical neighbours meet naturally post-to-post.
 * No outline, so rails join seamlessly across tiles.
 */
export function drawFence(east: boolean, west: boolean): PixelCanvas {
  const p = new PixelCanvas(16, 22);
  for (const rowTop of [9, 14]) {
    for (const [on, x0, x1] of [
      [west, 0, 6],
      [east, 9, 15],
    ] as const) {
      if (!on) continue;
      p.rect(x0, rowTop, x1 - x0 + 1, 1, P.woodLight);
      p.rect(x0, rowTop + 1, x1 - x0 + 1, 1, P.wood);
      p.rect(x0, rowTop + 2, x1 - x0 + 1, 1, P.woodDark);
    }
  }
  p.rect(6, 5, 4, 17, P.wood);
  p.rect(6, 5, 1, 17, P.woodLight);
  p.rect(9, 5, 1, 17, P.woodDark);
  p.rect(6, 4, 4, 1, P.woodDark);
  p.rect(7, 3, 2, 1, P.woodDark);
  p.rect(6, 21, 4, 1, P.trunkDark);
  return p;
}

/** Lamp post, 16x34, base row 32. */
export function drawLampPost(): PixelCanvas {
  const p = new PixelCanvas(16, 34);
  p.rect(7, 9, 2, 22, METAL.base);
  p.rect(7, 9, 1, 22, METAL.light);
  p.rect(5, 30, 6, 3, P.stoneDark);
  p.rect(5, 30, 6, 1, P.stone);
  // lantern
  p.rect(4, 3, 8, 1, METAL.base);
  p.rect(5, 2, 6, 1, METAL.base);
  p.rect(4, 4, 8, 5, METAL.base);
  p.rect(5, 4, 6, 4, GLASS.glow);
  p.rect(5, 4, 2, 2, GLASS.glowLight);
  p.rect(7, 4, 1, 4, METAL.base);
  p.rect(5, 9, 6, 1, METAL.base);
  p.outline(P.outline);
  return p;
}

/** Storage chest, 16x16, base row 14. */
export function drawChest(): PixelCanvas {
  const p = new PixelCanvas(16, 16);
  p.rect(2, 7, 12, 8, P.wood);
  p.rect(2, 14, 12, 1, P.woodDark);
  p.rect(2, 3, 12, 4, P.woodLight);
  p.rect(2, 6, 12, 1, P.woodDark);
  for (const x of [4, 11]) p.rect(x, 3, 1, 12, '#9c5525');
  p.rect(7, 6, 2, 3, '#e8c25a');
  p.set(7, 8, P.outline);
  p.outline(P.outline);
  return p;
}

/** The player's cottage, 48x52, three tiles wide, base row 50. */
export function drawCottage(rng: Rng): PixelCanvas {
  const p = new PixelCanvas(48, 52);
  // chimney
  p.rect(34, 2, 6, 10, P.stone);
  p.rect(34, 2, 6, 1, P.stoneLight);
  p.rect(39, 2, 1, 10, P.stoneDark);
  // log walls
  for (let y = 24; y <= 50; y++) {
    const band = (y - 24) % 4;
    const c = band === 0 ? P.trunkDark : band === 1 ? P.trunkLight : P.trunk;
    p.rect(3, y, 42, 1, c);
  }
  for (let i = 0; i < 12; i++) p.set(rng.int(4, 43), rng.int(25, 49), P.trunkDark);
  // windows
  for (const x of [7, 32]) {
    p.rect(x, 31, 9, 9, P.woodDark);
    p.rect(x + 1, 32, 7, 7, GLASS.day);
    p.rect(x + 1, 32, 3, 2, '#d9f0f8');
    p.rect(x + 4, 32, 1, 7, P.woodDark);
    p.rect(x + 1, 35, 7, 1, P.woodDark);
    p.rect(x - 1, 40, 11, 2, P.woodLight);
  }
  // door
  p.rect(19, 33, 10, 17, P.woodDark);
  p.rect(20, 34, 8, 16, P.wood);
  for (const x of [22, 25]) p.rect(x, 34, 1, 16, P.woodDark);
  p.set(26, 42, '#e8c25a');
  p.rect(17, 50, 14, 1, P.stoneDark);
  // roof: shingled trapezoid overhanging the walls
  for (let y = 6; y <= 26; y++) {
    const inset = Math.max(0, Math.round((26 - y) * 0.45));
    const x0 = inset;
    const x1 = 47 - inset;
    for (let x = x0; x <= x1; x++) {
      const row = Math.floor((y - 6) / 3);
      const shift = row % 2 === 0 ? 0 : 2;
      let c: string = (x + shift) % 4 === 0 ? ROOF.dark : ROOF.base;
      if ((y - 6) % 3 === 2) c = ROOF.dark;
      if (x < x0 + 2) c = ROOF.light;
      if (y === 26) c = ROOF.dark;
      p.set(x, y, c);
    }
  }
  p.rect(10, 6, 28, 1, ROOF.light);
  p.outline(P.outline);
  return p;
}

/** Floor tiles for the tileset (no transparency). */
export function woodPathTile(rng: Rng): PixelCanvas {
  const t = new PixelCanvas(16, 16);
  for (let y = 0; y < 16; y++) {
    const c = y % 4 === 3 ? P.woodDark : y % 4 === 0 ? P.woodLight : P.wood;
    t.rect(0, y, 16, 1, c);
  }
  for (let row = 0; row < 4; row++) {
    const x = (row * 7 + rng.int(0, 3)) % 16;
    t.rect(x, row * 4, 1, 3, P.woodDark);
  }
  for (let i = 0; i < 4; i++) t.set(rng.int(0, 15), rng.int(0, 15), P.trunk);
  return t;
}

export function stonePathTile(rng: Rng): PixelCanvas {
  const t = new PixelCanvas(16, 16);
  t.rect(0, 0, 16, 16, P.stoneDark);
  const stones: Array<[number, number, number, number]> = [
    [1, 1, 6, 5],
    [8, 1, 7, 4],
    [1, 7, 4, 4],
    [6, 6, 5, 5],
    [12, 6, 3, 5],
    [1, 12, 7, 3],
    [9, 12, 6, 3],
  ];
  for (const [x, y, w, h] of stones) {
    t.rect(x, y, w, h, rng.chance(0.5) ? P.stone : P.stoneLight);
    t.rect(x, y, w, 1, P.stoneHi);
    t.rect(x, y + h - 1, w, 1, P.stone);
  }
  return t;
}

/** Soft radial light used to cut through the night overlay. */
export function drawLight(size: number): PixelCanvas {
  const p = new PixelCanvas(size, size);
  const r = size / 2;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const d = Math.hypot(x + 0.5 - r, y + 0.5 - r) / r;
      if (d >= 1) continue;
      const a = 1 - d * d * (3 - 2 * d); // smoothstep falloff
      p.set(x, y, '#ffffff', Math.round(a * 255));
    }
  }
  return p;
}
