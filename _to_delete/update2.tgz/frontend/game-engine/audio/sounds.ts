import { bandpass, envelope, highpass, lowpass, noiseSource, oscillator, render, sweep, type Wave } from './dsp';

/** Every sound effect in the game. */
export type SfxName =
  | 'chop'
  | 'mine'
  | 'clunk'
  | 'treeFall'
  | 'rockBreak'
  | 'swish'
  | 'rustle'
  | 'till'
  | 'water'
  | 'refill'
  | 'plant'
  | 'harvest'
  | 'sparkle'
  | 'pickup'
  | 'place'
  | 'whoosh'
  | 'eat'
  | 'coin'
  | 'craft'
  | 'error'
  | 'uiOpen'
  | 'uiClose'
  | 'talk'
  | 'cluck'
  | 'step'
  | 'sleep'
  | 'morning'
  | 'cast'
  | 'splash'
  | 'bite'
  | 'catch'
  | 'heart'
  | 'quest';

type Builder = (ctx: BaseAudioContext) => AudioBuffer;

/** A short tone with optional pitch glide. */
function tone(ctx: BaseAudioContext, wave: Wave, from: number, to: number, seconds: number, attack = 0.005, gain = 0.5): AudioBuffer {
  const osc = sweep(ctx.sampleRate);
  return render(ctx, seconds, (t) => oscillator(wave, osc(from + (to - from) * (t / seconds))) * envelope(t, attack, seconds - attack), gain);
}

/** A sequence of notes [frequency, start, duration]. */
function notes(ctx: BaseAudioContext, wave: Wave, list: Array<[number, number, number]>, gain = 0.35): AudioBuffer {
  const total = Math.max(...list.map(([, s, d]) => s + d));
  return render(
    ctx,
    total,
    (t) => {
      let v = 0;
      for (const [f, s, d] of list) {
        if (t < s || t > s + d) continue;
        const lt = t - s;
        v += oscillator(wave, f * lt) * envelope(lt, 0.004, d, 2.5);
      }
      return v;
    },
    gain,
  );
}

export const SFX: Record<SfxName, Builder> = {
  cast: (ctx) => {
    const n = noiseSource(41);
    const bp = bandpass(ctx.sampleRate);
    return render(ctx, 0.35, (t) => bp(n(), 900 + 2600 * (t / 0.35), 1.2) * envelope(t, 0.02, 0.33, 2) * 2.2, 0.45);
  },
  splash: (ctx) => {
    const n = noiseSource(42);
    const lp = lowpass(ctx.sampleRate);
    const osc = sweep(ctx.sampleRate);
    return render(ctx, 0.4, (t) => (lp(n(), 1800 - 1400 * (t / 0.4)) * 1.6 + oscillator('sine', osc(520 - 300 * (t / 0.4))) * 0.3) * envelope(t, 0.004, 0.38, 3), 0.5);
  },
  bite: (ctx) => notes(ctx, 'square', [
    [988, 0, 0.06],
    [1319, 0.07, 0.1],
  ], 0.3),
  catch: (ctx) => notes(ctx, 'triangle', [
    [523, 0, 0.12],
    [784, 0.1, 0.12],
    [1047, 0.2, 0.3],
  ], 0.34),
  heart: (ctx) => notes(ctx, 'sine', [
    [880, 0, 0.14],
    [1175, 0.12, 0.22],
  ], 0.3),
  quest: (ctx) => notes(ctx, 'triangle', [
    [659, 0, 0.12],
    [784, 0.11, 0.12],
    [988, 0.22, 0.12],
    [1319, 0.33, 0.4],
  ], 0.3),
  // Axe into wood: low thump plus a woody knock.
  chop: (ctx) => {
    const n = noiseSource(11);
    const lp = lowpass(ctx.sampleRate);
    const osc = sweep(ctx.sampleRate);
    return render(ctx, 0.22, (t) => {
      const thump = oscillator('sine', osc(170 - t * 300)) * envelope(t, 0.002, 0.16);
      const knock = lp(n(), 1400) * envelope(t, 0.001, 0.07);
      return thump * 0.8 + knock * 1.6;
    }, 0.7);
  },
  // Pickaxe on stone: bright metallic ping.
  mine: (ctx) => {
    const n = noiseSource(12);
    const hp = highpass(ctx.sampleRate);
    return render(ctx, 0.35, (t) => {
      const ring = (oscillator('sine', 1870 * t) + 0.6 * oscillator('sine', 2730 * t) + 0.3 * oscillator('sine', 4100 * t)) * envelope(t, 0.001, 0.32, 4);
      const click = hp(n(), 2500) * envelope(t, 0.0005, 0.03);
      return ring * 0.35 + click;
    }, 0.55);
  },
  // Wrong tool: dull bonk.
  clunk: (ctx) => tone(ctx, 'triangle', 220, 140, 0.14, 0.002, 0.5),
  treeFall: (ctx) => {
    const n = noiseSource(13);
    const lp = lowpass(ctx.sampleRate);
    const osc = sweep(ctx.sampleRate);
    return render(ctx, 0.9, (t) => {
      const crack = t < 0.25 ? lp(n(), 2500) * envelope(t, 0.002, 0.25, 2) : 0;
      const rustle = lp(n(), 900 + 600 * Math.sin(t * 30)) * envelope(Math.max(0, t - 0.15), 0.1, 0.55, 2) * 0.7;
      const thud = t > 0.62 ? oscillator('sine', osc(70)) * envelope(t - 0.62, 0.003, 0.26) : 0;
      return crack + rustle + thud * 1.4;
    }, 0.6);
  },
  rockBreak: (ctx) => {
    const n = noiseSource(14);
    const bp = bandpass(ctx.sampleRate);
    return render(ctx, 0.45, (t) => {
      const grains = Math.sin(t * 90) > 0.3 ? 1 : 0.4;
      return bp(n(), 1100 - t * 900) * envelope(t, 0.002, 0.42, 2) * grains * 2.2;
    }, 0.6);
  },
  // Cutting grass: airy swish.
  swish: (ctx) => {
    const n = noiseSource(15);
    const bp = bandpass(ctx.sampleRate);
    return render(ctx, 0.16, (t) => bp(n(), 2500 + t * 9000) * envelope(t, 0.03, 0.13, 2) * 2.4, 0.5);
  },
  rustle: (ctx) => {
    const n = noiseSource(16);
    const bp = bandpass(ctx.sampleRate);
    return render(ctx, 0.3, (t) => bp(n(), 3200) * envelope(t, 0.02, 0.28, 2) * (0.6 + 0.4 * Math.sin(t * 70)) * 2, 0.45);
  },
  // Hoe in soil: crunchy scrape.
  till: (ctx) => {
    const n = noiseSource(17);
    const bp = bandpass(ctx.sampleRate);
    return render(ctx, 0.2, (t) => bp(n(), 700) * envelope(t, 0.005, 0.18, 2) * (Math.sin(t * 160) > 0 ? 1.6 : 0.9) * 2, 0.6);
  },
  water: (ctx) => {
    const n = noiseSource(18);
    const bp = bandpass(ctx.sampleRate);
    return render(ctx, 0.45, (t) => bp(n(), 1600 + 900 * Math.sin(t * 22)) * envelope(t, 0.04, 0.4, 2) * 2.2, 0.45);
  },
  refill: (ctx) => {
    const blips: Array<[number, number, number]> = [];
    for (let i = 0; i < 7; i++) blips.push([420 + ((i * 137) % 380), i * 0.045, 0.06]);
    return notes(ctx, 'sine', blips, 0.3);
  },
  plant: (ctx) => tone(ctx, 'sine', 320, 620, 0.12, 0.003, 0.45),
  harvest: (ctx) => notes(ctx, 'triangle', [
    [523, 0, 0.12],
    [659, 0.06, 0.12],
    [784, 0.12, 0.2],
  ]),
  sparkle: (ctx) => notes(ctx, 'sine', [
    [1568, 0, 0.15],
    [2093, 0.05, 0.15],
    [2637, 0.1, 0.25],
  ], 0.22),
  pickup: (ctx) => tone(ctx, 'square', 880, 1320, 0.08, 0.002, 0.18),
  place: (ctx) => {
    const n = noiseSource(19);
    const lp = lowpass(ctx.sampleRate);
    const osc = sweep(ctx.sampleRate);
    return render(ctx, 0.18, (t) => oscillator('sine', osc(240 - t * 400)) * envelope(t, 0.002, 0.15) + lp(n(), 1800) * envelope(t, 0.001, 0.05), 0.55);
  },
  whoosh: (ctx) => {
    const n = noiseSource(20);
    const bp = bandpass(ctx.sampleRate);
    return render(ctx, 0.18, (t) => bp(n(), 600 + t * 5000, 0.5) * envelope(t, 0.06, 0.12, 2) * 1.6, 0.35);
  },
  eat: (ctx) => {
    const n = noiseSource(21);
    const bp = bandpass(ctx.sampleRate);
    return render(ctx, 0.42, (t) => {
      const bite = [0, 0.14, 0.28].some((s) => t >= s && t < s + 0.08);
      return bite ? bp(n(), 2200) * 2.4 * envelope((t % 0.14), 0.002, 0.08) : 0;
    }, 0.5);
  },
  coin: (ctx) => notes(ctx, 'square', [
    [1319, 0, 0.07],
    [1760, 0.07, 0.22],
  ], 0.16),
  craft: (ctx) => {
    const clink = (offset: number, t: number) =>
      t < offset ? 0 : (oscillator('sine', 2200 * (t - offset)) + 0.5 * oscillator('sine', 3300 * (t - offset))) * envelope(t - offset, 0.001, 0.18, 4);
    return render(ctx, 0.5, (t) => clink(0, t) + clink(0.17, t) * 0.9 + (t > 0.32 ? oscillator('triangle', 784 * (t - 0.32)) * envelope(t - 0.32, 0.005, 0.18) : 0), 0.3);
  },
  error: (ctx) => notes(ctx, 'square', [
    [196, 0, 0.09],
    [155, 0.1, 0.14],
  ], 0.14),
  uiOpen: (ctx) => tone(ctx, 'sine', 600, 900, 0.07, 0.003, 0.3),
  uiClose: (ctx) => tone(ctx, 'sine', 800, 520, 0.07, 0.003, 0.25),
  talk: (ctx) => notes(ctx, 'triangle', [
    [587, 0, 0.06],
    [698, 0.07, 0.06],
    [659, 0.14, 0.08],
  ], 0.28),
  cluck: (ctx) => {
    const osc = sweep(ctx.sampleRate);
    return render(ctx, 0.32, (t) => {
      const burst = t < 0.09 || (t > 0.13 && t < 0.2) || t > 0.24;
      const f = 600 + 400 * Math.sin(t * 60) * (t > 0.24 ? 1.5 : 1);
      return burst ? oscillator('square', osc(f)) * 0.5 * envelope(t % 0.11, 0.004, 0.09) : 0;
    }, 0.25);
  },
  step: (ctx) => {
    const n = noiseSource(22);
    const lp = lowpass(ctx.sampleRate);
    return render(ctx, 0.06, (t) => lp(n(), 900) * envelope(t, 0.002, 0.055), 0.5);
  },
  sleep: (ctx) => notes(ctx, 'sine', [
    [784, 0, 0.5],
    [659, 0.25, 0.5],
    [523, 0.5, 0.5],
    [392, 0.75, 0.9],
  ], 0.3),
  morning: (ctx) => notes(ctx, 'triangle', [
    [523, 0, 0.25],
    [659, 0.15, 0.25],
    [784, 0.3, 0.25],
    [1047, 0.45, 0.6],
  ], 0.28),
};

/** Looping ambience beds. */
export const LOOPS = {
  // Gentle broadband rain: filtered noise with slow swells.
  rain: (ctx: BaseAudioContext) => {
    const n = noiseSource(31);
    const lp = lowpass(ctx.sampleRate);
    const hp = highpass(ctx.sampleRate);
    return render(ctx, 4, (t) => hp(lp(n(), 2400), 300) * (0.8 + 0.2 * Math.sin(t * Math.PI * 0.5)) * 1.4, 0.5);
  },
  // Soft wind for snowy days.
  wind: (ctx: BaseAudioContext) => {
    const n = noiseSource(32);
    const bp = bandpass(ctx.sampleRate);
    return render(ctx, 6, (t) => bp(n(), 400 + 250 * Math.sin(t * Math.PI / 3), 0.5) * (0.6 + 0.4 * Math.sin((t * Math.PI) / 3)) * 2, 0.5);
  },
} as const;

/** One bird chirp (pitched by the caller for variety). */
export const birdChirp: Builder = (ctx) => {
  const osc = sweep(ctx.sampleRate);
  return render(ctx, 0.28, (t) => {
    const seg = Math.floor(t / 0.07);
    const lt = t - seg * 0.07;
    const f = 2600 + 1400 * Math.sin(lt * 70) + seg * 200;
    return oscillator('sine', osc(f)) * envelope(lt, 0.005, 0.06, 2);
  }, 0.18);
};

/** A cricket trill. */
export const cricket: Builder = (ctx) =>
  render(ctx, 0.4, (t) => oscillator('sine', 4400 * t) * (Math.sin(t * Math.PI * 2 * 28) > 0 ? 1 : 0) * envelope(t, 0.02, 0.38, 1.5), 0.08);

/** A soft music note (plucked) used by the music sequencer. */
export function pluck(ctx: BaseAudioContext, freq: number, seconds: number): AudioBuffer {
  return render(ctx, seconds, (t) => (oscillator('triangle', freq * t) * 0.7 + oscillator('sine', freq * 2 * t) * 0.3) * envelope(t, 0.006, seconds, 3), 0.3);
}

/** A slow pad note for chords. */
export function pad(ctx: BaseAudioContext, freq: number, seconds: number): AudioBuffer {
  return render(
    ctx,
    seconds,
    (t) => (oscillator('sine', freq * t) + 0.4 * oscillator('sine', freq * 1.5 * t) + 0.25 * oscillator('triangle', freq * 0.5 * t)) * Math.min(1, t / 0.6) * Math.min(1, (seconds - t) / 0.8),
    0.12,
  );
}
