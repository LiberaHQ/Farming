import type * as Phaser from 'phaser';
import type { Season, WeatherKind } from '@farming/shared';
import { gameEvents } from '../events/GameEventBus';
import { midiToFreq } from './dsp';
import { birdChirp, cricket, LOOPS, pad, pluck, SFX, type SfxName } from './sounds';

export type AudioChannel = 'master' | 'music' | 'sfx' | 'ambience';

export interface AudioSettings {
  master: number;
  music: number;
  sfx: number;
  ambience: number;
  muted: boolean;
}

const SETTINGS_KEY = 'farming-game:audio';
const DEFAULTS: AudioSettings = { master: 0.8, music: 0.45, sfx: 0.8, ambience: 0.6, muted: false };

function loadSettings(): AudioSettings {
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULTS };
    const s = JSON.parse(raw) as Partial<AudioSettings>;
    const vol = (v: unknown, d: number) => (typeof v === 'number' && v >= 0 && v <= 1 ? v : d);
    return {
      master: vol(s.master, DEFAULTS.master),
      music: vol(s.music, DEFAULTS.music),
      sfx: vol(s.sfx, DEFAULTS.sfx),
      ambience: vol(s.ambience, DEFAULTS.ambience),
      muted: s.muted === true,
    };
  } catch {
    return { ...DEFAULTS };
  }
}

export interface AudioContextState {
  minute: number;
  weather: WeatherKind;
  season: Season;
}

const MAJOR = [0, 2, 4, 7, 9];
const MINOR = [0, 3, 5, 7, 10];
/** Each season has its own key and mood. */
const SEASON_KEYS: Record<Season, { root: number; scale: number[]; chords: number[] }> = {
  spring: { root: 60, scale: MAJOR, chords: [0, 9, 5, 7] },
  summer: { root: 62, scale: MAJOR, chords: [0, 5, 9, 7] },
  fall: { root: 57, scale: MINOR, chords: [0, 8, 3, 10] },
  winter: { root: 64, scale: MINOR, chords: [0, 3, 8, 7] },
};
const BPM = 76;
const EIGHTH = 60 / BPM / 2;

/**
 * Game audio: synthesised sound effects, ambience (birds by day, crickets at
 * night, rain and wind loops) and a gentle generative score that follows the
 * season and time of day. Volumes are per channel and remembered.
 */
export class AudioSystem {
  private readonly ctx: AudioContext | null;
  private readonly bus = {} as Record<AudioChannel, GainNode>;
  private readonly buffers = new Map<string, AudioBuffer>();
  private readonly loops = new Map<'rain' | 'wind', { source: AudioBufferSourceNode; gain: GainNode }>();
  private settings = loadSettings();
  private birdTimer = 2000;
  private cricketTimer = 1000;
  private nextNote = 0;
  private step = 0;
  private melodyIndex = 2;
  private night = false;

  constructor(scene: Phaser.Scene) {
    const manager = scene.sound as Phaser.Sound.WebAudioSoundManager;
    this.ctx = 'context' in manager && manager.context ? manager.context : null;
    if (!this.ctx) return;

    const ctx = this.ctx;
    this.bus.master = ctx.createGain();
    this.bus.master.connect(ctx.destination);
    for (const ch of ['music', 'sfx', 'ambience'] as const) {
      this.bus[ch] = ctx.createGain();
      this.bus[ch].connect(this.bus.master);
    }
    for (const name of Object.keys(SFX) as SfxName[]) this.buffers.set(name, SFX[name](ctx));
    this.buffers.set('bird', birdChirp(ctx));
    this.buffers.set('cricket', cricket(ctx));
    for (const kind of ['rain', 'wind'] as const) {
      const source = ctx.createBufferSource();
      source.buffer = LOOPS[kind](ctx);
      source.loop = true;
      const gain = ctx.createGain();
      gain.gain.value = 0;
      source.connect(gain).connect(this.bus.ambience);
      source.start();
      this.loops.set(kind, { source, gain });
    }
    this.applySettings();
  }

  get current(): AudioSettings {
    return { ...this.settings };
  }

  /** Plays a sound effect. `vary` adds slight random pitch so repeats don't sound robotic. */
  play(name: SfxName, options: { volume?: number; rate?: number; vary?: number } = {}): void {
    const buffer = this.buffers.get(name);
    if (!this.ctx || !buffer || this.settings.muted) return;
    const source = this.ctx.createBufferSource();
    source.buffer = buffer;
    const vary = options.vary ?? 0.06;
    source.playbackRate.value = (options.rate ?? 1) * (1 + (Math.random() * 2 - 1) * vary);
    const gain = this.ctx.createGain();
    gain.gain.value = options.volume ?? 1;
    source.connect(gain).connect(this.bus.sfx);
    source.start();
  }

  set(channel: AudioChannel, value: number): void {
    if (!Number.isFinite(value)) return;
    this.settings = { ...this.settings, [channel]: Math.max(0, Math.min(1, value)) };
    this.applySettings();
  }

  toggleMute(): void {
    this.settings = { ...this.settings, muted: !this.settings.muted };
    this.applySettings();
  }

  emit(): void {
    gameEvents.emit('audio:settings', { ...this.settings });
  }

  /** Ambience and music; call every frame. */
  update(delta: number, state: AudioContextState): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const h = state.minute / 60;
    this.night = h >= 20 || h < 5.5;
    const wet = state.weather === 'rain';

    // Weather loops fade in and out.
    const set = (kind: 'rain' | 'wind', target: number) => this.loops.get(kind)?.gain.gain.setTargetAtTime(target, ctx.currentTime, 0.8);
    set('rain', wet ? 0.55 : 0);
    set('wind', state.weather === 'snow' ? 0.4 : 0);

    // Birds by day in fair weather; crickets on warm nights.
    this.birdTimer -= delta;
    if (this.birdTimer <= 0) {
      this.birdTimer = 1500 + Math.random() * 4500;
      if (!this.night && h < 19 && !wet && state.weather !== 'snow' && state.season !== 'winter') {
        const count = 1 + Math.floor(Math.random() * 3);
        const pitch = 0.8 + Math.random() * 0.5;
        for (let i = 0; i < count; i++) this.scheduleAmbient('bird', ctx.currentTime + i * 0.18, pitch, 0.5 + Math.random() * 0.5);
      }
    }
    this.cricketTimer -= delta;
    if (this.cricketTimer <= 0) {
      this.cricketTimer = 500 + Math.random() * 1600;
      if (this.night && !wet && state.season !== 'winter') this.scheduleAmbient('cricket', ctx.currentTime, 0.95 + Math.random() * 0.1, 0.6 + Math.random() * 0.4);
    }

    this.scheduleMusic(state.season);
  }

  destroy(): void {
    for (const { source } of this.loops.values()) {
      try {
        source.stop();
      } catch {
        // already stopped
      }
    }
    this.bus.master?.disconnect();
  }

  private scheduleAmbient(key: 'bird' | 'cricket', when: number, rate: number, volume: number): void {
    const buffer = this.buffers.get(key);
    if (!this.ctx || !buffer) return;
    const source = this.ctx.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = rate;
    const gain = this.ctx.createGain();
    gain.gain.value = volume;
    // Gentle stereo placement so the world feels wide.
    const panner = this.ctx.createStereoPanner();
    panner.pan.value = Math.random() * 1.6 - 0.8;
    source.connect(gain).connect(panner).connect(this.bus.ambience);
    source.start(when);
  }

  /** Schedules the generative score a little ahead of time on the audio clock. */
  private scheduleMusic(season: Season): void {
    const ctx = this.ctx!;
    if (this.nextNote < ctx.currentTime) this.nextNote = ctx.currentTime + 0.1;
    const key = SEASON_KEYS[season];
    while (this.nextNote < ctx.currentTime + 0.6) {
      const bar = Math.floor(this.step / 8) % key.chords.length;
      const beat = this.step % 8;
      const chordRoot = key.root - 12 + key.chords[bar];
      if (beat === 0) {
        // Pad: root, fifth and octave, sustained for the bar.
        for (const interval of [0, 7, 12]) this.playNote(pad, midiToFreq(chordRoot + interval), EIGHTH * 8.5, this.nextNote, this.night ? 0.6 : 1);
      }
      const density = this.night ? 0.18 : 0.38;
      if (beat % 2 === 0 ? Math.random() < density + 0.15 : Math.random() < density * 0.5) {
        this.melodyIndex = Math.max(0, Math.min(key.scale.length * 2 - 1, this.melodyIndex + Math.floor(Math.random() * 5) - 2));
        const octave = Math.floor(this.melodyIndex / key.scale.length);
        const note = key.root + 12 * octave + key.scale[this.melodyIndex % key.scale.length];
        this.playNote(pluck, midiToFreq(note), EIGHTH * (beat % 4 === 0 ? 3 : 2), this.nextNote, this.night ? 0.55 : 0.9);
      }
      this.step += 1;
      this.nextNote += EIGHTH;
    }
  }

  private playNote(make: (ctx: BaseAudioContext, f: number, s: number) => AudioBuffer, freq: number, seconds: number, when: number, volume: number): void {
    const ctx = this.ctx!;
    const cacheKey = `${make.name}:${freq.toFixed(2)}:${seconds.toFixed(2)}`;
    let buffer = this.buffers.get(cacheKey);
    if (!buffer) {
      buffer = make(ctx, freq, seconds);
      this.buffers.set(cacheKey, buffer);
    }
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    const gain = ctx.createGain();
    gain.gain.value = volume;
    source.connect(gain).connect(this.bus.music);
    source.start(when);
  }

  private applySettings(): void {
    if (this.ctx) {
      const now = this.ctx.currentTime;
      this.bus.master.gain.setTargetAtTime(this.settings.muted ? 0 : this.settings.master, now, 0.05);
      this.bus.music.gain.setTargetAtTime(this.settings.music * 0.6, now, 0.05);
      this.bus.sfx.gain.setTargetAtTime(this.settings.sfx, now, 0.05);
      this.bus.ambience.gain.setTargetAtTime(this.settings.ambience, now, 0.05);
    }
    try {
      window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(this.settings));
    } catch {
      // storage unavailable
    }
    this.emit();
  }
}
