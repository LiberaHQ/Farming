import * as Phaser from 'phaser';
import { FORAGE, GAME_CONFIG, ITEMS, type ItemId } from '@farming/shared';
import { itemTextureKey, npcTextureKey, objectTextureKey, placeableTextureKey, TEXTURES } from '../assets/registerTextures';
import { PixelCanvas } from '../assets/PixelCanvas';
import { sfx } from '../audio/sfx';
import { DEPTH, SCENES } from '../constants';
import { gameEvents } from '../events/GameEventBus';
import { createRng } from '../utils/random';
import { AreaScene, type AreaAction, type AreaHost } from './AreaScene';

export interface ForestSceneData {
  host: AreaHost;
  /** Forage and hardwood taken today (each spot once a day). */
  forage: { taken(day: number): number[]; take(day: number, id: number): void };
}

const W = 40;
const H = 28;
/** Big old stumps give hardwood once a day; ids 100+ in the forage record. */
const STUMP_ID = 100;
const HERMIT = { tx: 9, ty: 6 };

const HERMIT_LINES = [
  "Hm. A visitor. Don't step on the morels.",
  'The forest gives what each season can spare. Spring is generous; winter, less so.',
  'Those old stumps? Oak, three hundred years if a day. Hardwood keeps forever.',
  "I'll pay double for anything you forage. The town folk don't know what's good.",
  'Bats in the mine, ghosts deeper down. I went once. Never again.',
  "Your grandfather used to bring me hazelnuts. He'd be glad someone's farming again.",
];

const toast = (text: string) => gameEvents.emit('toast', { text });

/**
 * The old forest west of the market: dense trees, seasonal mushrooms, herbs
 * and berries on the ground each morning, ancient stumps for hardwood, and a
 * hermit who pays double for forage.
 */
export class ForestScene extends AreaScene<ForestSceneData> {
  private forage!: ForestSceneData['forage'];
  private solid: boolean[] = [];
  private items: Array<{ id: number; sprite: Phaser.GameObjects.Image; itemId: ItemId }> = [];
  private stumps: Array<{ id: number; tx: number; ty: number; sprite: Phaser.GameObjects.Image; cut: boolean }> = [];
  private hermit!: Phaser.GameObjects.Sprite;
  private lineIndex = 0;

  constructor() {
    super(SCENES.Forest);
  }

  init(data: ForestSceneData): void {
    super.init(data);
    this.forage = data.forage;
    this.items = [];
    this.stumps = [];
  }

  create(): void {
    const size = GAME_CONFIG.tileSize;
    const { season, day } = this.host.calendar();
    const rng = createRng('forest-layout');
    this.solid = Array(W * H).fill(false);
    const key = `forest-ground-${season}`;
    if (!this.textures.exists(key)) this.textures.addCanvas(key, this.drawGround(season));
    this.add.image(0, 0, key).setOrigin(0).setDepth(DEPTH.ground);
    this.cameras.main.setBackgroundColor('#1e3a1e');

    // Trees everywhere except the trail, the clearing and the hermit's yard.
    const open = (tx: number, ty: number) => {
      const trail = Math.abs(ty - (14 + Math.round(Math.sin(tx * 0.25) * 2))) <= 1;
      const clearing = Math.hypot(tx - 20, ty - 18) < 5;
      const yard = tx >= HERMIT.tx - 3 && tx <= HERMIT.tx + 4 && ty >= HERMIT.ty - 2 && ty <= HERMIT.ty + 4;
      const branch = tx >= HERMIT.tx && tx <= HERMIT.tx + 1 && ty > HERMIT.ty && ty < 15;
      return trail || clearing || yard || branch || tx >= W - 2;
    };
    for (let ty = 1; ty < H - 1; ty += 2) {
      for (let tx = 1; tx < W - 2; tx += 2) {
        const x = tx + rng.int(0, 1);
        const y = ty + rng.int(0, 1);
        if (open(x, y) || rng.chance(0.18)) continue;
        const kind = rng.chance(0.55) ? 'pine' : 'oak';
        const variant = rng.int(0, kind === 'oak' ? 2 : 1);
        const tex = objectTextureKey(kind, variant, season);
        const baseY = y * size + size - 2;
        this.add.image(x * size + size / 2, baseY, tex).setOrigin(0.5, kind === 'oak' ? 41 / 44 : 44 / 46).setDepth(DEPTH.ySortBase + baseY);
        this.add.image(x * size + size / 2, baseY - 1, TEXTURES.shadowLarge).setDepth(DEPTH.shadow);
        this.solid[y * W + x] = true;
      }
    }
    // The hermit's cabin and the hermit.
    const cabinBase = HERMIT.ty * size + size - 2;
    this.add.image((HERMIT.tx + 1.5) * size, cabinBase, placeableTextureKey('cottage')).setOrigin(0.5, 51 / 52).setDepth(DEPTH.ySortBase + cabinBase).setTint(0xb8a890).setScale(0.85);
    for (let i = 0; i < 3; i++) this.solid[HERMIT.ty * W + HERMIT.tx + i] = true;
    this.hermit = this.add.sprite((HERMIT.tx + 3.5) * size, (HERMIT.ty + 2) * size + 12, npcTextureKey('tobin'), 0).setOrigin(0.5, 1).setTint(0xb8a8c8);
    this.hermit.setDepth(DEPTH.ySortBase + this.hermit.y);
    this.solid[(HERMIT.ty + 2) * W + HERMIT.tx + 3] = true;

    // Ancient stumps for hardwood.
    const taken = new Set(this.forage.taken(day));
    const stumpSpots = [
      [16, 17],
      [24, 20],
      [30, 11],
    ];
    stumpSpots.forEach(([tx, ty], i) => {
      const id = STUMP_ID + i;
      const baseY = ty * size + size - 2;
      const sprite = this.add.image(tx * size + size / 2, baseY, objectTextureKey('stump', 0)).setOrigin(0.5, 11 / 12).setDepth(DEPTH.ySortBase + baseY).setScale(1.4);
      const cut = taken.has(id);
      if (cut) sprite.setAlpha(0.45);
      this.solid[ty * W + tx] = true;
      this.stumps.push({ id, tx, ty, sprite, cut });
    });

    this.walls = this.physics.add.staticGroup();
    this.addSolidRuns(W, H, (tx, ty) => this.isSolid(tx, ty));
    this.walls.add(this.add.zone((W * size) / 2, -4, W * size, 8));
    this.walls.add(this.add.zone((W * size) / 2, H * size + 4, W * size, 8));
    this.walls.add(this.add.zone(-4, (H * size) / 2, 8, H * size));

    const entryY = 14 + Math.round(Math.sin((W - 3) * 0.25) * 2);
    this.setupArea(W, H, { x: (W - 3) * size, y: entryY * size + 12, facing: 'left' });
    this.spawnForage(day, season);
    gameEvents.emit('area:label', { label: '🌲 The Old Forest' });
    // Birdsong and rustling.
    this.time.addEvent({ delay: 3400, loop: true, callback: () => sfx('rustle', { volume: 0.12, rate: 0.7 + Math.random() * 0.4 }) });
  }

  protected tick(): void {
    // Walk off the right edge to go home.
    if (!this.leaving && this.player.x > W * GAME_CONFIG.tileSize - 6) this.leave();
    const day = this.host.calendar().day;
    for (let i = this.items.length - 1; i >= 0; i--) {
      const it = this.items[i];
      if (Math.hypot(it.sprite.x - this.player.x, it.sprite.y - this.player.y + 4) > 9) continue;
      if (this.host.state.inventory.add(it.itemId, 1) > 0) continue;
      this.forage.take(day, it.id);
      gameEvents.emit('item:collected', { itemId: it.itemId, quantity: 1 });
      sfx('pickup');
      it.sprite.destroy();
      this.items.splice(i, 1);
    }
  }

  protected resolve(mode: 'use' | 'interact'): AreaAction | null {
    const { tx, ty } = this.target();
    const feet = this.player.tile;
    if (feet.tx >= W - 2) return { verb: 'Back to the farm', key: 'E', run: () => this.leave() };
    const hermitNear = Math.hypot(this.hermit.x - this.player.x, this.hermit.y - this.player.y) < 22;
    if (hermitNear) {
      const stack = this.host.state.inventory.selectedStack;
      const forage = stack && (Object.values(FORAGE).flat() as ItemId[]).includes(stack.itemId);
      if (forage && stack && mode === 'use') {
        const price = (ITEMS[stack.itemId].sellPrice ?? 0) * 2;
        return {
          verb: `Sell ${stack.quantity}× ${ITEMS[stack.itemId].name} to the hermit (${price * stack.quantity}g)`,
          key: 'Space',
          run: () => {
            const slot = this.host.state.inventory.selected;
            const n = this.host.state.inventory.removeAt(slot, stack.quantity);
            if (n <= 0) return;
            this.host.state.earn(price * n);
            sfx('coin');
            toast(`The hermit paid ${price * n}g. "Good finds."`);
          },
        };
      }
      return {
        verb: 'Talk to the hermit',
        key: 'E',
        run: () => {
          const line = HERMIT_LINES[this.lineIndex++ % HERMIT_LINES.length];
          if (this.host.say) this.host.say('The Hermit', line);
          else toast(line);
        },
      };
    }
    const stump = this.stumps.find((s) => s.tx === tx && s.ty === ty);
    if (stump) {
      const stack = this.host.state.inventory.selectedStack;
      const tool = stack ? ITEMS[stack.itemId].tool : undefined;
      if (stump.cut) return { verb: 'Already cut today', key: 'Space', info: true, run: () => toast('The stump will be ready for more hardwood tomorrow.') };
      if (tool?.kind !== 'axe') return { verb: 'Needs an axe', key: 'Space', blocked: true, run: () => undefined };
      const cost = GAME_CONFIG.energy.toolCost * 2;
      return {
        verb: 'Chop hardwood',
        key: 'Space',
        run: () => {
          if (!this.host.state.spendEnergy(cost)) return toast("You're too tired.");
          this.player.useTool(itemTextureKey(stack!.itemId), 'swing', () => {
            stump.cut = true;
            stump.sprite.setAlpha(0.45);
            this.forage.take(this.host.calendar().day, stump.id);
            this.fx.burst('wood', stump.sprite.x, stump.sprite.y - 8, 10);
            sfx('chop');
            this.drops.spawn('hardwood', tool.power >= 3 ? 3 : 2, stump.sprite.x, stump.sprite.y - 6);
          });
        },
      };
    }
    return null;
  }

  private isSolid(tx: number, ty: number): boolean {
    if (tx < 0 || ty < 0 || tx >= W || ty >= H) return true;
    return this.solid[ty * W + tx];
  }

  private spawnForage(day: number, season: keyof typeof FORAGE): void {
    const size = GAME_CONFIG.tileSize;
    const taken = new Set(this.forage.taken(day));
    const rng = createRng(`forest-forage:${day}`);
    const pool = FORAGE[season];
    const count = rng.int(6, 10);
    for (let id = 0, tries = 0; id < count && tries < 400; tries++) {
      const tx = rng.int(2, W - 4);
      const ty = rng.int(2, H - 3);
      if (this.isSolid(tx, ty)) continue;
      const itemId = pool[rng.int(0, pool.length - 1)];
      if (!taken.has(id)) {
        const sprite = this.add.image(tx * size + 8, ty * size + 10, itemTextureKey(itemId)).setDepth(DEPTH.ySortBase + ty * size + 10).setScale(0.75);
        this.items.push({ id, sprite, itemId });
      }
      id++;
    }
  }

  private drawGround(season: string): HTMLCanvasElement {
    const size = GAME_CONFIG.tileSize;
    const rng = createRng('forest-ground');
    const p = new PixelCanvas(W * size, H * size);
    const base = season === 'winter' ? ['#dfe8ee', '#cdd8e0'] : season === 'fall' ? ['#7a8a3a', '#6a7a32'] : ['#3f7a3a', '#376e33'];
    p.rect(0, 0, W * size, H * size, base[0]);
    for (let i = 0; i < W * H * 3; i++) p.rect(rng.int(0, W * size - 2), rng.int(0, H * size - 1), 2, 1, base[1]);
    // The trail.
    for (let tx = 0; tx < W; tx++) {
      const cy = 14 + Math.round(Math.sin(tx * 0.25) * 2);
      p.rect(tx * size, cy * size - 4, size, size + 8, season === 'winter' ? '#c8c0b8' : '#9a7a4a');
    }
    // Fallen leaves / needles.
    const fleck = season === 'fall' ? ['#d9823b', '#c8452e', '#e8b83a'] : season === 'spring' ? ['#f4b8d0', '#ffffff'] : ['#2f5a2a'];
    for (let i = 0; i < 400; i++) p.set(rng.int(0, W * size - 1), rng.int(0, H * size - 1), fleck[rng.int(0, fleck.length - 1)]);
    return p.toCanvas();
  }
}
