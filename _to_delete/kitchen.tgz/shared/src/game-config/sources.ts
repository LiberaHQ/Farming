import { CROP_IDS, CROPS } from './crops';
import { FISH, FORAGE } from './activities';
import type { ItemId } from './items';
import { MACHINES } from './machines';
import { NPCS, NPC_IDS } from './npcs';
import { RECIPES } from './recipes';

const BASICS: Partial<Record<ItemId, string>> = {
  wood: 'chop trees',
  stone: 'break rocks',
  fiber: 'cut tall grass',
  copper_ore: 'copper rocks, or the mine',
  iron_ore: 'the mine (floor 5+)',
  gold_ore: 'the mine (floor 15+)',
  amethyst: 'the mine',
  berries: 'pick from berry bushes',
  egg: 'chickens lay them',
  duck_egg: 'ducks lay them',
  milk: 'milk a cow',
  wool: 'shear a sheep',
  hay: 'buy from Mira, or cut grass with a silo',
  seashell: 'the beach',
  coral: 'the beach',
  hardwood: 'old stumps in the forest',
  slime: 'slimes in the mine',
};

/** A short hint of where to get an item, for recipes and requests ("grow it", "Rosa's bakery"). */
export function whereToGet(itemId: ItemId): string {
  if (BASICS[itemId]) return BASICS[itemId]!;
  const crop = CROP_IDS.find((c) => CROPS[c].harvestItem === itemId);
  if (crop) return `grow it (seeds from Mira)`;
  if (FISH.some((f) => f.itemId === itemId)) return FISH.find((f) => f.itemId === itemId)?.water === 'ocean' ? 'fish at the beach' : 'go fishing';
  if (Object.values(FORAGE).some((list) => list.includes(itemId))) return 'forage in the forest';
  for (const id of NPC_IDS) {
    const shop = NPCS[id].shop;
    if (shop?.sells.some((s) => s.itemId === itemId)) return `buy from ${NPCS[id].name}`;
  }
  const machine = Object.values(MACHINES).find((m) => m.output === itemId);
  if (machine) return `make it in a ${machine.name.toLowerCase()}`;
  const recipe = RECIPES.find((r) => r.output.itemId === itemId);
  if (recipe) return recipe.category === 'cooking' ? 'cook it' : 'craft it';
  return 'find it around the valley';
}
