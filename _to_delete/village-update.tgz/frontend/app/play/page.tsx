import { DEFAULT_WORLD_SEED } from '@farming/shared';
import { GameCanvas } from '@/components/GameCanvas';
import { Hud } from '@/components/Hud';
import { cleanSeed } from '@/services/api';

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export const metadata = { title: 'Playing — Farming Game' };

/** The game itself. /play?seed=name picks the world (each world has its own save). */
export default async function PlayPage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  const raw = Array.isArray(params.seed) ? params.seed[0] : params.seed;
  const seed = cleanSeed(raw) ?? DEFAULT_WORLD_SEED;

  return (
    <main className="game-shell">
      <GameCanvas key={seed} seed={seed} />
      <Hud />
    </main>
  );
}
