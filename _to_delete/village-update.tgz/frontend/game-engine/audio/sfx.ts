import type { AudioSystem } from './AudioSystem';
import type { SfxName } from './sounds';

/**
 * Global access point for sound effects, so any system can play a sound
 * without wiring the audio system through every constructor. Does nothing
 * until the world scene has created its AudioSystem.
 */
let active: AudioSystem | null = null;

export function bindAudio(system: AudioSystem | null): void {
  active = system;
}

export function sfx(name: SfxName, options?: { volume?: number; rate?: number; vary?: number }): void {
  active?.play(name, options);
}
