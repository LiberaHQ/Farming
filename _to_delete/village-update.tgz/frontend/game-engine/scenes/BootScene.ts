import * as Phaser from 'phaser';
import { DEFAULT_APPEARANCE, DEFAULT_WORLD_SEED, NPCS, type NpcId } from '@farming/shared';
import { npcTextureKey, registerTextures, TEXTURES } from '../assets/registerTextures';
import { SCENES } from '../constants';
import { createCharacterAnimations } from '../entities/Player';

/** Generates all art and animations, then hands off to the world. */
export class BootScene extends Phaser.Scene {
  constructor() {
    super(SCENES.Boot);
  }

  create(): void {
    registerTextures(this, DEFAULT_APPEARANCE);
    createCharacterAnimations(this, TEXTURES.player);
    for (const id of Object.keys(NPCS) as NpcId[]) createCharacterAnimations(this, npcTextureKey(id));
    const seed = (this.registry.get('seed') as string | undefined) ?? DEFAULT_WORLD_SEED;
    this.scene.start(SCENES.World, { seed, save: this.registry.get('initialSave') ?? null });
  }
}
