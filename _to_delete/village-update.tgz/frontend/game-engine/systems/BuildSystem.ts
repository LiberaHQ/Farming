import type * as Phaser from 'phaser';
import { CHEST_SIZE, GAME_CONFIG, PLACEABLES, Terrain, isItemId, type ItemId, type PlaceableKind, type PlacedSave } from '@farming/shared';
import { fenceTextureKey, placeableTextureKey, TEXTURES } from '../assets/registerTextures';
import { TILE } from '../assets/tileIndex';
import { DEPTH } from '../constants';
import { gameEvents } from '../events/GameEventBus';
import { terrainAt, type WorldData } from '../maps/WorldData';
import { Inventory, type InventorySlot } from '../state/Inventory';
import type { LightSource } from './LightingSystem';
import type { FxSystem } from './FxSystem';
import type { Occluder, OcclusionSystem } from './OcclusionSystem';

export interface Placed {
  kind: PlaceableKind;
  tx: number;
  ty: number;
  sprite: Phaser.GameObjects.Image | null;
  shadow: Phaser.GameObjects.Image | null;
  zone: Phaser.GameObjects.Zone | null;
  occluder: Occluder | null;
  /** Chests only. */
  storage: Inventory | null;
}

export type { PlacedSave } from '@farming/shared';

interface Visual {
  originY: number;
  collider: { width: number; height: number };
}

const VISUALS: Partial<Record<PlaceableKind, Visual>> = {
  fence: { originY: 1, collider: { width: 16, height: 6 } },
  lamp_post: { originY: 33 / 34, collider: { width: 6, height: 5 } },
  chest: { originY: 15 / 16, collider: { width: 12, height: 7 } },
  cottage: { originY: 51 / 52, collider: { width: 44, height: 14 } },
  sprinkler: { originY: 15 / 16, collider: { width: 8, height: 5 } },
  bench: { originY: 13 / 14, collider: { width: 14, height: 5 } },
  flower_pot: { originY: 17 / 18, collider: { width: 8, height: 5 } },
  scarecrow: { originY: 27 / 28, collider: { width: 6, height: 4 } },
};

/**
 * Player-built structures: fences (auto-connecting), floor paths, lamp posts,
 * chests, and the player's cottage. Owns their sprites, colliders, storage
 * and light sources, and serialises them for saving.
 */
export class BuildSystem {
  private readonly byTile = new Map<number, Placed>();
  private readonly all = new Set<Placed>();
  /** Chest whose contents the UI is currently showing. */
  openChest: Placed | null = null;

  constructor(
    private readonly scene: Phaser.Scene,
    private readonly world: WorldData,
    private readonly floor: Phaser.Tilemaps.TilemapLayer,
    private readonly obstacles: Phaser.Physics.Arcade.StaticGroup,
    private readonly occlusion: OcclusionSystem,
    private readonly fx: FxSystem,
  ) {
    floor.setDepth(DEPTH.floor);
  }

  at(tx: number, ty: number): Placed | undefined {
    return this.byTile.get(this.key(tx, ty));
  }

  isBlocked(tx: number, ty: number): boolean {
    return this.byTile.has(this.key(tx, ty));
  }

  /** Tiles a placement of `kind` at (tx, ty) would cover. */
  footprint(kind: PlaceableKind, tx: number, ty: number): Array<[number, number]> {
    return Array.from({ length: PLACEABLES[kind].width }, (_, i) => [tx + i, ty] as [number, number]);
  }

  /**
   * Whether `kind` can go at (tx, ty). `occupied` reports tiles taken by other
   * systems (resources, soil, animals, the player).
   */
  canPlace(kind: PlaceableKind, tx: number, ty: number, occupied: (tx: number, ty: number) => boolean): boolean {
    return this.footprint(kind, tx, ty).every(
      ([x, y]) => terrainAt(this.world, x, y) === Terrain.Grass && !this.isBlocked(x, y) && !occupied(x, y),
    );
  }

  place(kind: PlaceableKind, tx: number, ty: number, items?: InventorySlot[]): Placed {
    const size = GAME_CONFIG.tileSize;
    const def = PLACEABLES[kind];
    const placed: Placed = { kind, tx, ty, sprite: null, shadow: null, zone: null, occluder: null, storage: null };

    if (def.floor) {
      this.floor.putTileAt(kind === 'wood_path' ? TILE.WOOD_PATH : TILE.STONE_PATH, tx, ty);
    } else {
      const visual = VISUALS[kind]!;
      const x = tx * size + (def.width * size) / 2;
      const baseY = kind === 'fence' ? ty * size + size : ty * size + size - 2;
      const texture = kind === 'fence' ? fenceTextureKey(false, false) : placeableTextureKey(kind as Exclude<PlaceableKind, 'fence' | 'wood_path' | 'stone_path'>);
      placed.sprite = this.scene.add
        .image(x, baseY, texture)
        .setOrigin(0.5, visual.originY)
        .setDepth(DEPTH.ySortBase + baseY);
      if (kind !== 'fence') {
        placed.shadow = this.scene.add
          .image(x, baseY - 1, kind === 'cottage' ? TEXTURES.shadowLarge : TEXTURES.shadowSmall)
          .setDepth(DEPTH.shadow)
          .setScale(kind === 'cottage' ? 2.2 : 1, 1);
      }
      const { width, height } = visual.collider;
      placed.zone = this.scene.add.zone(x, baseY - height / 2 - (kind === 'fence' ? 2 : 0), width, height);
      this.obstacles.add(placed.zone);
      if (kind === 'cottage') {
        placed.occluder = { sprite: placed.sprite, x, baseY, halfWidth: 24, height: 48 };
        this.occlusion.add(placed.occluder, tx + 1, ty);
      }
    }

    if (kind === 'chest') {
      placed.storage = new Inventory(CHEST_SIZE, 0, () => {
        if (this.openChest === placed) this.emitChest();
      });
      for (const s of items ?? []) if (s && isItemId(s.itemId) && s.quantity > 0) placed.storage.add(s.itemId, s.quantity);
    }

    for (const [x, y] of this.footprint(kind, tx, ty)) this.byTile.set(this.key(x, y), placed);
    this.all.add(placed);
    if (kind === 'fence') this.refreshFences(tx, ty);
    return placed;
  }

  /** Removes a structure and returns the item it gives back (or null). */
  remove(placed: Placed): ItemId | null {
    const def = PLACEABLES[placed.kind];
    if (!def.item) return null;
    for (const [x, y] of this.footprint(placed.kind, placed.tx, placed.ty)) this.byTile.delete(this.key(x, y));
    this.all.delete(placed);
    if (def.floor) this.floor.removeTileAt(placed.tx, placed.ty);
    placed.sprite?.destroy();
    placed.shadow?.destroy();
    if (placed.zone) this.obstacles.remove(placed.zone, true, true);
    const size = GAME_CONFIG.tileSize;
    this.fx.burst(def.floor || placed.kind === 'lamp_post' ? 'stone' : 'wood', placed.tx * size + 8, placed.ty * size + 10, 6);
    if (placed.kind === 'fence') this.refreshFences(placed.tx, placed.ty);
    return def.item;
  }

  /** Every placed structure of one kind. */
  ofKind(kind: PlaceableKind): Placed[] {
    return [...this.all].filter((p) => p.kind === kind);
  }

  /** Light sources for the night: lamp posts and the cottage's windows. */
  lights(): LightSource[] {
    const size = GAME_CONFIG.tileSize;
    const out: LightSource[] = [];
    for (const p of this.all) {
      if (p.kind === 'lamp_post') out.push({ x: p.tx * size + 8, y: p.ty * size + 4, radius: PLACEABLES.lamp_post.light! });
      if (p.kind === 'cottage') {
        const baseY = p.ty * size + size - 2;
        out.push({ x: p.tx * size + 11, y: baseY - 14, radius: 30 }, { x: p.tx * size + 37, y: baseY - 14, radius: 30 });
      }
    }
    return out;
  }

  openChestUi(placed: Placed): void {
    this.openChest = placed;
    this.emitChest();
  }

  emitChest(): void {
    if (this.openChest?.storage) gameEvents.emit('chest:contents', { slots: this.openChest.storage.snapshot().slots });
  }

  serialize(): PlacedSave[] {
    return [...this.all].map((p) => ({
      kind: p.kind,
      tx: p.tx,
      ty: p.ty,
      ...(p.storage ? { items: p.storage.snapshot().slots } : {}),
    }));
  }

  private refreshFences(tx: number, ty: number): void {
    for (const x of [tx - 1, tx, tx + 1]) {
      const p = this.at(x, ty);
      if (p?.kind !== 'fence' || !p.sprite) continue;
      const east = this.at(x + 1, ty)?.kind === 'fence';
      const west = this.at(x - 1, ty)?.kind === 'fence';
      p.sprite.setTexture(fenceTextureKey(east, west));
    }
  }

  private key(tx: number, ty: number): number {
    return ty * this.world.width + tx;
  }
}

export function chestIsEmpty(placed: Placed): boolean {
  return !placed.storage || placed.storage.slots.every((s) => s === null);
}

