import * as Phaser from 'phaser';
import type { ItemId } from '@farming/shared';
import { itemTextureKey } from '../assets/registerTextures';
import { DEPTH } from '../constants';
import { sfx } from '../audio/sfx';
import { gameEvents } from '../events/GameEventBus';
import type { Inventory } from '../state/Inventory';

interface Drop {
  sprite: Phaser.GameObjects.Image;
  itemId: ItemId;
  quantity: number;
  readyAt: number;
}

const MAGNET_RADIUS = 36;
const PICKUP_RADIUS = 6;
const MAX_SPRITES_PER_SPAWN = 5;

/**
 * Items lying in the world. They pop out of whatever produced them, then get
 * pulled toward the player and into the inventory (if there is room).
 */
export class DropSystem {
  private readonly drops: Drop[] = [];
  private fullWarningAt = 0;

  constructor(private readonly scene: Phaser.Scene) {}

  spawn(itemId: ItemId, quantity: number, x: number, y: number): void {
    if (quantity <= 0) return;
    const pieces = Math.min(quantity, MAX_SPRITES_PER_SPAWN);
    for (let i = 0; i < pieces; i++) {
      const share = Math.floor(quantity / pieces) + (i < quantity % pieces ? 1 : 0);
      const sprite = this.scene.add.image(x, y, itemTextureKey(itemId));
      const tx = x + Phaser.Math.Between(-12, 12);
      const ty = y + Phaser.Math.Between(2, 12);
      const arc = Phaser.Math.Between(8, 14);
      this.scene.tweens.addCounter({
        from: 0,
        to: 1,
        duration: 360,
        ease: 'Linear',
        onUpdate: (tween) => {
          const t = tween.getValue() ?? 1;
          sprite.setPosition(x + (tx - x) * t, y + (ty - y) * t - Math.sin(Math.PI * t) * arc);
        },
      });
      this.drops.push({ sprite, itemId, quantity: share, readyAt: this.scene.time.now + 500 });
    }
  }

  update(delta: number, px: number, py: number, inventory: Inventory): void {
    const now = this.scene.time.now;
    const targetY = py - 6;
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const drop = this.drops[i];
      const s = drop.sprite;
      s.setDepth(DEPTH.ySortBase + s.y + 6);
      if (now < drop.readyAt) continue;

      const dx = px - s.x;
      const dy = targetY - s.y;
      const dist = Math.hypot(dx, dy);
      if (dist > MAGNET_RADIUS) continue;

      if (inventory.capacityFor(drop.itemId) === 0) {
        if (now > this.fullWarningAt) {
          gameEvents.emit('toast', { text: 'Inventory full' });
          this.fullWarningAt = now + 3000;
        }
        continue;
      }

      if (dist <= PICKUP_RADIUS) {
        const leftover = inventory.add(drop.itemId, drop.quantity);
        const collected = drop.quantity - leftover;
        if (collected > 0) {
          gameEvents.emit('item:collected', { itemId: drop.itemId, quantity: collected });
          sfx('pickup', { volume: 0.7 });
        }
        if (leftover === 0) {
          s.destroy();
          this.drops.splice(i, 1);
        } else {
          drop.quantity = leftover;
        }
        continue;
      }

      const speed = 120 + (MAGNET_RADIUS - dist) * 7;
      const step = Math.min(dist, (speed * delta) / 1000);
      s.setPosition(s.x + (dx / dist) * step, s.y + (dy / dist) * step);
    }
  }
}
