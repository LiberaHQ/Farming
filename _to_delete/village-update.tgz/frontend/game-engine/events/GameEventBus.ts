import type { AppearanceChoice, AppearancePart, ItemAmount, ItemId, NpcId, Season, TerrainName, WeatherKind } from '@farming/shared';

/**
 * Two typed channels between the Phaser game and the React UI:
 *
 * - gameEvents   (game → UI): state snapshots and notifications.
 * - gameCommands (UI → game): player intents from menus (move a stack, craft…).
 *
 * The game stays the single source of truth; React renders what it is told and
 * asks the game to change things. Neither file imports Phaser, so React can use
 * them without pulling the engine into the server bundle.
 */

export interface InventorySlotView {
  itemId: ItemId;
  quantity: number;
}

export type PanelId = 'inventory' | 'crafting' | 'shop' | 'chest' | 'character' | 'menu' | 'dialogue' | 'map' | 'board';

/** The merchant you're trading with, and what's on offer. */
export interface ShopContext {
  npcId: NpcId;
  name: string;
  title: string;
  shopTitle: string;
  greeting: string;
  hearts: number;
  /** 0–0.2 discount from friendship. */
  discount: number;
  giftedToday: boolean;
  stock: Array<{ itemId: ItemId; price: number; basePrice: number }>;
  /** What they pay per item (only items they buy). */
  offers: Partial<Record<ItemId, number>>;
  barter: Array<{ give: ItemAmount[]; get: ItemAmount }>;
  /** Items they love / like as gifts. */
  loves: ItemId[];
  likes: ItemId[];
}

export interface BoardRequestView {
  index: number;
  npcName: string;
  itemId: ItemId;
  itemName: string;
  quantity: number;
  have: number;
  reward: number;
  text: string;
  done: boolean;
}

export interface FriendView {
  id: NpcId;
  name: string;
  title: string;
  hearts: number;
  progress: number;
  talkedToday: boolean;
  giftedToday: boolean;
}

export interface GameEventMap {
  'world:ready': { seed: string; widthTiles: number; heightTiles: number; objectCount: number };
  'player:tile': { tx: number; ty: number; terrain: TerrainName };
  'player:stats': {
    gold: number;
    lifetimeEarnings: number;
    water: number;
    waterCapacity: number;
    energy: number;
    maxEnergy: number;
  };
  'player:appearance': { choice: AppearanceChoice };
  'world:time': {
    day: number;
    year: number;
    season: Season;
    dayOfSeason: number;
    minute: number;
    clock: string;
    weather: WeatherKind;
    /** True while the merchant is at her stall. */
    shopOpen: boolean;
  };
  'chest:contents': { slots: (InventorySlotView | null)[] };
  dialogue: { speaker: string; text: string; hearts?: number };
  'shop:context': ShopContext;
  'board:state': { requests: BoardRequestView[]; friends: FriendView[] };
  /** World map snapshot (data URL) and the player's position on it, in map pixels. */
  'map:image': { url: string; width: number; height: number; player: { x: number; y: number }; home: { x: number; y: number } };
  'save:info': { hasSave: boolean; savedAt: number | null; storage: string };
  'audio:settings': { master: number; music: number; sfx: number; ambience: number; muted: boolean };
  /** Screen position (CSS px) of the faced object's action button; null = hidden. */
  'interaction:anchor': { x: number; y: number } | null;
  'inventory:changed': { slots: (InventorySlotView | null)[]; selected: number; hotbarSize: number };
  'ui:panel': { panel: PanelId | null };
  'interaction:hint': { action: string | null; key: string | null; blocked: boolean; info?: boolean };
  'perf:fps': { fps: number };
  // Transient notifications (not replayed to late subscribers):
  'item:collected': { itemId: ItemId; quantity: number };
  toast: { text: string };
}

export interface GameCommandMap {
  'inventory:select': { index: number };
  'inventory:move': { from: number; to: number };
  craft: { recipeId: string };
  'shop:buy': { itemId: ItemId; quantity: number };
  'shop:sell': { slot: number; quantity: number };
  'shop:barter': { index: number };
  'shop:gift': { slot: number };
  'board:deliver': { index: number };
  'ui:open': { panel: PanelId };
  'ui:close': Record<string, never>;
  'chest:transfer': { from: 'chest' | 'inventory'; slot: number };
  'appearance:set': { part: AppearancePart; index: number };
  'game:save': Record<string, never>;
  'game:new': Record<string, never>;
  /** Save immediately without announcing (leaving the game). */
  'game:flush': Record<string, never>;
  'audio:set': { channel: 'master' | 'music' | 'sfx' | 'ambience'; value: number };
  'audio:mute': Record<string, never>;
  /** The on-screen action button was clicked. */
  'action:perform': { trigger: 'use' | 'interact' };
  /** Eat the food in an inventory slot. */
  'item:eat': { slot: number };
}

const TRANSIENT_EVENTS = new Set<keyof GameEventMap>(['item:collected', 'toast']);

type Listener<T> = (payload: T) => void;

class Channel<M extends object> {
  private listeners = new Map<keyof M, Set<Listener<never>>>();
  private last = new Map<keyof M, unknown>();

  constructor(private readonly replay: (event: keyof M) => boolean) {}

  /** Subscribes (replaying the latest cached value, if any). Returns an unsubscribe function. */
  on<K extends keyof M>(event: K, listener: Listener<M[K]>): () => void {
    let set = this.listeners.get(event);
    if (!set) {
      set = new Set();
      this.listeners.set(event, set);
    }
    set.add(listener as Listener<never>);
    if (this.last.has(event)) listener(this.last.get(event) as M[K]);
    return () => {
      set.delete(listener as Listener<never>);
    };
  }

  emit<K extends keyof M>(event: K, payload: M[K]): void {
    if (this.replay(event)) this.last.set(event, payload);
    this.listeners.get(event)?.forEach((listener) => (listener as Listener<M[K]>)(payload));
  }

  /** Forget cached values (used when a game instance is destroyed). */
  reset(): void {
    this.last.clear();
  }
}

export const gameEvents = new Channel<GameEventMap>((event) => !TRANSIENT_EVENTS.has(event));
export const gameCommands = new Channel<GameCommandMap>(() => false);
