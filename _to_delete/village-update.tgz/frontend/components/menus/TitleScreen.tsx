'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import type { WorldSummary } from '@farming/shared';
import { LocalSaveStore } from '@/game-engine/state/save';
import { useSession } from '@/hooks/useSession';
import { api, cleanSeed, randomSeed } from '@/services/api';

interface WorldEntry extends WorldSummary {
  where: 'cloud' | 'browser' | 'both';
}

const timeAgo = (ms: number) => {
  const mins = Math.round((Date.now() - ms) / 60_000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours} h ago`;
  return new Date(ms).toLocaleDateString();
};

/** Main menu: account, saved worlds, and starting a new world. */
export function TitleScreen() {
  const router = useRouter();
  const { user, online, logout } = useSession();
  const [worlds, setWorlds] = useState<WorldEntry[] | null>(null);
  const [seed, setSeed] = useState('');
  const [seedError, setSeedError] = useState<string | null>(null);

  useEffect(() => setSeed(randomSeed()), []);

  useEffect(() => {
    if (user === undefined) return;
    let cancelled = false;
    (async () => {
      const local = new LocalSaveStore().list();
      const cloud = user ? await api.worlds().then((r) => r.worlds).catch(() => [] as WorldSummary[]) : [];
      const merged = new Map<string, WorldEntry>();
      for (const w of cloud) merged.set(w.seed, { ...w, where: 'cloud' });
      for (const w of local) {
        const existing = merged.get(w.seed);
        if (!existing) merged.set(w.seed, { ...w, where: 'browser' });
        else merged.set(w.seed, { ...(w.savedAt > existing.savedAt ? w : existing), where: 'both' });
      }
      if (!cancelled) setWorlds([...merged.values()].sort((a, b) => b.savedAt - a.savedAt));
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  const play = (name: string) => router.push(`/play?seed=${encodeURIComponent(name)}`);
  const startNew = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = cleanSeed(seed);
    if (!clean) {
      setSeedError('Use letters, numbers, spaces, - or _ (up to 64).');
      return;
    }
    play(clean);
  };
  const existing = worlds?.find((w) => w.seed === cleanSeed(seed));

  return (
    <main className="menu-page">
      <header className="title">
        <h1>Farming Game</h1>
        <p className="hud-muted">Farm, gather, craft and build in a cosy pixel world.</p>
      </header>

      <section className="card account">
        {user === undefined ? (
          <span className="hud-muted">Checking your account…</span>
        ) : user ? (
          <>
            <span>
              Signed in as <strong>{user.displayName}</strong>
              <span className="hud-muted"> · your worlds are saved to your account</span>
            </span>
            <span className="account-actions">
              <Link className="btn" href="/profile">
                Profile
              </Link>
              <button type="button" className="btn" onClick={() => void logout()}>
                Log out
              </button>
            </span>
          </>
        ) : online ? (
          <>
            <span>
              Playing as a <strong>guest</strong>
              <span className="hud-muted"> · saves stay in this browser</span>
            </span>
            <span className="account-actions">
              <Link className="btn" href="/login">
                Log in
              </Link>
              <Link className="btn btn-primary" href="/register">
                Create account
              </Link>
            </span>
          </>
        ) : (
          <span className="hud-muted">
            The server is offline, so accounts are unavailable. You can still play; saves stay in this browser.
          </span>
        )}
      </section>

      <section className="card">
        <h2>Your worlds</h2>
        {worlds === null ? (
          <p className="hud-muted">Loading…</p>
        ) : worlds.length === 0 ? (
          <p className="hud-muted">No saved worlds yet. Start one below!</p>
        ) : (
          <ul className="world-list">
            {worlds.map((w) => (
              <li key={w.seed}>
                <div className="world-info">
                  <strong>{w.seed}</strong>
                  <span className="hud-muted">
                    Day {w.day} · {w.gold}g · saved {timeAgo(w.savedAt)}
                    {w.where === 'browser' && user ? ' · this browser only (syncs when you play)' : ''}
                  </span>
                </div>
                <button type="button" className="btn btn-primary" onClick={() => play(w.seed)}>
                  Continue
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="card">
        <h2>New world</h2>
        <form className="new-world" onSubmit={startNew}>
          <label htmlFor="seed" className="hud-muted">
            World name (the same name always makes the same map)
          </label>
          <div className="new-world-row">
            <input
              id="seed"
              className="input"
              value={seed}
              maxLength={64}
              onChange={(e) => {
                setSeed(e.target.value);
                setSeedError(null);
              }}
            />
            <button type="button" className="btn" onClick={() => setSeed(randomSeed())} title="Random name">
              Shuffle
            </button>
            <button type="submit" className="btn btn-primary">
              {existing ? 'Continue' : 'Start'}
            </button>
          </div>
          {seedError && <p className="form-error">{seedError}</p>}
          {existing && !seedError && <p className="hud-muted">You already have a save for this world; it will be continued.</p>}
        </form>
      </section>
    </main>
  );
}
