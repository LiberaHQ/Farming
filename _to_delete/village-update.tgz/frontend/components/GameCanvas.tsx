'use client';

import { useEffect, useRef, useState } from 'react';
import type { AppearanceChoice } from '@farming/shared';
import type { GameHandle } from '@/game-engine';
import { LocalSaveStore, type SaveStore } from '@/game-engine/state/save';
import { api } from '@/services/api';
import { CloudSaveStore } from '@/services/saveStores';

/** Signed-in players save to their account; guests save in the browser. */
async function chooseStore(): Promise<{ store: SaveStore; appearance?: AppearanceChoice }> {
  try {
    const health = await api.health();
    if (!health.database) return { store: new LocalSaveStore() };
    const { user } = await api.me();
    if (!user) return { store: new LocalSaveStore() };
    const { profile } = await api.profile();
    return { store: new CloudSaveStore(user.displayName), appearance: profile.appearance };
  } catch {
    return { store: new LocalSaveStore() };
  }
}

/**
 * Mounts the Phaser game into a div. The engine is imported dynamically inside
 * the effect, so it only ever loads in the browser (never during SSR). The
 * save is loaded first, so the game starts directly in the right state.
 */
export function GameCanvas({ seed }: { seed: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let handle: GameHandle | null = null;
    let cancelled = false;

    (async () => {
      const [{ createGame }, { store, appearance }] = await Promise.all([import('@/game-engine'), chooseStore()]);
      const initialSave = await store.load(seed);
      if (cancelled || !containerRef.current) return;
      handle = createGame(containerRef.current, { seed, store, initialSave, defaultAppearance: appearance });
    })().catch((err: unknown) => {
      console.error(err);
      if (!cancelled) setError('The game failed to start. Try reloading the page.');
    });

    return () => {
      cancelled = true;
      handle?.destroy();
    };
  }, [seed]);

  return (
    <>
      <div ref={containerRef} className="game-canvas" />
      {error && <div className="hud-loading">{error}</div>}
    </>
  );
}
